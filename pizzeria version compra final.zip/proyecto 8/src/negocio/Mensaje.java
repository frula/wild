package negocio;

import java.net.PasswordAuthentication;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JOptionPane;

public class Mensaje {
	public static String Usuario="";
	public static String Contrase�a="";
	public String  mensage;
	public String Asunto;
	public String Subject;
	
	/* public void SendMail() {
	        Properties props = new Properties();
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.host", "smtp.gmail.com");
	        props.put("mail.smtp.port", "587");

	        Session session = Session.getInstance(props,
	                new javax.mail.Authenticator() {
	                    protected PasswordAuthentication getPasswordAuthentication() {
	                        return new PasswordAuthentication(Usuario, Contrase�a);
	                    }
	                });

	        try {

	            Message message = new MimeMessage(session);
	            message.setFrom(new InternetAddress(Usuario));
	            message.setRecipients(Message.RecipientType.TO,
	                    InternetAddress.parse(Asunto));
	            message.setSubject(Subject);
	            message.setText(mensage);

	            Transport.send(message);
	            JOptionPane.showMessageDialog(this, "Su mensaje ha sido enviado");

	        } catch (MessagingException e) {
	            throw new RuntimeException(e);
	        }
	    }*/
	
	public static void enviar(String mailenvio,String contrase�a,String destinatario,String asunto,String mensaje,String archivo){
		String host = "localhost";
		Properties propiedades = System.getProperties();
		propiedades.setProperty("mail.smtp.host", host);
		  Session sesion = Session.getDefaultInstance(propiedades);
		    try{
		  MimeMessage mensaje1 = new MimeMessage(sesion);
		  mensaje1.setFrom(new InternetAddress(mailenvio));
		  mensaje1.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario));
		  mensaje1.setSubject(asunto);
		  BodyPart cuerpoMensaje = new MimeBodyPart();
		  cuerpoMensaje.setText(mensaje);
		  Multipart multiparte = new MimeMultipart();
		  multiparte.addBodyPart(cuerpoMensaje);
		  
		  // Ahora el proceso para adjuntar el archivo//falta el nombre del archivo
	      cuerpoMensaje = new MimeBodyPart();
	      String nombreArchivo = "consulta.pdf";
	      DataSource fuente = new FileDataSource(nombreArchivo);
	      cuerpoMensaje.setDataHandler(new DataHandler(fuente));
	      cuerpoMensaje.setFileName(nombreArchivo);
	      multiparte.addBodyPart(cuerpoMensaje);
	      
	      mensaje1.setContent(multiparte);
	      
	      Transport.send(mensaje1);
	      System.out.println("Mensaje enviado");
		  
	} catch (MessagingException e) {
	      e.printStackTrace();
	    }
	}
}
