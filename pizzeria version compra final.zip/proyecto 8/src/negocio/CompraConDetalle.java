package negocio;

public class CompraConDetalle {

	
	static String proveedor;
    public String MateriaPrima;
	public int cant;
	public int idCompra;
	
	
	public CompraConDetalle(String pro,String mat,int cant,int id){
		this.proveedor=pro;
		this.MateriaPrima=mat;
		this.cant=cant;
		this.idCompra=id;
	}
	public CompraConDetalle(){
		this.proveedor="";
		this.MateriaPrima="";
		this.cant=0;
		this.idCompra=0;
	}
}
