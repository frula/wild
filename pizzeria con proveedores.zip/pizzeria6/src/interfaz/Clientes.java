package interfaz;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import negocio.Cliente;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Clientes {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Clientes window = new Clientes();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Clientes() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblDni = new JLabel("DNI");
		lblDni.setBounds(10, 47, 46, 14);
		frame.getContentPane().add(lblDni);
		
		textField = new JTextField();
		textField.setBounds(66, 44, 180, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(66, 83, 180, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(10, 86, 46, 14);
		frame.getContentPane().add(lblNombre);
		
		JLabel lblDireccion = new JLabel("Direccion");
		lblDireccion.setBounds(10, 124, 46, 14);
		frame.getContentPane().add(lblDireccion);
		
		textField_2 = new JTextField();
		textField_2.setBounds(66, 121, 180, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblTelefono = new JLabel("Telefono");
		lblTelefono.setBounds(10, 161, 46, 14);
		frame.getContentPane().add(lblTelefono);
		
		textField_3 = new JTextField();
		textField_3.setBounds(66, 158, 180, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblEstado = new JLabel("Estado");
		lblEstado.setBounds(10, 199, 46, 14);
		frame.getContentPane().add(lblEstado);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(66, 199, 86, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Agregar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int dni=Integer.parseInt(textField_1.getText());
				Cliente.AgregarCliente(textField.getText(),textField_1.getText(),textField_2.getText(),textField_3.getText(),1);
			}
		});
		btnNewButton.setBounds(322, 82, 80, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnBuscar = new JButton("Cambiar estado");
		btnBuscar.setBounds(289, 195, 135, 23);
		frame.getContentPane().add(btnBuscar);
		
		JButton btnNewButton_1 = new JButton("Modificar");
		btnNewButton_1.setBounds(322, 43, 80, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		textField_4 = new JTextField();
		textField_4.setBounds(10, 11, 86, 20);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnBuscar_1 = new JButton("Buscar");
		btnBuscar_1.setBounds(120, 10, 89, 23);
		frame.getContentPane().add(btnBuscar_1);
	}
}
