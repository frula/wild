package persistencia.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import presentacion.vista.Mensajes;

public class Conexion 
{
	public static Conexion instancia;
	private final static String driver = "com.mysql.jdbc.Driver";
	private static Connection conexion;
		
	public Conexion()
	{
		try
		{
			Class.forName(driver).newInstance();
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/agenda",LeeFichero.leerUser(),LeeFichero.leerPass());
			System.out.println("Conexion exitosa");
		}
		catch(Exception e)
		{
			Mensajes.lanzarMensajeInformativo("Conexion Fallida");
		}
	}
	
	public static boolean establecerConexion() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/agenda",LeeFichero.leerUser(),LeeFichero.leerPass());
			return true;
		} catch (Exception e) {
			//Mensajes.lanzarMensajeInformativo("Imposible realizar conexion con la BD, verificar configuracion");
			e.printStackTrace();
			return false;
		}
	}
	
	public static Conexion getConexion()   
	{								
		if(instancia == null)
		{
			instancia = new Conexion();
		}
		return instancia;
	}
	
	public static Connection DameConexion() {
		return conexion;
	}

	public Connection getSQLConexion() 
	{
		return conexion;
	}
	
	public void cerrarConexion()
	{
		instancia = null;
	}
	
	public static void cerrarconexion() {

		if (conexion != null) {
			try {
				conexion.close();
			} catch (Exception e) {
			}
		}
	}
	
	public static ResultSet consultasql(String sql) throws SQLException {

		establecerConexion();
		Statement stmt = Conexion.DameConexion().createStatement();
		ResultSet resultado = stmt.executeQuery(sql);
		if (resultado.next())
			return resultado;
		System.err.println("La consulta est� vacia");
		// cerrarconexion();
		return resultado;

	}

	public static void ejecutarsql(String sql) throws SQLException {

		 establecerConexion();
		Statement stmt =Conexion.DameConexion().createStatement();
		stmt.execute(sql);
		 cerrarconexion();
	}
	
	private String devuelvePassword(){
		String pass="";
	
		
		
		return pass;
	}
}
