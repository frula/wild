package persistencia.conexion;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import presentacion.vista.Mensajes;

public class LeeFichero {

	public static String leerUser() {
		FileReader fr = null;
		BufferedReader br = null;
		String linea = "";
		try {
			fr = new FileReader(System.getProperty("user.dir")+"\\config.txt");
			br = new BufferedReader(fr);

			// Lectura del fichero
			for(int i=0;i<1;i++){
			linea = br.readLine();
			}
			System.out.println(linea);
			if (null != fr) {
				fr.close();
			}
		} catch (Exception e) {
			System.out.println("Excepcion leyendo fichero ");
		}
		return linea;

	}

	public static String leerPass() {
		FileReader fr = null;
		BufferedReader br = null;
		String linea = "";
		try {
			fr = new FileReader(System.getProperty("user.dir")+"\\config.txt");
			br = new BufferedReader(fr);

			// Lectura del fichero
			for(int i=0;i<=1;i++){
			linea = br.readLine();
			}
			fr.close();
			if (null != fr) {
				fr.close();
			}
		
		} catch (Exception e) {
			//Mensajes.lanzarMensajeInformativo("Error al modificar fichero config.txt . Verificar si existe el " +
				//	"mismo en la ruta"+System.getProperty("user.dir")+"\\config.txt");
		}
		return linea;

	}
	
	public static void setUserYPass(String nuevoUser,String nuevaPass){
		
		//File TextFile = new File("C:\\config\\config.txt"); 
	
		try {
			//System.getProperty("user.dir")+"\\config.txt")
			
			java.io.BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getProperty("user.dir")+"\\config.txt"));
			bufferedWriter.append(nuevoUser);
			bufferedWriter.flush();
			bufferedWriter.newLine();
			bufferedWriter.append(nuevaPass);
			bufferedWriter.flush();
			
		} catch (Exception e) {
			//Mensajes.lanzarMensajeInformativo("Error al modificar fichero config.txt. Verificar si existe el " +
				//	"mismo en la ruta"+System.getProperty("user.dir")+"\\config.txt");
		}
		}

}
