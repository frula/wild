package persistencia.conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;

import Negocio.Localidad;
import Negocio.Tipo;

public class Consultas {
	
	public static ArrayList<Localidad> localidades = new ArrayList<Localidad>();
	public static ArrayList<Tipo> tipos = new ArrayList<Tipo>();
	
	// Devuelve las localidades
	
	public static ArrayList<Localidad> devuelveLocalidades() {
		try {
			borrarListaLocalidad();
			localidades=new ArrayList<Localidad>();
			ResultSet result;
			result = Busqueda.devuelveTabla("Localidad");
			result.previous();
			while (result.next()) {
				localidades.add(new Localidad(result.getString(2),result.getString(3)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return localidades;
	}
	
	public static String devuelveProvincia(ArrayList<Localidad> listaLocalidades, String localidadABuscar){
		
		String provinciaDevuelta=null;
		
		for(int i=0;i<listaLocalidades.size();i++){
			
			if(listaLocalidades.get(i).getLocalidad().equals(localidadABuscar)){
				
				provinciaDevuelta=listaLocalidades.get(i).getProvincia();
			}
			
		}
		
		return provinciaDevuelta;
	}
	
	public static ArrayList<Tipo> devuelveTipos() {
		try {
			tipos=new ArrayList<Tipo>();
			ResultSet result;
			result = Busqueda.devuelveTabla("Tipo");
			result.previous();
			while (result.next()) {
				tipos.add(new Tipo(result.getInt(1),result.getString(2)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tipos;
	}
	
	public static boolean LocalidadExistenteparaAgregar(String localidad, String provincia){
		devuelveLocalidades();
		boolean existe=false;
		for(int i=0;i<localidades.size();i++){
			if(localidades.get(i).getLocalidad().toUpperCase().equals(localidad.toUpperCase())
					&& localidades.get(i).getProvincia().equals(provincia)){
				existe=true;
			}
		}
		borrarListaLocalidad();
		return existe;
	}
	
	public static boolean LocalidadExistentemodyeli(String localidad, String provincia){
		devuelveLocalidades();
		boolean existe=false;
		for(int i=0;i<localidades.size();i++){
			if(localidades.get(i).getLocalidad().equals(localidad)
					&& localidades.get(i).getProvincia().equals(provincia)){
				existe=true;
			}
		}
		borrarListaLocalidad();
		return existe;
	}
	
	public static boolean TipoExistenteparaAgregar(String tipo){
		devuelveTipos();
		boolean existe=false;
		for(int i=0;i<tipos.size();i++){
			if(tipos.get(i).getTipo().toUpperCase().equals(tipo.toUpperCase())){
				existe=true;
			}
		}
		borrarListaTipo();
		return existe;
	}
	
	public static boolean TipoExistenteparaModyEli(String tipo){
		devuelveTipos();
		boolean existe=false;
		for(int i=0;i<tipos.size();i++){
			if(tipos.get(i).getTipo().equals(tipo)){
				existe=true;
			}
		}
		borrarListaTipo();
		return existe;
	}
	
	public static void AgregarLocalidad(String localidad, String provincia) {
		String sql = "INSERT INTO localidad (Localidad,Provincia) VALUES("
				+"'"+ localidad + "'" + "," +"'"+ provincia +"'"+ ")";
		borrarListaLocalidad();
		try {
			Conexion.ejecutarsql(sql);

			JOptionPane.showMessageDialog(null,
					"Registro guardado exitosamente");
		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(null, "Error al guardar registro");
			Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null,
					ex);
		}
	}
	
	public static void EliminarLocalidad(String localidad, String provincia) {
		String sql = "DELETE FROM localidad WHERE localidad=" + "'" + localidad
				+ "'" +" AND provincia="+ "'" + provincia+ "'";
		JOptionPane.showMessageDialog(null,
				"Registro eliminado");
		borrarListaLocalidad();
		try {
			Conexion.ejecutarsql(sql);
		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(null, "Error");
			Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null,
					ex);
		}
	}
	
	public static void ModificarLocalidad(String localidadAmod,String localidad,String ProvinciaAmod,String prov){
			String sql="UPDATE localidad SET Localidad="+"'"+localidad+"'"+" , "
		   		+ "Provincia="+" '"+prov+"'"+ " WHERE Localidad="+" '"+localidadAmod+"'"+" AND Provincia="+" '"+ProvinciaAmod+"'";  
			borrarListaLocalidad();
			try {
				Conexion.ejecutarsql(sql);
	        } catch (SQLException ex) {
	            Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
	        } 
	}
	public static void ModificarLocalidadAgenda(String localidadAmod,String localidad){
		String sql="UPDATE personas SET Localidad="+"'"+localidad+"'"+" WHERE Localidad="+" '"+localidadAmod+"'";  
		borrarListaLocalidad();
		try {
			Conexion.ejecutarsql(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
        } 
}	
	public static void AgregarTipo(String tipo) {
		String sql = "INSERT INTO tipo (Tipo) VALUES("
				+"'"+ tipo + "'"+")";
		try {
			Conexion.ejecutarsql(sql);

			JOptionPane.showMessageDialog(null,
					"Registro guardado exitosamente");
			borrarListaTipo();
		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(null, "Error al guardar registro");
			Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null,
					ex);
		}
	}
	
	public static void EliminarTipo(String tipo) {
		String sql = "DELETE FROM tipo WHERE tipo=" +"'"+ tipo+"'";
		JOptionPane.showMessageDialog(null,
				"Registro"+" '"+tipo+"' "+"eliminado");
		borrarListaTipo();
		try {
			Conexion.ejecutarsql(sql);
		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(null, "Error");
			Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null,
					ex);
		}
	}
	
	public static void ModificarTipo(String tipoAmod,String tipo){
		String sql="UPDATE tipo SET Tipo="+"'"+tipo+"'"+""
				+ "WHERE Tipo="+" '"+tipoAmod+"'";  
	   borrarListaTipo();
	   try {
		   Conexion.ejecutarsql(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
        } 
}

	public static void ModificarTipoAgenda(String tipoAmod,String tipo){
		String sql="UPDATE personas set Tipo = "+"'"+tipo+"'"+" WHERE Tipo="+"'"+tipoAmod+"'";
	   borrarListaTipo();
	   try {
		   Conexion.ejecutarsql(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
        } 
}
	public static void borrarListaLocalidad(){
		for (int i=0;i<localidades.size();i++){
			localidades.remove(i);
		}
	}
	public static void borrarListaTipo(){
		for (int i=0;i<tipos.size();i++){
			tipos.remove(i);
		}
	}
}
