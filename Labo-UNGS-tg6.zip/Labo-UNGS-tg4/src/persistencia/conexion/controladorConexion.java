package persistencia.conexion;

public class controladorConexion {
	

	public static String getUser() {
		String user="";
		return user;
	}

	public static void setUser(String user) {
	
	}

	public static String getPass() {
		String pass="";
		
		return pass;
	}

	public static void setPass(String pass) {

	}
}
