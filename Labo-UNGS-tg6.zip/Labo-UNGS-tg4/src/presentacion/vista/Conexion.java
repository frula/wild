package presentacion.vista;


import java.awt.Color;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

import persistencia.conexion.Consultas;
import persistencia.conexion.LeeFichero;
import presentacion.controlador.Controlador;

import com.toedter.calendar.JDateChooser;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Conexion extends JFrame 
{
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtUserActivo;
	private JTextField txtPassActual;
	private JTextField txtUserNuevo;
	private JTextField textPassNueva;

	public Conexion() 
	{
		super();
		setTitle("Paramentros de conexi\u00F3n:");
		setType(Type.POPUP);
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 409, 308);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel.setBounds(10, 11, 376, 202);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblUsuActivo = new JLabel("Usuario activo:");
		lblUsuActivo.setBounds(10, 35, 88, 14);
		panel.add(lblUsuActivo);
		
		JLabel lblPassActiva = new JLabel("Password Actual:");
		lblPassActiva.setBounds(10, 74, 88, 14);
		panel.add(lblPassActiva);
		
		txtUserActivo = new JTextField();
		txtUserActivo.setEnabled(false);
		txtUserActivo.setBorder(UIManager.getBorder("TextField.border"));
		txtUserActivo.setBounds(123, 32, 239, 20);
		panel.add(txtUserActivo);
		txtUserActivo.setColumns(10);
		
		txtPassActual = new JTextField();
		txtPassActual.setEnabled(false);
		txtPassActual.setBorder(UIManager.getBorder("TextField.border"));
		txtPassActual.setBounds(123, 71, 239, 20);
		panel.add(txtPassActual);
		txtPassActual.setColumns(10);
		
		JLabel lblNuevaPassword = new JLabel("Nueva Password:");
		lblNuevaPassword.setBounds(10, 151, 88, 14);
		panel.add(lblNuevaPassword);
		
		txtUserNuevo = new JTextField();
		txtUserNuevo.setBorder(UIManager.getBorder("TextField.border"));
		txtUserNuevo.setColumns(10);
		txtUserNuevo.setBounds(123, 108, 239, 20);
		panel.add(txtUserNuevo);
		
		JLabel lblNuevoUsuario = new JLabel("Nuevo Usuario:");
		lblNuevoUsuario.setBounds(10, 111, 88, 14);
		panel.add(lblNuevoUsuario);
		
		textPassNueva = new JTextField();
		textPassNueva.setColumns(10);
		textPassNueva.setBorder(UIManager.getBorder("TextField.border"));
		textPassNueva.setBounds(123, 148, 239, 20);
		panel.add(textPassNueva);
		
		JLabel lblDomicilio = new JLabel("Domicilio");
		lblDomicilio.setBounds(11, 11, 375, 20);
		contentPane.add(lblDomicilio);
		lblDomicilio.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		lblDomicilio.setBackground(Color.DARK_GRAY);
		lblDomicilio.setHorizontalAlignment(SwingConstants.CENTER);
		
		JButton btnConfirmarCambios = new JButton("Confirmar Cambios");
		btnConfirmarCambios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String usuarioNuevo="";
			String passwordNueva="";
					
				if(txtUserNuevo.getText().equals("")==true){
					usuarioNuevo=txtUserActivo.getText();
				}else usuarioNuevo=txtUserNuevo.getText();
				
				if(textPassNueva.getText().equals("")==true){
					passwordNueva="";
				}else passwordNueva=textPassNueva.getText();
			
			LeeFichero.setUserYPass(usuarioNuevo, passwordNueva);
		Mensajes.lanzarMensajeInformativo("Parametros modificados");
		txtUserNuevo.setText("");
		textPassNueva.setText("");
		txtUserActivo.setText(usuarioNuevo);
		txtPassActual.setText(passwordNueva);
			}
		
		});
		btnConfirmarCambios.setBounds(224, 224, 162, 37);
		contentPane.add(btnConfirmarCambios);
		//this.setVisible(true);
		this.txtUserActivo.setText(LeeFichero.leerUser());
		this.txtPassActual.setText(LeeFichero.leerPass());
		
	}
	
}

