package presentacion.vista;
import javax.swing.JOptionPane;

public final class Mensajes {

	 public static void lanzarMensajeInformativo(String mensaje){
	
	  //En la siguiente l�nea est� la magia (es lo que muestra el mensaje).
	
	  JOptionPane.showMessageDialog(null,mensaje,"Aviso de sistema",JOptionPane.INFORMATION_MESSAGE);
	 
	 }
}
