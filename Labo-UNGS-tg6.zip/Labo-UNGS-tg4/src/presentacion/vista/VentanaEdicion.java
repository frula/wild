package presentacion.vista;


import java.awt.Color;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

import persistencia.conexion.Consultas;
import presentacion.controlador.Controlador;

import com.toedter.calendar.JDateChooser;

public class VentanaEdicion extends JFrame 
{
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNombre;
	private JTextField txtTelefono;
	private JButton btnGuardar;
	private Controlador controlador;
	private JTextField txtMail;
	private JTextField txtCalle;
	private JTextField txtAltura;
	private JTextField txtPiso;
	private JTextField txtDepto;
	private JComboBox<String> cbLocalidad;
	private JComboBox<String> cbTipo;
	private JDateChooser txtCumplea�os;

	public VentanaEdicion(Controlador controlador) 
	{
		super();
		setTitle("Editar Contacto");
		setType(Type.POPUP);
		this.controlador = controlador;
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 409, 372);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel.setBounds(10, 11, 376, 314);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNombreYApellido = new JLabel("Nombre y apellido*:");
		lblNombreYApellido.setBounds(10, 35, 115, 14);
		panel.add(lblNombreYApellido);
		
		JLabel lblTelfono = new JLabel("Tel\u00E9fono:");
		lblTelfono.setBounds(10, 74, 88, 14);
		panel.add(lblTelfono);
		
		txtNombre = new JTextField();
		txtNombre.setBorder(UIManager.getBorder("TextField.border"));
		txtNombre.setBounds(123, 32, 239, 20);
		panel.add(txtNombre);
		txtNombre.setColumns(10);
		
		txtTelefono = new JTextField();
		txtTelefono.setBorder(UIManager.getBorder("TextField.border"));
		txtTelefono.setBounds(123, 71, 78, 20);
		panel.add(txtTelefono);
		txtTelefono.setColumns(10);
		
		JLabel lblCumplea�os = new JLabel("Cumplea\u00F1os:");
		lblCumplea�os.setBounds(10, 151, 88, 14);
		panel.add(lblCumplea�os);
		
		JLabel lblDomicilio = new JLabel("Domicilio");
		lblDomicilio.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		lblDomicilio.setBackground(Color.DARK_GRAY);
		lblDomicilio.setHorizontalAlignment(SwingConstants.CENTER);
		lblDomicilio.setBounds(0, 179, 375, 20);
		panel.add(lblDomicilio);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.setLayout(null);
		panel_1.setBounds(0, 199, 376, 116);
		panel.add(panel_1);
		
		JLabel lblLocalidad = new JLabel("Localidad:");
		lblLocalidad.setBounds(10, 14, 68, 14);
		panel_1.add(lblLocalidad);
		
		txtCalle = new JTextField();
		txtCalle.setBorder(UIManager.getBorder("TextField.border"));
		txtCalle.setColumns(10);
		txtCalle.setBounds(88, 45, 156, 20);
		panel_1.add(txtCalle);
		
		JLabel lblCalle = new JLabel("Calle:");
		lblCalle.setBounds(10, 48, 50, 14);
		panel_1.add(lblCalle);
		
		JLabel lblAltura = new JLabel("Altura:");
		lblAltura.setIgnoreRepaint(true);
		lblAltura.setBounds(247, 48, 44, 14);
		panel_1.add(lblAltura);
		
		txtAltura = new JTextField();
		txtAltura.setBorder(UIManager.getBorder("TextField.border"));
		txtAltura.setColumns(10);
		txtAltura.setBounds(291, 45, 75, 20);
		panel_1.add(txtAltura);
		
		JLabel lblPiso = new JLabel("Piso:");
		lblPiso.setIgnoreRepaint(true);
		lblPiso.setBounds(10, 86, 44, 14);
		panel_1.add(lblPiso);
		
		txtPiso = new JTextField();
		txtPiso.setBorder(UIManager.getBorder("TextField.border"));
		txtPiso.setColumns(10);
		txtPiso.setBounds(88, 83, 53, 20);
		panel_1.add(txtPiso);
		
		JLabel lblDepartamento = new JLabel("Depto:");
		lblDepartamento.setIgnoreRepaint(true);
		lblDepartamento.setBounds(151, 86, 44, 14);
		panel_1.add(lblDepartamento);
		
		txtDepto = new JTextField();
		txtDepto.setBorder(UIManager.getBorder("TextField.border"));
		txtDepto.setColumns(10);
		txtDepto.setBounds(189, 83, 55, 20);
		panel_1.add(txtDepto);
		
		btnGuardar = new JButton("Guardar");
		btnGuardar.setBounds(277, 82, 89, 23);
		panel_1.add(btnGuardar);
		
		cbLocalidad = new JComboBox<String>();
		cbLocalidad.setBounds(88, 11, 278, 20);
		panel_1.add(cbLocalidad);
		btnGuardar.addActionListener(this.controlador);
		
		txtMail = new JTextField();
		txtMail.setBorder(UIManager.getBorder("TextField.border"));
		txtMail.setColumns(10);
		txtMail.setBounds(123, 108, 239, 20);
		panel.add(txtMail);
		
		JLabel lblMail = new JLabel("Email:");
		lblMail.setBounds(10, 111, 68, 14);
		panel.add(lblMail);
		
		JLabel lblTipo = new JLabel("Tipo:");
		lblTipo.setBounds(211, 151, 36, 14);
		panel.add(lblTipo);
		
		cbTipo = new JComboBox<String>();
		cbTipo.setBounds(248, 148, 115, 20);
		panel.add(cbTipo);
		JLabel lblCamposObligatorios = new JLabel("(*) Campos obligatorios");
		lblCamposObligatorios.setHorizontalAlignment(SwingConstants.CENTER);
		lblCamposObligatorios.setBounds(211, 74, 151, 14);
		panel.add(lblCamposObligatorios);
		
		txtCumplea�os = new JDateChooser();
		txtCumplea�os.setDateFormatString("yyyy-MM-dd");
		txtCumplea�os.setBounds(106, 145, 95, 20);
		panel.add(txtCumplea�os);
		inicializarCombos();
		//this.setVisible(true);
	}
	
	public JTextField getTxtNombre() 
	{
		return txtNombre;
	}

	public JTextField getTxtTelefono() 
	{
		return txtTelefono;
	}
	public String getTxtCumplea�os() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	    Date date = txtCumplea�os.getDate();
	    String fecha2=format.format(date);
	    
	return fecha2;
	}

	public void setTxtCumplea�os(String txtCumplea�os) throws ParseException {
		//this.txtCumplea�os.setText(txtCumplea�os);
		String dateValue = txtCumplea�os; // What ever column
		java.util.Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateValue);

		this.txtCumplea�os.setDate(date);
	}

	public JTextField getTxtMail() {
		return txtMail;
	}

	public void setTxtMail(String txtMail) {
		this.txtMail.setText(txtMail);
	}

	public JTextField getTxtCalle() {
		return txtCalle;
	}

	public void setTxtCalle(String txtCalle) {
		this.txtCalle.setText(txtCalle);
	}

	public JTextField getTxtAltura() {
		return txtAltura;
	}

	public void setTxtAltura(String txtAltura) {
		this.txtAltura.setText(txtAltura);
	}

	public JTextField getTxtPiso() {
		return txtPiso;
	}

	public void setTxtPiso(String txtPiso) {
		this.txtPiso.setText(txtPiso);
	}
	public void setTipo(String txtTipo) {
		this.cbTipo.setSelectedItem(txtTipo);
	}
	public void setLocalidad(String txtLocalidad) {
		this.cbLocalidad.setSelectedItem(txtLocalidad);
	}
	public JTextField getTxtDepto() {
		return txtDepto;
	}

	public void setTxtDepto(String txtDepto) {
		this.txtDepto.setText(txtDepto);
	}

	public void setTxtNombre(String txtNombre) {
		this.txtNombre.setText(txtNombre);
	}

	public void setTxtTelefono(String txtTelefono) {
		this.txtTelefono.setText(txtTelefono);
	}

	public String getTipo() {
		return String.valueOf(cbTipo.getSelectedItem());
	}
	
	public String getLocalidad() {
		return String.valueOf(cbLocalidad.getSelectedItem());
	}
	
	public JButton getBtnGuardar() 
	{
		return btnGuardar;
	}
	public void inicializarCombos(){
		cbLocalidad.removeAllItems();
		cbTipo.removeAllItems();
		Consultas.devuelveLocalidades();
		Consultas.devuelveTipos();
			for (int i=0;i<Consultas.localidades.size();i++){
				cbLocalidad.addItem(Consultas.localidades.get(i).getLocalidad());
		}
			for (int j=0;j<Consultas.tipos.size();j++){
				cbTipo.addItem(Consultas.tipos.get(j).getTipo());
		}
			}
}

