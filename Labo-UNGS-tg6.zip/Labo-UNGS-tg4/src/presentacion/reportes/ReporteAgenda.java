package presentacion.reportes;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;
import persistencia.conexion.Conexion;
import dto.PersonaDTO;

public class ReporteAgenda
{
	private JasperReport reporte;
	private JasperReport Subreporte;
	private static JasperViewer reporteViewer;
	private static JasperPrint	reporteLleno;
	
	//Recibe la lista de personas para armar el reporte
    public ReporteAgenda(List<PersonaDTO> personas)
    {
    	//Hardcodeado
		Map<String, Object> parametersMap = new HashMap<String, Object>();
		parametersMap.put("Fecha", new SimpleDateFormat("dd/MM/yyyy").format(new Date()));		
    	try		{
    	
    		String dir_current = System.getProperty("user.dir") ;
			this.reporte = (JasperReport) JRLoader.loadObjectFromFile(dir_current+"/XProvincia2.jasper");
			this.reporteLleno = JasperFillManager.fillReport(this.reporte, parametersMap, 
					new JRBeanCollectionDataSource(personas));
		}
		catch( JRException ex ) 	
		{
			ex.printStackTrace();
		}
    }       
    public static void abrirReporte2(String archivo){
    	String fileName = archivo;
    	
    	
    	Conexion.establecerConexion();
    	JasperPrint print;
    	try {
    		print = JasperFillManager.fillReport(fileName, new HashMap(),Conexion.DameConexion());
    		JasperViewer jviewer = new JasperViewer(print, false);
    		jviewer.show();
    		Conexion.establecerConexion();
    	
    	} catch (JRException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
    	
    	
    	
    }	
    public void mostrar()
	{
		this.reporteViewer = new JasperViewer(this.reporteLleno,false);
		this.reporteViewer.setVisible(true);
	}

     public static void abrirReporte(String archivo, String parametroAPasarle, String nombreParametro)
 
    {
    	 String fileName =archivo;
    	 Conexion.establecerConexion();
    	 
    	 try {
    		 Map<String, Object> parametro = new HashMap<String, Object>();
    		 parametro.put(nombreParametro, parametroAPasarle);
    		 
    		 reporteLleno=JasperFillManager.fillReport(fileName,parametro,Conexion.DameConexion());
    		 reporteViewer= new JasperViewer(reporteLleno, false);
    		 reporteViewer.setVisible(true);
    		 
    	 }catch (JRException e){
    		 e.printStackTrace();
    	 }
 
    }

}	