package presentacion.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

import modelo.Agenda;
import persistencia.conexion.Consultas;
import presentacion.reportes.ReporteAgenda;
import presentacion.vista.Mensajes;
import presentacion.vista.VentanaEdicion;
import presentacion.vista.VentanaPersona;
import presentacion.vista.Vista;
import dto.PersonaDTO;

public class Controlador implements ActionListener {
	private Vista vista;
	private List<PersonaDTO> personas_en_tabla;
	private List<PersonaDTO> personasParaEdicion;
	private PersonaDTO personaAEditar;
	private VentanaPersona ventanaPersona;
	private VentanaEdicion ventanaEdicion;
	private Agenda agenda;

	public Controlador(Vista vista, Agenda agenda) {
		this.vista = vista;
		this.vista.getBtnAgregar().addActionListener(this);
		this.vista.getBtnBorrar().addActionListener(this);
		this.vista.getBtnReporte().addActionListener(this);
		this.vista.getBtnEditar().addActionListener(this);
		this.agenda = agenda;
		this.personas_en_tabla = null;
		this.ventanaEdicion = new VentanaEdicion(this);
		GroupLayout groupLayout = new GroupLayout(ventanaEdicion.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGap(0, 383, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGap(0, 324, Short.MAX_VALUE)
		);
		ventanaEdicion.getContentPane().setLayout(groupLayout);
		this.ventanaPersona = new VentanaPersona(this);
	}

	public void inicializar() {
		this.llenarTabla();
	}

	private void llenarTabla() {
		this.vista.getModelPersonas().setRowCount(0); // Para vaciar la tabla
		this.vista.getModelPersonas().setColumnCount(0);
		this.vista.getModelPersonas().setColumnIdentifiers(
				this.vista.getNombreColumnas());

		this.personas_en_tabla = agenda.obtenerPersonas();
		for (int i = 0; i < this.personas_en_tabla.size(); i++) {
			Object[] fila = {this.personas_en_tabla.get(i).getNombre(),
					this.personas_en_tabla.get(i).getTelefono(),
					this.personas_en_tabla.get(i).getEmail(),
					this.personas_en_tabla.get(i).getCumplea�os(),
					this.personas_en_tabla.get(i).getTipo(),
					this.personas_en_tabla.get(i).getLocalidad(),
					this.personas_en_tabla.get(i).getCalle(),
					this.personas_en_tabla.get(i).getAltura(),
					this.personas_en_tabla.get(i).getPiso(),
					this.personas_en_tabla.get(i).getDepto()};
			this.vista.getModelPersonas().addRow(fila);
		}
		this.vista.show();
	}
	//Completo el formulario para la edicion
	private void llenarParaEdicion() {
				
		String nombre,telefono,email,cumplea�os,tipo,localidad,calle,altura,piso,depto;
		
		altura=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 7));
		calle=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 6));
		cumplea�os=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 3));
		depto=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 9));
		email=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(),2));
		nombre=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 0));
		piso=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 8));
		telefono=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 1));
		tipo=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 4));
		localidad=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 5));
		
		//lleno los campos de la ventana de edicion
		//Faltan la localidad y el tipo
		this.ventanaEdicion.setTxtAltura(altura);
		this.ventanaEdicion.setTxtCalle(calle);
		try {
			this.ventanaEdicion.setTxtCumplea�os(cumplea�os);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.ventanaEdicion.setTxtDepto(depto);
		this.ventanaEdicion.setTxtMail(email);
		this.ventanaEdicion.setTxtNombre(nombre);
		this.ventanaEdicion.setTxtPiso(piso);
		this.ventanaEdicion.setTxtTelefono(telefono);
		this.ventanaEdicion.setTipo(tipo);
		this.ventanaEdicion.setLocalidad(localidad);
		
		
	}
	public PersonaDTO contactoAModificar(){
		
		int idPersonaSeleccionada=personas_en_tabla.get(vista.devuelveFilaPersonaSeleccionada()).getIdPersona();
		personaAEditar=new PersonaDTO(idPersonaSeleccionada,ventanaEdicion.getTxtNombre().getText(),ventanaEdicion.getTxtTelefono().getText()
				,ventanaEdicion.getTxtMail().getText(),ventanaEdicion.getTxtCumplea�os(),ventanaEdicion.getTipo(),
			ventanaEdicion.getLocalidad(),ventanaEdicion.getTxtCalle().getText(),ventanaEdicion.getTxtAltura().getText(),
			ventanaEdicion.getTxtPiso().getText(),ventanaEdicion.getTxtDepto().getText(),
			Consultas.devuelveProvincia(Consultas.devuelveLocalidades(),ventanaEdicion.getLocalidad()));
				
				
		return personaAEditar;
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == this.vista.getBtnAgregar()) {
			this.ventanaPersona = new VentanaPersona(this);
			this.ventanaPersona.setVisible(true);
			
					
		} else if (e.getSource() == this.vista.getBtnBorrar()) {
			int[] filas_seleccionadas = this.vista.getTablaPersonas()
					.getSelectedRows();
			for (int fila : filas_seleccionadas) {
				this.agenda.borrarPersona(this.personas_en_tabla.get(fila));
			}

			this.llenarTabla();

		} else if (e.getSource() == this.vista.getBtnEditar()) {
			
				//Abro el formulario para editar
		if(this.vista.getTablaPersonas().getSelectedRow()!=-1){
			this.ventanaEdicion = new VentanaEdicion(this);	
			this.ventanaEdicion.setVisible(true);
				this.llenarParaEdicion();
			
		}else Mensajes.lanzarMensajeInformativo("Debe seleccionar un contacto en la tabla");		
		
		}else if (e.getSource() == this.vista.getBtnReporte()) {
			
			//ReporteAgenda reporte = new ReporteAgenda(agenda.obtenerPersonas());
			//reporte.mostrar();
			//ReporteAgenda.abrirReporte2("reportes\\XProvincia.jasper");
			String dir_current = System.getProperty("user.dir") ;
			ReporteAgenda.abrirReporte(dir_current+"/XProvincia.jasper",null,null);
			
		} else if (e.getSource() == this.ventanaEdicion.getBtnGuardar()) {
			
			if(ventanaEdicion.getTxtNombre().getText().equals("")==false){
				this.agenda.actualizaPersona(this.contactoAModificar());
				this.llenarTabla();
				this.ventanaEdicion.dispose();
			}else Mensajes.lanzarMensajeInformativo("Debe completar al menos el nombre de contacto");
		}else if (e.getSource() == this.ventanaPersona.getBtnAgregarPersona()) {
			if(ventanaPersona.getTxtNombre().getText().equals("")==false){
			PersonaDTO nuevaPersona = new PersonaDTO(0, this.ventanaPersona
					.getTxtNombre().getText(), ventanaPersona.getTxtTelefono()
					.getText(), ventanaPersona.getTxtMail().getText(),
					ventanaPersona.getTxtCumplea�os(),
					ventanaPersona.getTipo(), ventanaPersona.getLocalidad(),
					ventanaPersona.getTxtCalle().getText(),
					ventanaPersona.getTxtAltura().getText(),
					ventanaPersona.getTxtPiso().getText(),
					ventanaPersona.getTxtDepto().getText(),
					Consultas.devuelveProvincia(Consultas.devuelveLocalidades(),ventanaPersona.getLocalidad()));

			System.out.println("Esta es la localidad elegida"+ventanaPersona.getLocalidad());
			System.out.println("Esta deberia ser la provincia devuelta"+Consultas.devuelveProvincia(Consultas.devuelveLocalidades(),ventanaPersona.getLocalidad()));
			this.agenda.agregarPersona(nuevaPersona);
			this.llenarTabla();
			this.ventanaPersona.dispose();
}else Mensajes.lanzarMensajeInformativo("Debe completar al menos el nombre del contacto");

		}
			}
	}


