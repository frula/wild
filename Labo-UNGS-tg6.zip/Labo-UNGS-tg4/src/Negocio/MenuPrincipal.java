package Negocio;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import modelo.Agenda;
import presentacion.controlador.Controlador;
import presentacion.vista.Conexion;
import presentacion.vista.Mensajes;
import presentacion.vista.Vista;
import PresentacionInt.ABMlocalidad;
import PresentacionInt.ABMtipo;

public class MenuPrincipal extends JFrame {

	private JPanel contentPane;
	private JMenuBar barra1;
    private JMenu configuracion;
    private JMenuItem seteo;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuPrincipal frame = new MenuPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MenuPrincipal() {
		
		setTitle("Menu principal");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 339, 197);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		 barra1 = new JMenuBar();
	        setJMenuBar(barra1);
	        configuracion = new JMenu("Configurar conexion a servidor");
	        barra1.add(configuracion);
	        seteo = new JMenuItem("Setear parametros de conexion");
	        seteo.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	Conexion conex=new Conexion();
	            	conex.setVisible(true);
	            }
	        });
	        configuracion.add(seteo);
		
		JButton btnAgenda = new JButton("Agenda");
		btnAgenda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(persistencia.conexion.Conexion.establecerConexion()==true){
				Vista vista = new Vista();
				Agenda modelo = new Agenda();
				Controlador controlador = new Controlador(vista, modelo);
				controlador.inicializar();
				}else Mensajes.lanzarMensajeInformativo("Fallo en la conexion. Verificar parametros");
				}
		});
		btnAgenda.setFont(new Font("Arial", Font.BOLD, 18));
		
		JButton btnLocalidad = new JButton("Localidades");
		btnLocalidad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(persistencia.conexion.Conexion.establecerConexion()==true){
				ABMlocalidad localidad=new ABMlocalidad();
				localidad.setVisible(true);	
				}else Mensajes.lanzarMensajeInformativo("Fallo en la conexion. Verificar parametros");
			}

				
		});
		btnLocalidad.setFont(new Font("Arial", Font.BOLD, 18));
		
		JButton btnTipo = new JButton("Categorias");
		btnTipo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(persistencia.conexion.Conexion.establecerConexion()==true){
				ABMtipo tipo = new ABMtipo();
				tipo.setVisible(true);
			}else Mensajes.lanzarMensajeInformativo("Fallo en la conexion. Verificar parametros");
		}

			
		});
		btnTipo.setFont(new Font("Arial", Font.BOLD, 18));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(btnAgenda, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE)
					.addGap(41)
					.addComponent(btnLocalidad, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(31))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(94)
					.addComponent(btnTipo, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(116))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAgenda, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnLocalidad, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addComponent(btnTipo, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(72, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
