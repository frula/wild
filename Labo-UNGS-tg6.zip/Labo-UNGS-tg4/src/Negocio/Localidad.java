package Negocio;

public class Localidad {
	private String localidad;
	private String Provincia;
	
	public Localidad(String localidad, String Provincia){
		this.localidad=localidad;
		this.Provincia=Provincia;
	}

	public String getLocalidad() {
		return localidad;
	}

	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}

	public String getProvincia() {
		return Provincia;
	}

	public void setProvincia(String provincia) {
		Provincia = provincia;
	}
	

}
