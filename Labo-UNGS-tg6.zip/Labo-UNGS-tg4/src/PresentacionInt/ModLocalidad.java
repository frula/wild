package PresentacionInt;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;

import persistencia.conexion.Conexion;
import persistencia.conexion.Consultas;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ModLocalidad extends JFrame {

	private JPanel contentPane;
	private JComboBox<String> cbProvincia;
	private JTextField texLocalidad;
	private JButton btnConfirmar;
	private JButton btnCancelar;
	private JLabel lblLocalidad;
	private JLabel lblProvincia;
	private String ProvinciaAmodidicar;
	private String LocalidadAmodificar;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModLocalidad frame = new ModLocalidad("","");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ModLocalidad(String localidadAmod, String ProvinciaAmod) {
		
		setTitle("Modificar localidad");
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 421, 223);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Modificar:");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 18));
		
		lblLocalidad = new JLabel("Localidad");
		lblLocalidad.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JLabel lblPor = new JLabel("por");
		lblPor.setFont(new Font("Arial", Font.PLAIN, 14));
		
		lblProvincia = new JLabel("Provincia");
		lblProvincia.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JLabel lblPor_1 = new JLabel("por");
		lblPor_1.setFont(new Font("Arial", Font.PLAIN, 14));
		
		cbProvincia = new JComboBox<String>();
		cbProvincia.setFont(new Font("Gungsuh", Font.BOLD, 12));
		
		btnConfirmar = new JButton("Confirmar");
		btnConfirmar.setFont(new Font("Arial", Font.BOLD, 12));
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					if(Consultas.LocalidadExistentemodyeli(texLocalidad.getText(), (String)cbProvincia.getSelectedItem())==false){
						Consultas.ModificarLocalidad(LocalidadAmodificar, texLocalidad.getText(), 
								ProvinciaAmodidicar, (String)cbProvincia.getSelectedItem()); 
						Consultas.ModificarLocalidadAgenda(LocalidadAmodificar, texLocalidad.getText());
						dispose();}
					else{
						JOptionPane.showMessageDialog(null, "La localidad ya esta registrada","Warning",JOptionPane.WARNING_MESSAGE);
	
					}
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Error");
					Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null,
							ex);
				}
		Conexion.establecerConexion();
			}
		});
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.setFont(new Font("Arial", Font.BOLD, 12));
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		
		texLocalidad = new JTextField();
		texLocalidad.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				desbloquear();
			}
		});
		texLocalidad.setFont(new Font("Gungsuh", Font.BOLD, 12));
		texLocalidad.setColumns(10);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 331, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblLocalidad)
								.addComponent(lblProvincia))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(btnConfirmar)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(btnCancelar))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblPor)
										.addComponent(lblPor_1))
									.addGap(24)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(texLocalidad, GroupLayout.DEFAULT_SIZE, 263, Short.MAX_VALUE)
										.addComponent(cbProvincia, 0, 263, Short.MAX_VALUE))))))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblLocalidad)
						.addComponent(lblPor)
						.addComponent(texLocalidad, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblProvincia)
						.addComponent(cbProvincia, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblPor_1))
					.addGap(34)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancelar)
						.addComponent(btnConfirmar))
					.addContainerGap(18, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		this.LocalidadAmodificar=localidadAmod;
		this.ProvinciaAmodidicar=ProvinciaAmod;
		inicializarProvincias();
		iniciar();
	}
	
	public void iniciar(){
		btnConfirmar.setEnabled(false);
		lblLocalidad.setText(LocalidadAmodificar);
		lblProvincia.setText(ProvinciaAmodidicar);
	}
	
	public void desbloquear(){
		boolean desbloqueo=true;
		if(texLocalidad.getText().equals("")){
			desbloqueo=false;
		}
		btnConfirmar.setEnabled(desbloqueo);
	}
	
	public void inicializarProvincias(){
		cbProvincia.addItem("Buenos Aires"); cbProvincia.addItem("Catamarca");
		cbProvincia.addItem("Chaco"); cbProvincia.addItem("Chubut");
		cbProvincia.addItem("C�rdoba"); cbProvincia.addItem("Corrientes");
		cbProvincia.addItem("Entre R�os"); cbProvincia.addItem("Formosa");
		cbProvincia.addItem("Jujuy"); cbProvincia.addItem("La Pampa");
		cbProvincia.addItem("La Rioja"); cbProvincia.addItem("Mendoza");
		cbProvincia.addItem("Misiones"); cbProvincia.addItem("Neuqu�n");
		cbProvincia.addItem("R�o Negro"); cbProvincia.addItem("Salta");
		cbProvincia.addItem("San Juan"); cbProvincia.addItem("San Luis");
		cbProvincia.addItem("Santa Cruz"); cbProvincia.addItem("Santa Fe");
		cbProvincia.addItem("Santiago del Estero"); cbProvincia.addItem("Tierra del Fuego");
		cbProvincia.addItem("Tucum�n");
	}
}
