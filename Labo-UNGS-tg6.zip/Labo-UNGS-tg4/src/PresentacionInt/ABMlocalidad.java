package PresentacionInt;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.ImageIcon;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JComboBox;

import persistencia.conexion.Conexion;
import persistencia.conexion.Consultas;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ABMlocalidad extends JFrame {

	private JPanel contentPane;
	private JTextField texlocalidad;
	private JButton btnAgregar;
	private JButton btnModificar;
	private JButton btnEliminar;
	private JComboBox<String> cbProvincia;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ABMlocalidad frame = new ABMlocalidad();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ABMlocalidad() {
		
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 398, 220);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblLocalidad = new JLabel("Localidades:");
		lblLocalidad.setForeground(new Color(0, 0, 0));
		lblLocalidad.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 22));
		
		JLabel lblProvincia = new JLabel("Localidad:");
		lblProvincia.setFont(new Font("Arial", Font.PLAIN, 16));
		
		JLabel lblLocalidad_1 = new JLabel("Provincia:");
		lblLocalidad_1.setFont(new Font("Arial", Font.PLAIN, 16));
		
		texlocalidad = new JTextField();
		texlocalidad.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent arg0) {
				desbloquear();
			}
		});
		texlocalidad.setFont(new Font("Gungsuh", Font.PLAIN, 12));
		texlocalidad.setColumns(10);
		
		btnAgregar = new JButton("Agregar");
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String loc=texlocalidad.getText();
				String prov=(String) cbProvincia.getSelectedItem();
				if(Consultas.LocalidadExistenteparaAgregar(loc, prov)==false){
					Consultas.AgregarLocalidad(loc, prov);
			}
				else{
					JOptionPane.showMessageDialog(null, "Registro existente","Warning",JOptionPane.WARNING_MESSAGE);
				}
	
			Conexion.establecerConexion();
			}

		});
		btnAgregar.setIcon(new ImageIcon(ABMlocalidad.class.getResource("/Imagenes/add-item.png")));
		
		btnModificar = new JButton("Modificar");
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String loc=texlocalidad.getText();
				String prov=(String) cbProvincia.getSelectedItem();
				if(Consultas.LocalidadExistentemodyeli(loc, prov)==true){
				ModLocalidad modificar= new ModLocalidad(loc,prov);
				modificar.setVisible(true);
				texlocalidad.setText("");
				}
				else{
					JOptionPane.showMessageDialog(null, "No se encontro registro","Warning",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnModificar.setIcon(new ImageIcon(ABMlocalidad.class.getResource("/Imagenes/edit.png")));
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String loc=texlocalidad.getText();
				String prov=(String) cbProvincia.getSelectedItem();
				if(Consultas.LocalidadExistentemodyeli(loc, prov)==true){
					Consultas.EliminarLocalidad(loc, prov);
			}
				else{
					JOptionPane.showMessageDialog(null, "No se encontro registro","Warning",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnEliminar.setIcon(new ImageIcon(ABMlocalidad.class.getResource("/Imagenes/delete-item.png")));
		
		cbProvincia = new JComboBox<String>();
		cbProvincia.setFont(new Font("Gungsuh", Font.BOLD, 12));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblLocalidad)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblLocalidad_1)
										.addComponent(lblProvincia))
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addComponent(cbProvincia, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(texlocalidad, GroupLayout.DEFAULT_SIZE, 243, Short.MAX_VALUE)))
								.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
									.addComponent(btnAgregar, GroupLayout.PREFERRED_SIZE, 103, GroupLayout.PREFERRED_SIZE)
									.addGap(18)
									.addComponent(btnModificar)
									.addGap(18)
									.addComponent(btnEliminar)))
							.addPreferredGap(ComponentPlacement.RELATED, 14, Short.MAX_VALUE)))
					.addGap(18))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblLocalidad)
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblProvincia)
						.addComponent(texlocalidad, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblLocalidad_1)
						.addComponent(cbProvincia, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAgregar, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnModificar, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnEliminar, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
		iniciar();
		inicializarProvincias();
	}
	
	public void iniciar(){
		btnAgregar.setEnabled(false);
		btnEliminar.setEnabled(false);
		btnModificar.setEnabled(false);
	}
	
	public void desbloquear(){
		boolean desbloqueo=true;
		if(texlocalidad.getText().equals("") ){
			desbloqueo=false;
		}
		btnAgregar.setEnabled(desbloqueo);
		btnModificar.setEnabled(desbloqueo);
		btnEliminar.setEnabled(desbloqueo);
	}
	
	public void inicializarProvincias(){
		cbProvincia.addItem("Buenos Aires"); cbProvincia.addItem("Catamarca");
		cbProvincia.addItem("Chaco"); cbProvincia.addItem("Chubut");
		cbProvincia.addItem("C�rdoba"); cbProvincia.addItem("Corrientes");
		cbProvincia.addItem("Entre R�os"); cbProvincia.addItem("Formosa");
		cbProvincia.addItem("Jujuy"); cbProvincia.addItem("La Pampa");
		cbProvincia.addItem("La Rioja"); cbProvincia.addItem("Mendoza");
		cbProvincia.addItem("Misiones"); cbProvincia.addItem("Neuqu�n");
		cbProvincia.addItem("R�o Negro"); cbProvincia.addItem("Salta");
		cbProvincia.addItem("San Juan"); cbProvincia.addItem("San Luis");
		cbProvincia.addItem("Santa Cruz"); cbProvincia.addItem("Santa Fe");
		cbProvincia.addItem("Santiago del Estero"); cbProvincia.addItem("Tierra del Fuego");
		cbProvincia.addItem("Tucum�n");
	}
}
