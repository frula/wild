package PresentacionInt;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;

import persistencia.conexion.Conexion;
import persistencia.conexion.Consultas;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ModTipo extends JFrame {

	private JPanel contentPane;
	private JTextField txtipo;
	private JLabel lblTipo;
	private JButton btnConfirmar;
	private JButton btnCancelar;
	private String TipoAmod;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModTipo frame = new ModTipo("");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ModTipo(String tipoamod) {
		
		setTitle("Modificar categoria de contacto");
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 332, 176);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblModificarTipo = new JLabel("Modificar Categoria:");
		lblModificarTipo.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 23));
		
		lblTipo = new JLabel("Tipo");
		lblTipo.setFont(new Font("Arial", Font.BOLD, 16));
		
		JLabel lblNewLabel = new JLabel("por");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 16));
		
		txtipo = new JTextField();
		txtipo.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				desbloquear();
			}
		});
		txtipo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		txtipo.setFont(new Font("Gungsuh", Font.BOLD, 14));
		txtipo.setColumns(10);
		
		btnConfirmar = new JButton("Confirmar");
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Consultas.ModificarTipo(TipoAmod, txtipo.getText());
				Consultas.ModificarTipoAgenda(TipoAmod, txtipo.getText());
				try {
					if(Consultas.TipoExistenteparaModyEli(TipoAmod)==false){
						Consultas.ModificarTipo(TipoAmod, txtipo.getText());
						dispose();}
					else{
						JOptionPane.showMessageDialog(null, "El tipo ya esta registrado","Warning",JOptionPane.WARNING_MESSAGE);
	
					}
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Error");
					Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null,
							ex);
				}
			Conexion.establecerConexion();
			}
		});
		btnConfirmar.setFont(new Font("Arial", Font.BOLD, 14));
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnCancelar.setFont(new Font("Arial", Font.BOLD, 14));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblModificarTipo)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblTipo)
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(btnConfirmar)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(btnCancelar))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblNewLabel)
									.addGap(18)
									.addComponent(txtipo, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE)))))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblModificarTipo)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTipo)
						.addComponent(lblNewLabel)
						.addComponent(txtipo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(27)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnConfirmar)
						.addComponent(btnCancelar))
					.addContainerGap(34, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		this.TipoAmod=tipoamod;
		iniciar();
	}

	public void iniciar(){
		btnConfirmar.setEnabled(false);
		lblTipo.setText(TipoAmod);
	}
	public void desbloquear(){
		boolean desbloqueo=true;
		if(txtipo.getText().equals("")){
			desbloqueo=false;
		}
		btnConfirmar.setEnabled(desbloqueo);
	}
}
