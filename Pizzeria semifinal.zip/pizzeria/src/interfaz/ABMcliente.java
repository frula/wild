package interfaz;

import com.mxrck.autocompleter.*;

import datos.Pizzeria;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import negocio.Cliente;

import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import net.miginfocom.swing.MigLayout;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class ABMcliente extends javax.swing.JFrame {

    ArrayList <Cliente> clientes= Pizzeria.devuelveTodosLosClientes();
    boolean modificado=false;
    int id=clientes.size()+1;
    public ABMcliente() {
    	setResizable(false);
        initComponents();
        inicio();
        
        
       /* final TextAutoCompleter busqueda = new TextAutoCompleter(txbuscar);
		for (int i = 0; i < clientes.size(); i++) {

			busqueda.addItem(clientes.get(i).getNombreCliente());
		}*/
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txbuscar = new javax.swing.JTextField();
        txbuscar.setBackground(Color.CYAN);
        txbuscar.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent arg0) {
        	txbuscar.setText("");
        	txnombre.setText("");
        	txdir.setText("");
        	txdni.setText("");
        	txtel.setText("");
        	}
        });

        txbuscar.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent arg0) {
        		TextAutoCompleter busqueda = new TextAutoCompleter(txbuscar);
                if(modificado==true){
        			busqueda.removeAllItems();
        			
        			modificado=false;
        			txbuscar.setText("");
        		}
                else if(modificado==false){
        		for (int i = 0; i < clientes.size(); i++) {
        			busqueda.addItem(clientes.get(i).toString());
        			
        		}}
        		
        		
        	}
        	@Override
        	public void keyReleased(KeyEvent arg0) {
        		
        	}
        	@Override
        	public void keyPressed(KeyEvent arg0) {
        		
        	}
        });
        lbdni = new javax.swing.JLabel();
        lbnombre = new javax.swing.JLabel();
        lbdir = new javax.swing.JLabel();
        lbtel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setName("panel"); // NOI18N

        jLabel1.setFont(new Font("Rod", Font.PLAIN, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Cliente");

     
        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1Layout.setHorizontalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(jLabel2, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
        			.addPreferredGap(ComponentPlacement.RELATED, 294, Short.MAX_VALUE)
        			.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.LEADING)
        		.addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE)
        		.addGroup(Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(jLabel1, GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE))
        );
        jPanel1.setLayout(jPanel1Layout);

        txbuscar.setText("Ingrese DNI cliente");
        txbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txbuscarActionPerformed(evt);
            }
        });

        lbdni.setText("DNI:");

        lbnombre.setText("Nombre:");

        lbdir.setText("Direccion:");

        lbtel.setText("Telefono:");
        getContentPane().setLayout(new MigLayout("", "[35px][14.00px][30px][18px][6px][18px][10px][7px][136.00px][136.00px]", "[51px][23px][34.00px][31.00px][33.00px][34.00px][20px]"));
        txdni = new javax.swing.JTextField();
        
                txdni.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        txdniActionPerformed(evt);
                    }
                });
                txdni.addKeyListener(new java.awt.event.KeyAdapter() {
                    public void keyReleased(java.awt.event.KeyEvent evt) {
                        txdniKeyReleased(evt);
                    }
                    public void keyTyped(java.awt.event.KeyEvent evt) {
                        txdniKeyTyped(evt);
                    }
                });
                btmod = new javax.swing.JButton();
                
                        btmod.setText("Modificar");
                        btmod.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btmodActionPerformed(evt);
                            }
                        });
                        btbuscar = new javax.swing.JButton();
                        
                                btbuscar.setText("Buscar");
                                btbuscar.addActionListener(new java.awt.event.ActionListener() {
                                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                                        btbuscarActionPerformed(evt);
                                    }
                                });
                                getContentPane().add(btbuscar, "cell 0 1 5 1,growx,aligny center");
                        checkhab = new javax.swing.JCheckBox();
                        
                                checkhab.setText("Habilitado");
                                checkhab.addActionListener(new java.awt.event.ActionListener() {
                                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                                        checkhabActionPerformed(evt);
                                    }
                                });
                                getContentPane().add(checkhab, "cell 0 2 5 1,alignx left,aligny center");
                        getContentPane().add(btmod, "cell 8 2,growx,aligny center");
                getContentPane().add(txdni, "cell 2 3 5 1,growx,aligny center");
                btsalir = new javax.swing.JButton();
                btsalir.setVisible(false);
                
                        btsalir.setText("Salir");
                        btsalir.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btsalirActionPerformed(evt);
                            }
                        });
                        getContentPane().add(btsalir, "flowx,cell 8 3");
        btbloquear = new javax.swing.JButton();
        
        
                btbloquear.setText("Bloqueo/Desbloqueo");
                btbloquear.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        btbloquearActionPerformed(evt);
                    }
                });
                getContentPane().add(btbloquear, "cell 9 3,growx,aligny center");
        getContentPane().add(lbtel, "flowx,cell 0 6 3 1,alignx left,aligny center");
        getContentPane().add(lbdni, "cell 0 3,alignx left,aligny center");
        getContentPane().add(lbnombre, "flowx,cell 0 4 3 1,alignx left,aligny center");
        getContentPane().add(lbdir, "flowx,cell 0 5 3 1,alignx left,aligny center");
        getContentPane().add(txbuscar, "cell 5 1 5 1,growx,aligny center");
        getContentPane().add(jPanel1, "cell 0 0 10 1,growx,aligny top");
        txnombre = new javax.swing.JTextField();
        
                txnombre.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        txnombreActionPerformed(evt);
                    }
                });
                txnombre.addKeyListener(new java.awt.event.KeyAdapter() {
                    public void keyReleased(java.awt.event.KeyEvent evt) {
                        txnombreKeyReleased(evt);
                    }
                    public void keyTyped(java.awt.event.KeyEvent evt) {
                        txnombreKeyTyped(evt);
                    }
                });
                getContentPane().add(txnombre, "cell 2 4 8 1,growx,aligny center");
                txdir = new javax.swing.JTextField();
                
                        txdir.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txdirActionPerformed(evt);
                            }
                        });
                        txdir.addKeyListener(new java.awt.event.KeyAdapter() {
                            public void keyReleased(java.awt.event.KeyEvent evt) {
                                txdirKeyReleased(evt);
                            }
                            public void keyTyped(java.awt.event.KeyEvent evt) {
                                txdirKeyTyped(evt);
                            }
                        });
                        getContentPane().add(txdir, "cell 2 5 8 1,growx,aligny center");
                        txtel = new javax.swing.JTextField();
                        
                                txtel.addActionListener(new java.awt.event.ActionListener() {
                                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                                        txtelActionPerformed(evt);
                                    }
                                });
                                txtel.addKeyListener(new java.awt.event.KeyAdapter() {
                                    public void keyReleased(java.awt.event.KeyEvent evt) {
                                        txtelKeyReleased(evt);
                                    }
                                    public void keyTyped(java.awt.event.KeyEvent evt) {
                                        txtelKeyTyped(evt);
                                    }
                                });
                                getContentPane().add(txtel, "cell 2 6 5 1,growx,aligny center");
                                btagregar = new javax.swing.JButton();
                                
                                
                                        btagregar.setText("Confirmar Nuevo");
                                        btagregar.addActionListener(new java.awt.event.ActionListener() {
                                            public void actionPerformed(java.awt.event.ActionEvent evt) {
                                                btagregarActionPerformed(evt);
                                            }
                                        });
                                        getContentPane().add(btagregar, "flowx,cell 8 6 2 1,growx,aligny top");
                                                                btnuevo = new javax.swing.JButton();
                                                                
                                                                        btnuevo.setText("Nuevo");
                                                                        btnuevo.addActionListener(new java.awt.event.ActionListener() {
                                                                            public void actionPerformed(java.awt.event.ActionEvent evt) {
                                                                                btnuevoActionPerformed(evt);
                                                                            }
                                                                        });
                                                                        getContentPane().add(btnuevo, "cell 9 2,growx,aligny center");

        jPanel1.getAccessibleContext().setAccessibleName("panel");

        pack();
    }// </editor-fold>                        

    void inicio(){
        checkhab.setEnabled(false);
        checkhab.setSelected(true);
        btbloquear.setEnabled(false);
        btmod.setEnabled(false);
    }
    
    void actualizar(){
 	   this.clientes=Pizzeria.devuelveTodosLosClientes();
 	   modificado=true;
    }
    
    void desbloquearGuardar(){
        boolean desbloqueo=true;
        if(txdni.getText().equals("")){
            desbloqueo=false;}
        else if(txtel.getText().equals("")){
            desbloqueo=false;}
        else if(txdir.getText().equals("")){
            desbloqueo=false;}
        else if(txnombre.getText().equals("")){
            desbloqueo=false;
        }
        else if(btbloquear.isEnabled()==true || btmod.isEnabled()==true){
            desbloqueo=false;
        }
        else{
            desbloqueo=true;}
        btagregar.setEnabled(desbloqueo);
        }
    
    private void txbuscarActionPerformed(java.awt.event.ActionEvent evt) {    
    	

    }                                        

    private void txdniActionPerformed(java.awt.event.ActionEvent evt) {                                      
        if(txdni.getText().equals("")){
            txdni.requestFocus();
        }
        else{
            txdni.transferFocus(); 
        }
    }                                     

    private void txtelActionPerformed(java.awt.event.ActionEvent evt) {                                      
        if(txtel.getText().equals("")){
            txtel.requestFocus();
        }
        else{
            txtel.transferFocus(); 
        }
    }                                     

    private void btsalirActionPerformed(java.awt.event.ActionEvent evt) {                                        
        dispose();        
    }                                       

    private void btagregarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        String dni=txdni.getText();
        String tel=txtel.getText();
        id=id++;
        //System.out.println(id);
        Cliente cli = new Cliente(id,txnombre.getText().toUpperCase(),dni,txdir.getText(),tel,0);
        Pizzeria.AgregarCliente(cli);
        actualizar();
        txnombre.setText("");
        txdir.setText("");
        txdni.setText("");
        txtel.setText("");
        
        
    }                                         

    private void btbloquearActionPerformed(java.awt.event.ActionEvent evt) {                                           
        int act;
        if(checkhab.isSelected()){act=1; checkhab.setSelected(false);}
        else{act=0; checkhab.setSelected(true);}
        int dni=Integer.parseInt(txdni.getText());
        Pizzeria.bloquearcliente(act,dni );
        btbloquear.setEnabled(false);
        txbuscar.setText("");
        txnombre.setText("");
        txdir.setText("");
        txdni.setText("");
        txtel.setText("");
        actualizar();
    }                                          

    private void btmodActionPerformed(java.awt.event.ActionEvent evt) {    
    	
        int dni=Integer.parseInt(txdni.getText());
        int tel=Integer.parseInt(txtel.getText());
        String nombre=txnombre.getText().toUpperCase();
        Pizzeria.modificarcliente(dni,nombre,txdir.getText(),tel);
        txnombre.setEnabled(true);
        txnombre.setText("");
        txdni.setText("");
        txdir.setText("");
        btmod.setEnabled(false);
        btbloquear.setEnabled(false);
        txtel.setText("");
        txbuscar.setText("");
        actualizar();
    }                                     

    private void txnombreActionPerformed(java.awt.event.ActionEvent evt) {                                         
        if(txnombre.getText().equals("")){
            txnombre.requestFocus();
        }
        else{
            txnombre.transferFocus(); 
        }
    }                                        

    private void txdirActionPerformed(java.awt.event.ActionEvent evt) {                                      
        if(txdir.getText().equals("")){
            txdir.requestFocus();
        }
        else{
            txdir.transferFocus(); 
        }
    }                                     

    private void checkhabActionPerformed(java.awt.event.ActionEvent evt) {                                         
    }                                        

    private void btbuscarActionPerformed(java.awt.event.ActionEvent evt) {                                         
        if(txbuscar.getText().equals("")==false&&txbuscar.getText().equals(null)==false){
        String busqueda = txbuscar.getText().toUpperCase();
        for(int i=0;i<clientes.size();i++){
            if(busqueda.equals(clientes.get(i).getDni())){
                txdni.setText(String.valueOf(clientes.get(i).getDni()));
                txdir.setText(clientes.get(i).getDireccion());
                txtel.setText(String.valueOf(clientes.get(i).getTelefono()));
                txnombre.setText(clientes.get(i).getNombreCliente());
                if(clientes.get(i).getActivo()==1){checkhab.setSelected(false);}
                else{checkhab.setSelected(true);}
                btbloquear.setEnabled(true);
                btmod.setEnabled(true);
                btagregar.setEnabled(false);
                txdni.setEnabled(false);
            }
        }
  
        }
    }                                        

    private void btnuevoActionPerformed(java.awt.event.ActionEvent evt) {                                        
  
    	txdir.setText("");
        btagregar.setEnabled(true);   
    	checkhab.setSelected(true);
            txdni.setEnabled(true);
            txdni.setText("");
            txnombre.setText("");
            txtel.setText("");
            btbloquear.setEnabled(false);
            btmod.setEnabled(false);
           
            txnombre.setEnabled(true);
            txbuscar.setText("Ingrese nombre de cliente");
            // TODO add your handling code here:
            
    }                                       

    private void txdniKeyReleased(java.awt.event.KeyEvent evt) {                                  
        if(!txdni.getText().matches("[0-9--]*")){
            JOptionPane.showMessageDialog(null, "Solo valores num�ricos","Advertencia",JOptionPane.ERROR_MESSAGE);
            txdni.setText("");
        }        // TODO add your handling code here:
    }                                 

    private void txtelKeyReleased(java.awt.event.KeyEvent evt) {                                  
        if(!txtel.getText().matches("[0-9--]*")){
            JOptionPane.showMessageDialog(null, "Solo valores num�ricos","Advertencia",JOptionPane.ERROR_MESSAGE);
            txtel.setText("");
        }        // TODO add your handling code here:
    }                                 

    private void txdniKeyTyped(java.awt.event.KeyEvent evt) {                               
         desbloquearGuardar();
    }                              

    private void txnombreKeyTyped(java.awt.event.KeyEvent evt) {                                  
        desbloquearGuardar();// TODO add your handling code here:
    }                                 

    private void txdirKeyTyped(java.awt.event.KeyEvent evt) {                               
        desbloquearGuardar();// TODO add your handling code here:
    }                              

    private void txtelKeyTyped(java.awt.event.KeyEvent evt) {                               
        desbloquearGuardar();// TODO add your handling code here:
    }                              

    private void txnombreKeyReleased(java.awt.event.KeyEvent evt) {                                     
        // TODO add your handling code here:
    }                                    

    private void txdirKeyReleased(java.awt.event.KeyEvent evt) {                                  
        // TODO add your handling code here:
    }                                 

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ABMcliente dialog = new ABMcliente();
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton btagregar;
    private javax.swing.JButton btbloquear;
    private javax.swing.JButton btbuscar;
    private javax.swing.JButton btmod;
    private javax.swing.JButton btnuevo;
    private javax.swing.JButton btsalir;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JCheckBox checkhab;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbdir;
    private javax.swing.JLabel lbdni;
    private javax.swing.JLabel lbnombre;
    private javax.swing.JLabel lbtel;
    private javax.swing.JTextField txbuscar;
    private javax.swing.JTextField txdir;
    private javax.swing.JTextField txdni;
    private javax.swing.JTextField txnombre;
    private javax.swing.JTextField txtel;
    // End of variables declaration                   
}
