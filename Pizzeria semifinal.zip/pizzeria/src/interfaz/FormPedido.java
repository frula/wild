package interfaz;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import negocio.Cliente;
import negocio.Combo;
import negocio.DetallePedido;
import negocio.Pedido;
import negocio.Producto;

import com.mxrck.autocompleter.TextAutoCompleter;

import datos.Basededatos;
import datos.Busqueda;
import datos.Pizzeria;

import javax.swing.UIManager;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import com.toedter.calendar.JDateChooser;

public class FormPedido extends JFrame implements ActionListener {

	private JMenuBar mbar;
	private JMenu opciones;
	private JMenuItem buscarPedido;
	private Pedido pedidoActivo;
	private JTextField pedido;
	private JTextField fechaPedido;
	private JTextField cliente;
	private JTextField dni;
	private JTextField direccion;
	private JTextField telefono;
	private JTextField producto;
	private JTextField precio;
	private Producto productoSeleccionado;
	private Cliente clienteSeleccionado;
	private DetallePedido linea;
	private ArrayList<DetallePedido> lineasPedido;
	private JTextField total;
	private Double totalPedido;
	private Integer cantidad;
	private Double precioUnitario;
	private Double totalLinea;
	private String numeroPed;
	private JTextField txbuscar;
	private JDateChooser calendario;
	ArrayList<Pedido> pedidos=Pizzeria.devuelvepedido();
	
	public FormPedido() {
		getContentPane().setForeground(UIManager.getColor("Button.light"));
		setResizable(false);
		getContentPane().setBackground(UIManager.getColor("Button.light"));
		setTitle("Pedidos");
		setSize(new Dimension(910, 561));

		// Creo el menu contenedor
		mbar = new JMenuBar();
		mbar.setBackground(new Color(102, 102, 153));
		setJMenuBar(mbar);

		// Creo el menu principal
		opciones = new JMenu("Opciones de pedido");
		mbar.add(opciones);
		buscarPedido = new JMenuItem("Consultar pedido");
		buscarPedido.addActionListener(this);
		opciones.add(buscarPedido);

		JLabel lblCliente = new JLabel("Cliente");
		lblCliente.setFont(new Font("SansSerif", Font.BOLD, 12));
		lblCliente.setForeground(UIManager.getColor("Button.focus"));

		pedido = new JTextField();
		pedido.setHorizontalAlignment(SwingConstants.CENTER);
		pedido.setEnabled(false);
		pedido.setColumns(10);

		JLabel lblpedido = new JLabel("Pedido");
		lblpedido.setFont(new Font("SansSerif", Font.BOLD, 12));
		lblpedido.setForeground(UIManager.getColor("Button.focus"));

		fechaPedido = new JTextField();
		fechaPedido.setHorizontalAlignment(SwingConstants.CENTER);
		fechaPedido.setEnabled(false);
		fechaPedido.setColumns(10);

		JLabel lblFecha = new JLabel("Fecha:");
		lblFecha.setFont(new Font("SansSerif", Font.BOLD, 12));
		lblFecha.setForeground(UIManager.getColor("Button.focus"));

		JLabel lblProducto = new JLabel("Producto");
		lblProducto.setFont(new Font("SansSerif", Font.BOLD, 12));
		lblProducto.setForeground(UIManager.getColor("Button.focus"));

		JButton btnAgregarproducto = new JButton("AgregarProducto");

		JButton btnEliminarproducto = new JButton("QuitarProducto");

		cliente = new JTextField();
		cliente.setBackground(new Color(0, 255, 255));
		cliente.setColumns(10);

		JLabel lblDNI = new JLabel("DNI");
		lblDNI.setFont(new Font("SansSerif", Font.BOLD, 12));
		lblDNI.setForeground(UIManager.getColor("Button.focus"));

		dni = new JTextField();
		dni.setEnabled(false);
		dni.setColumns(10);

		JLabel lbldireccion = new JLabel("Direccion");
		lbldireccion.setFont(new Font("SansSerif", Font.BOLD, 12));
		lbldireccion.setForeground(UIManager.getColor("Button.focus"));

		direccion = new JTextField();
		direccion.setEnabled(false);
		direccion.setColumns(10);

		JLabel lblTelefono = new JLabel("Tel\u00E9fono");
		lblTelefono.setFont(new Font("SansSerif", Font.BOLD, 12));
		lblTelefono.setForeground(UIManager.getColor("Button.focus"));

		telefono = new JTextField();
		telefono.setEnabled(false);
		telefono.setColumns(10);

		final JCheckBox delivery = new JCheckBox("Delivery");
		delivery.setBackground(new Color(0, 255, 255));
		delivery.setFont(new Font("SansSerif", Font.BOLD, 12));
		delivery.setForeground(new Color(0, 0, 0));

		producto = new JTextField();
		producto.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent arg0) {
			
				//producto.setText(""); 
				
			}
		});
		producto.setBackground(new Color(0, 255, 255));
		producto.setColumns(10);

		precio = new JTextField();
		precio.setHorizontalAlignment(SwingConstants.CENTER);
		precio.setEnabled(false);
		precio.setColumns(10);

		JLabel lblPrecio = new JLabel("Precio");
		lblPrecio.setFont(new Font("SansSerif", Font.BOLD, 12));
		lblPrecio.setForeground(UIManager.getColor("Button.focus"));

		// Defino la tabla de detalle y sus campos
		JScrollPane scrollPane = new JScrollPane();
		final JTable tabdet = new JTable();
		final DefaultTableModel datostabla = new DefaultTableModel();

		String[] columna = new String[] { "Cod", "Producto", "Cant.", "Precio",
				"Tot.linea", "Observacion" };
		datostabla.setColumnIdentifiers(columna);
		tabdet.setModel(datostabla);
		scrollPane.setViewportView(tabdet);

		tabdet.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {

				if (tabdet.getValueAt(tabdet.getSelectedRow(), 2) != null
						&& tabdet.getValueAt(tabdet.getSelectedRow(), 3) != null) {
					cantidad = Integer.valueOf(String.valueOf(tabdet
							.getValueAt(tabdet.getSelectedRow(), 2)));
					precioUnitario = Double.valueOf(String.valueOf(tabdet
							.getValueAt(tabdet.getSelectedRow(), 3)));

					totalLinea = cantidad * precioUnitario;

					tabdet.setValueAt(totalLinea, tabdet.getSelectedRow(), 4);

					totalPedido = 0.0;
					for (int i = 0; i < datostabla.getRowCount(); i++) {

						totalPedido = totalPedido
								+ Double.valueOf(String.valueOf(tabdet
										.getValueAt(i, 4)));

					}
					total.setText(String.valueOf(totalPedido));
				}

			}
		});
		
		

		// Agregar producto al pedido
		btnAgregarproducto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// verifico primero si no esta el item cargado ya
				
				int repetido = 0;
				int fila = 0;
				for (int j = 0; j < tabdet.getRowCount(); j++) {

					// Verifico si es un combo
					if (productoSeleccionado instanceof Combo) {
						Combo comboSeleccionado = (Combo) productoSeleccionado;
						if (tabdet.getValueAt(j, 0).equals(
								comboSeleccionado.getIdCombo())) {

							repetido = 1;
							fila = j;
						}
					} else if (productoSeleccionado instanceof Producto) {

						if (tabdet.getValueAt(j, 0).equals(
								productoSeleccionado.getIdProducto())) {

							repetido = 1;
							fila = j;
						}

					}
				}
				// Cargo el item nuevo
				if (repetido == 0 && productoSeleccionado instanceof Combo) {
					System.out.println("entroCombo");
					Combo comboSeleccionado = (Combo) productoSeleccionado;
					datostabla.addRow(new Object[] {

					comboSeleccionado.getIdCombo(),
							comboSeleccionado.getNombreCombo(), 1,
							comboSeleccionado.getPrecioCombo(), null, null });

				} else if (repetido == 1) {
					System.out.println("entro nulo");
					Integer valorAnterior = 0;
					valorAnterior = Integer.valueOf(String.valueOf(tabdet
							.getValueAt(fila, 2))) + 1;
					datostabla.setValueAt(valorAnterior, fila, 2);

				} else if (repetido == 0
						&& productoSeleccionado instanceof Producto) {

					System.out.println("entro producto");
					datostabla.addRow(new Object[] {

					productoSeleccionado.getIdProducto(),
							productoSeleccionado.getNombre(), 1,
							productoSeleccionado.getPrecio(), null, null });

				}
				// Actualizo el total

				for (int l = 0; l < tabdet.getRowCount(); l++) {

					totalLinea = Integer.valueOf(String.valueOf(tabdet
							.getValueAt(l, 2)))
							* Double.valueOf(String.valueOf(tabdet.getValueAt(
									l, 3)));
					tabdet.setValueAt(totalLinea, l, 4);

				}
				totalPedido = 0.0;
				for (int i = 0; i < datostabla.getRowCount(); i++) {

					totalPedido = totalPedido
							+ Double.valueOf(String.valueOf(tabdet.getValueAt(
									i, 4)));

				}
				total.setText(String.valueOf(totalPedido));
					}
		});

		// Cargo las busquedas

		final TextAutoCompleter clientes = new TextAutoCompleter(cliente);
		for (int i = 0; i < Pizzeria.devuelveClientes().size(); i++) {

			clientes.addItem(Pizzeria.devuelveClientes().get(i));

		}

		final TextAutoCompleter productos = new TextAutoCompleter(producto);
		for (int i = 0; i < Pizzeria.devuelveProductos().size(); i++) {
			productos.addItem(Pizzeria.devuelveProductos().get(i));
		}
		
		
	
		// Defino la fecha del dia
		fechaPedido.setText(Basededatos.dateToMySQLDate2(new Date()));

		JLabel lblTot = new JLabel("Total:");
		lblTot.setForeground(UIManager.getColor("Button.focus"));
		lblTot.setFont(new Font("SansSerif", Font.BOLD, 12));

		total = new JTextField();
		total.setHorizontalAlignment(SwingConstants.CENTER);
		total.setEnabled(false);
		total.setColumns(10);

		final JButton btconfirmar = new JButton("Confirmar");

		JButton btnuevo = new JButton("Nuevo Pedido");
		btnuevo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txbuscar.setEnabled(true);
				cliente.setEnabled(true);
				cliente.setText("");
				producto.setEnabled(true);
				producto.setText("");
				pedido.setText("");
				dni.setText("");
				precio.setText("");
				direccion.setText("");
				delivery.setEnabled(true);
				delivery.setSelected(false);
				tabdet.setEnabled(true);
				int total=tabdet.getRowCount();
		        for (int i = total-1; i >= 0; i--) {
		             datostabla.removeRow(i);
		            }
				
			}
		});
		
		JButton btbuscar = new JButton("Buscar");
		btbuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ArrayList<Pedido> pedidos=Pizzeria.devuelvepedido();
				ArrayList<Cliente> clientes=Pizzeria.devuelveTodosLosClientes();
				ArrayList<DetallePedido>detalle=Pizzeria.devuelvedetallepedido();
				ArrayList<Producto>productos=Pizzeria.devuelveProductos();
				if(!txbuscar.equals("") 
						&& calendario.getDate()!=null){
				
				int t=tabdet.getRowCount();
		        for (int i = t-1; i >= 0; i--) {
		             datostabla.removeRow(i);
		            }
		        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		        Date date = calendario.getDate();
		        String fecha=format.format(date);
		        
				for(int i=0;i<pedidos.size();i++){

				if(txbuscar.getText().equals(pedidos.get(i).getNumeroPedido()) &&
						fecha.equals(pedidos.get(i).getFechaPedido())){
					
					pedido.setText(pedidos.get(i).getIdPedido());
					fechaPedido.setText(pedidos.get(i).getFechaPedido());
					total.setText(String.valueOf(pedidos.get(i).getTotalPedido()));
					
					if(pedidos.get(i).getAdomicilio()==true){delivery.setSelected(true);}
					else{delivery.setSelected(false);}
					
					for(int j=0;j<clientes.size();j++){
						if(pedidos.get(i).getIdcliente()==clientes.get(j).getIdCliente()){
							telefono.setText(clientes.get(j).getTelefono());
							cliente.setText(clientes.get(j).getNombreCliente());
							dni.setText(clientes.get(j).getDni());
							direccion.setText(clientes.get(j).getDireccion());
						}
					}
					
					
					for(int h=0;h<detalle.size();h++){
                        String pro = null;
                        String idped= String.valueOf(pedidos.get(i).getIdPedido());
                        double precio = 0;
                        if(idped.equals(detalle.get(h).getIdPedido())){
                            Double tot=pedidos.get(i).getTotalPedido();
                            
                            for(int k=0;k<productos.size();k++){
                                if(detalle.get(h).getidproducto()==productos.get(k).getIdProducto()){
                                    pro=productos.get(k).getNombre();
                                    precio=productos.get(k).getPrecio();
                                }
                            }
                            Double tot3=detalle.get(h).getCantidad()*precio;
                            datostabla.addRow(new Object[] {

				detalle.get(h).getidproducto(),
						pro, detalle.get(h).getCantidad(),
						precio, tot3, detalle.get(h).getObservacion() });
                        }
					}
					
				}
				}
				txbuscar.setEnabled(false);
				btconfirmar.setEnabled(false);
				cliente.setEnabled(false);
				producto.setText("");
			}
			else{
					JOptionPane.showMessageDialog(null,
							"Complete los campos para busqueda");
				}
			}
			
			
		});
		
		txbuscar = new JTextField();
		txbuscar.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent arg0) {
				final TextAutoCompleter buscar = new TextAutoCompleter(txbuscar);
				for (int i = 0; i < Pizzeria.devuelvepedido().size(); i++) {
					buscar.addItem(Pizzeria.devuelvepedido().get(i).getNumeroPedido());
				}
			}
		});
		txbuscar.setText("Ingrese Nro Pedido");
		txbuscar.setColumns(10);
		
		JButton btmodificar = new JButton("Modificar");
		btmodificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
ArrayList<DetallePedido>detalle=Pizzeria.devuelvedetallepedido();
				
				int dc;
				if(delivery.isSelected()){dc=1;}
				else{dc=0;}
				
		        int idp = 0;
		        String id=pedido.getText();
		        Double tot=Double.valueOf(total.getText());  
		        
		        Pizzeria.modificarpedido(id,tot,dc);
		        for(int i=0;i<detalle.size();i++){
		            if(id.equals(detalle.get(i).getIdPedido())){
		                //for(int k=0;k<productos.size();k++){
		            	Pizzeria.eliminardetalle(id);
		                    for (int j=0;j<tabdet.getRowCount();j++){ 
		                  //  if(productos.get(k).getNombre()==String.valueOf(tabdet.getValueAt(j, 1))){
		                        idp=Integer.valueOf(String.valueOf(tabdet.getValueAt(j, 0)));
		                        int cant=Integer.valueOf(String.valueOf(tabdet.getValueAt(j, 2)));
		                        String ob = String.valueOf(tabdet.getValueAt(j, 5));
		                        
		                        DetallePedido deta = new DetallePedido(id,txbuscar.getText(),idp,cant,ob);
		                        Pizzeria.agregarDetallePedido(deta);
		                        
		                        }
		                    }
		                }
		        
		        pedidos=Pizzeria.devuelvepedido();
			
			}
		});
		
		calendario = new JDateChooser();
		calendario.setDateFormatString("yyyy-MM-dd");
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(26)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblDNI, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
							.addGap(29)
							.addComponent(dni, GroupLayout.PREFERRED_SIZE, 129, GroupLayout.PREFERRED_SIZE)
							.addGap(12)
							.addComponent(lblTelefono, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE)
							.addGap(27)
							.addComponent(telefono, GroupLayout.PREFERRED_SIZE, 129, GroupLayout.PREFERRED_SIZE)
							.addGap(74)
							.addComponent(delivery, GroupLayout.PREFERRED_SIZE, 122, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblProducto, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE)
							.addGap(12)
							.addComponent(producto, GroupLayout.PREFERRED_SIZE, 354, GroupLayout.PREFERRED_SIZE)
							.addGap(5)
							.addComponent(lblPrecio, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
							.addGap(29)
							.addComponent(precio, GroupLayout.PREFERRED_SIZE, 74, GroupLayout.PREFERRED_SIZE)
							.addGap(12)
							.addComponent(btnAgregarproducto, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE)
							.addGap(6)
							.addComponent(btnEliminarproducto, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE))
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 847, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(btnuevo, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(btconfirmar, GroupLayout.PREFERRED_SIZE, 90, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btmodificar, GroupLayout.PREFERRED_SIZE, 83, GroupLayout.PREFERRED_SIZE)
							.addGap(347)
							.addComponent(lblTot, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
							.addGap(15)
							.addComponent(total, GroupLayout.PREFERRED_SIZE, 104, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(lblCliente, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE)
									.addGap(12)
									.addComponent(cliente, GroupLayout.PREFERRED_SIZE, 354, GroupLayout.PREFERRED_SIZE)
									.addGap(5)
									.addComponent(lbldireccion, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE))
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(lblpedido, GroupLayout.PREFERRED_SIZE, 63, GroupLayout.PREFERRED_SIZE)
									.addGap(4)
									.addComponent(pedido, GroupLayout.PREFERRED_SIZE, 129, GroupLayout.PREFERRED_SIZE)
									.addGap(36)
									.addComponent(lblFecha, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE)
									.addGap(12)
									.addComponent(fechaPedido, GroupLayout.PREFERRED_SIZE, 122, GroupLayout.PREFERRED_SIZE)))
							.addGap(12)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(calendario, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(txbuscar, GroupLayout.PREFERRED_SIZE, 107, GroupLayout.PREFERRED_SIZE)
									.addGap(10)
									.addComponent(btbuscar, GroupLayout.PREFERRED_SIZE, 89, GroupLayout.PREFERRED_SIZE))
								.addComponent(direccion, GroupLayout.PREFERRED_SIZE, 354, GroupLayout.PREFERRED_SIZE)))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addComponent(lblpedido))
						.addComponent(pedido, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addComponent(lblFecha))
						.addComponent(fechaPedido, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
						.addComponent(btbuscar)
						.addComponent(txbuscar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(calendario, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(12)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addComponent(lblCliente))
						.addComponent(cliente, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addComponent(lbldireccion))
						.addComponent(direccion, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE))
					.addGap(12)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addComponent(lblDNI))
						.addComponent(dni, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addComponent(lblTelefono))
						.addComponent(telefono, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(5)
							.addComponent(delivery, GroupLayout.PREFERRED_SIZE, 18, GroupLayout.PREFERRED_SIZE)))
					.addGap(12)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addComponent(lblProducto))
						.addComponent(producto, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addComponent(lblPrecio))
						.addComponent(precio, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnAgregarproducto, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnEliminarproducto, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE))
					.addGap(25)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 248, GroupLayout.PREFERRED_SIZE)
					.addGap(17)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(btmodificar, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnuevo, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
								.addComponent(btconfirmar, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addComponent(lblTot))
						.addComponent(total, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)))
		);
		getContentPane().setLayout(groupLayout);

		// Completo los campos con el cliente seleccionado
		cliente.getDocument().addDocumentListener(
				new javax.swing.event.DocumentListener() {

					public void insertUpdate(javax.swing.event.DocumentEvent evt) {

						// lleno los campos
						clienteSeleccionado = (Cliente) clientes.getItemSelected();
						if (clienteSeleccionado != null) {
							dni.setText(clienteSeleccionado.getDni());
							telefono.setText(clienteSeleccionado.getTelefono());
							direccion.setText(clienteSeleccionado
									.getDireccion());
						}

					}

					public void removeUpdate(javax.swing.event.DocumentEvent evt) {
						// limpio al cambiar
						dni.setText("");
						telefono.setText("");
						direccion.setText("");
					}

					public void changedUpdate(
							javax.swing.event.DocumentEvent evt) {
						// limpio al cambiar
						dni.setText("");
						telefono.setText("");
						direccion.setText("");
					}

				});
		// Completo los campos con el producto seleccionado
		producto.getDocument().addDocumentListener(
				new javax.swing.event.DocumentListener() {

					public void insertUpdate(javax.swing.event.DocumentEvent evt) {
						
						precio.setText("");
						// lleno los campos
					
						if(productos.getItemSelected()instanceof Combo){
							productoSeleccionado=(Combo)productos
									.getItemSelected();
							Combo comboSeleccionado=(Combo)productoSeleccionado;
							if (comboSeleccionado!= null) {

								precio.setText(String.valueOf(comboSeleccionado
										.getPrecioCombo()));
							}
						}else if(productos.getItemSelected() instanceof Producto){
							productoSeleccionado = (Producto) productos
									.getItemSelected();

							if (productoSeleccionado != null) {

								precio.setText(String.valueOf(productoSeleccionado
										.getPrecio()));
							}	
						}
					

					}

					public void removeUpdate(javax.swing.event.DocumentEvent evt) {
						// limpio al cambiar
						precio.setText("");

					}

					public void changedUpdate(
							javax.swing.event.DocumentEvent evt) {
						// limpio al cambiar
						precio.setText("");
					}

				});

		// Capturo el evento del cambio en la tabla
		tabdet.getModel().addTableModelListener(new TableModelListener() {

			public void tableChanged(TableModelEvent evt) {

			}
		});

		// capturo el evento de la columna cantidad
		tabdet.addKeyListener(new java.awt.event.KeyAdapter() {
			@Override
			public void keyReleased(java.awt.event.KeyEvent e) {

				if (!tabdet.isEditing()) {
					if (tabdet.editCellAt(tabdet.getSelectedRow(), 2)) {

						if (tabdet.getValueAt(tabdet.getSelectedRow(), 2) != null
								&& tabdet
										.getValueAt(tabdet.getSelectedRow(), 2)
										.equals("") == false) {

							cantidad = Integer.valueOf(String.valueOf(tabdet
									.getValueAt(tabdet.getSelectedRow(), 2)));
							precioUnitario = Double.valueOf(String
									.valueOf(tabdet.getValueAt(
											tabdet.getSelectedRow(), 3)));

							totalLinea = cantidad * precioUnitario;

							tabdet.setValueAt(totalLinea,
									tabdet.getSelectedRow(), 4);

						}

						totalPedido = 0.0;

						for (int i = 0; i < datostabla.getRowCount(); i++) {

							totalPedido = totalPedido
									+ Double.valueOf(String.valueOf(tabdet
											.getValueAt(i, 4)));

						}
						total.setText(String.valueOf(totalPedido));

					}
				}
			}

		});

		// Eliminar fila de la tabla
		btnEliminarproducto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				datostabla.removeRow(tabdet.getSelectedRow());
				totalPedido = 0.0;

				for (int i = 0; i < datostabla.getRowCount(); i++) {

					totalPedido = totalPedido
							+ Double.valueOf(String.valueOf(tabdet.getValueAt(
									i, 4)));

				}

				total.setText(String.valueOf(totalPedido));
			}

		});
		// Doy ingreso al pedido
		btconfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Obtengo el numero de pedido
				Integer numeroPedido;
				numeroPedido = Pizzeria.dameNumeroPedido();
				pedido.setText(String.valueOf(numeroPedido));
				// Armo el encabezado del pedido
				pedidoActivo = new Pedido(pedido.getText(),
						clienteSeleccionado, fechaPedido.getText(), 0.0);
				boolean entregaADomicilio = delivery.isSelected();
				int valorEntrega = 0;
				if (entregaADomicilio == true) {
					valorEntrega = 1;
				} else if (entregaADomicilio == false) {
					valorEntrega = 0;
				}

				try {
					// Inserto los datos
					Basededatos.ejecutarsql("INSERT INTO pedido (NumeroPedido,Cliente,FechaPedido,TotalPedido,Preparado,Pagado,Adomicilio,Itinerario,Estado) VALUES ('"
							+ pedidoActivo.getNumeroPedido()
							+ "', '"
							+ pedidoActivo.getClientePedido().getIdCliente()
							+ "', '"
							+ pedidoActivo.getFechaPedido()
							+ "' , '"
							+ total.getText()
							+ "' , '"
							+ 0
							+ "','"
							+ 0
							+ "','"
							+ valorEntrega + "','"
							+ 0
							+ "','"
							+ "Preparando"
							+ "' )");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String numeroPed = null;
				int id =0;
				try {
					id=Pizzeria.devuelveMayorColumna("pedido", "IDPedido");
					numeroPed = Busqueda.buscaUnValor(
							Busqueda.devuelveTabla("pedido"), "NumeroPedido",
							pedidoActivo.getIdPedido(), "IDPedido");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				for (int k = 0; k < tabdet.getRowCount(); k++) {

					try {
						String obs = null;
						if(tabdet.getValueAt(k, 5)!=null){
							obs=String.valueOf(tabdet.getValueAt(k, 5));
						}else obs="";
						
						Basededatos
								.ejecutarsql("INSERT INTO detallepedido (IDPedido,NumeroPedido,IDProducto,Cantidad,Observacion) VALUES ('"
										+ id
										+ "', '"
										+ pedidoActivo.getNumeroPedido()
										+ "', '"
										+ tabdet.getValueAt(k, 0)
										+ "' , '"
										+ tabdet.getValueAt(k, 2)
										+ "' , '"
										+ obs
										+ "')");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				cliente.setEnabled(false);
				producto.setEnabled(false);
				tabdet.setEnabled(false);
				delivery.setEnabled(false);
				System.out.println(pedidoActivo.getIdPedido());
				Pizzeria.abrirReporte("C:\\Users\\user\\Pictures\\pizzeriawild\\src\\ticketFinal.jasper",
					Integer.valueOf(id), "NumPedido");

			}
			// aca termina el ingreso

		});
		// aca termina la clase
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {

	}
}
