package interfaz;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import negocio.Producto;
import com.mxrck.autocompleter.TextAutoCompleter;
import datos.Pizzeria;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

//import com.mxrck.autocompleter.TextAutoCompleter;

public class Productos {

	private JFrame frmProductos;
	private JTextField producto;
	private JTextField precio;
	private JButton btnNewButton_2;
	private Producto productoEncontrado;
	private JLabel lblEstado;
	private JButton btnNewButton_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Productos window = new Productos();
					window.frmProductos.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Productos() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		// Defino el estilo
		try {
			UIManager
					.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedLookAndFeelException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (Exception e) {
		}
		frmProductos = new JFrame();
		frmProductos.getContentPane().setBackground(new Color(211, 211, 211));
		frmProductos.setResizable(false);
		frmProductos.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmProductos.setTitle("Productos");
		frmProductos.setBounds(100, 100, 417, 245);
		frmProductos.getContentPane().setLayout(null);
		productoEncontrado = new Producto();
		final JComboBox Cat = new JComboBox();
		Cat.setToolTipText("");
		Cat.setBounds(92, 141, 125, 24);
		frmProductos.getContentPane().add(Cat);
		Cat.addItem("ELABORADO");
		Cat.addItem("LISTO");
		JLabel lblDescripcion = new JLabel("Producto:");
		lblDescripcion.setFont(new Font("SansSerif", Font.BOLD, 12));
		lblDescripcion.setBounds(12, 70, 71, 14);
		frmProductos.getContentPane().add(lblDescripcion);

		producto = new JTextField();
		producto.setBackground(Color.CYAN);
		producto.setBounds(92, 67, 304, 24);
		frmProductos.getContentPane().add(producto);
		producto.setColumns(10);

		// Cargo las busquedas

		final TextAutoCompleter productos = new TextAutoCompleter(producto);
		for (int i = 0; i < Pizzeria.devuelveTodosLosProductos().size(); i++) {

			productos.addItem(Pizzeria.devuelveTodosLosProductos().get(i));

		}

		JLabel lblPrecio = new JLabel("Precio");
		lblPrecio.setFont(new Font("SansSerif", Font.BOLD, 12));
		lblPrecio.setBounds(12, 108, 46, 14);
		frmProductos.getContentPane().add(lblPrecio);

		precio = new JTextField();
		precio.setBackground(Color.CYAN);
		precio.setBounds(92, 103, 125, 24);
		frmProductos.getContentPane().add(precio);
		precio.setColumns(10);

		final JButton btnNewButton = new JButton("Confirmar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// String a=textField.getText();
				// int a1=Integer.parseInt(a);
				if (producto.getText().equals("")
						|| precio.getText().equals("")) {
					JOptionPane.showMessageDialog(frmProductos,
							"No fue ingresado ningun dato", "Problemas",
							JOptionPane.WARNING_MESSAGE);
				} else {
		
					if (Producto.existeProducto(producto.getText())) {
						JOptionPane.showMessageDialog(frmProductos,
								"El producto ya existe", "Problemas",
								JOptionPane.WARNING_MESSAGE);
					} else {

						String a2 = precio.getText();
						Double a3 = Double.parseDouble(a2);

						String a4 = String.valueOf(Cat.getSelectedItem());
						String a6 = producto.getText();
						try {

							Producto.agregarProducto(a6, a3, a4, 0);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						// Basededatos.ejecutarsql("INSERT INTO producto(Producto,Precio,Categoria) VALUES(a,precio,categoria)");

					}
					producto.setText("");
					precio.setText("");
					lblEstado.setText("");
		
				}
		
			}
		});
		btnNewButton.setBounds(290, 177, 106, 28);
		frmProductos.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("Buscar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				// lleno los campos
				Producto productoEncontrado = (Producto) productos.getItemSelected();
				
				if (producto.getText().toUpperCase().equals("")||productoEncontrado.getNombre()==null) {
					JOptionPane.showMessageDialog(frmProductos,
							"NO existe producto ingrese nuevamente codigo",
							"Problemas", JOptionPane.WARNING_MESSAGE);
				} else {
					
					btnNewButton_5.setEnabled(true);
					btnNewButton_2.setEnabled(true);
					btnNewButton.setEnabled(false);
					producto.setText(productoEncontrado.getNombre().toUpperCase());
					precio.setText(String.valueOf(productoEncontrado.getPrecio()));
					Cat.setSelectedItem(productoEncontrado.getCategoria());

					if (productoEncontrado.getEstado() == true) {
						lblEstado.setText("Activo");
					} else if (productoEncontrado.getEstado() == false) {
						lblEstado.setText("Inactivo");
					}
							
				}

			}
		});
		btnNewButton_1.setBounds(290, 104, 106, 28);
		frmProductos.getContentPane().add(btnNewButton_1);

		btnNewButton_2 = new JButton("Modificar");
		btnNewButton_2.setEnabled(false);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Producto aModificar=(Producto)productos.getItemSelected();
					
					double pre = Double.valueOf(precio.getText());
					String cat = String.valueOf(Cat.getSelectedItem());
					
					Producto p1 = new Producto(producto.getText(),pre, cat,
							aModificar.getEstado());
					Producto.modificarProducto(p1,aModificar.getIdProducto());

					btnNewButton_2.setEnabled(false);
					btnNewButton_5.setEnabled(false);

				producto.setText("");
				precio.setText("");
				lblEstado.setText("");
			}
		});
		btnNewButton_2.setBounds(175, 177, 106, 28);
		frmProductos.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("Salir");
		btnNewButton_3.setVisible(false);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frmProductos.setVisible(false);
			}
		});
		btnNewButton_3.setBounds(310, 47, 86, 14);
		frmProductos.getContentPane().add(btnNewButton_3);

		JLabel lblNewLabel = new JLabel("Estado");
		lblNewLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
		lblNewLabel.setBounds(12, 183, 60, 14);
		frmProductos.getContentPane().add(lblNewLabel);

		btnNewButton_5 = new JButton("Cambiar estado");
		btnNewButton_5.setFont(new Font("SansSerif", Font.PLAIN, 11));
		btnNewButton_5.setEnabled(false);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Cargo las busquedas

			
				Producto filtrado=(Producto)productos.getItemSelected();
				Producto.cambiarEstado(filtrado.getEstado(),
						filtrado.getIdProducto());
				
				btnNewButton_5.setVisible(false);
				btnNewButton_2.setVisible(false);
				producto.setText("");
				precio.setText("");
				lblEstado.setText("");
	
			}
	
		
		
		});
		btnNewButton_5.setBounds(290, 139, 106, 28);
		frmProductos.getContentPane().add(btnNewButton_5);

		lblEstado = new JLabel("");
		lblEstado.setEnabled(false);
		lblEstado.setBounds(92, 178, 78, 19);
		frmProductos.getContentPane().add(lblEstado);

		JLabel label_1 = new JLabel("Categoria");
		label_1.setFont(new Font("SansSerif", Font.BOLD, 12));
		label_1.setBounds(12, 146, 71, 14);
		frmProductos.getContentPane().add(label_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(28, 76, 70));
		panel.setBounds(0, 0, 411, 47);
		frmProductos.getContentPane().add(panel);
		
		JLabel lblClientes = new JLabel();
		lblClientes.setText("Productos");
		lblClientes.setForeground(Color.WHITE);
		lblClientes.setFont(new Font("Rod", Font.PLAIN, 24));
		lblClientes.setBackground(Color.WHITE);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGap(0, 467, Short.MAX_VALUE)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap(273, Short.MAX_VALUE)
					.addComponent(lblClientes)
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGap(0, 47, Short.MAX_VALUE)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblClientes)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);

	}

	public void setVisible(boolean b) {
		frmProductos.setVisible(b);

	}
}
