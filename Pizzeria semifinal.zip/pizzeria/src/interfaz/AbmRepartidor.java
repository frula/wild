package interfaz;

import datos.Pizzeria;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import com.mxrck.autocompleter.TextAutoCompleter;

import negocio.Cliente;
import negocio.Repartidor;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AbmRepartidor extends javax.swing.JFrame {
    ArrayList <Repartidor> repartidor=Pizzeria.devuelveRepartidor();
    
    public AbmRepartidor(java.awt.Frame parent, boolean modal) {
        initComponents();
        inicio();
    }
    
    void inicio(){
        checkhab.setEnabled(false);
        checkhab.setSelected(true);
        btagregar.setEnabled(false);
        btbloquear.setEnabled(false);
        btmod.setEnabled(false);
    }
    
   
    
    void desbloquearGuardar(){
        boolean desbloqueo=true;
        if(txnombre.getText().equals("")){
            desbloqueo=false;}
        else if(txdni.getText().equals("")){
            desbloqueo=false;}
        else if(txtelefono.getText().equals("")){
            desbloqueo=false;}
        else if(txdir.getText().equals("")){
            desbloqueo=false;}
        
        else if(btbloquear.isEnabled()==true || btmod.isEnabled()==true){
            desbloqueo=false;
        }
        else{
            desbloqueo=true;}
        btagregar.setEnabled(desbloqueo);
        }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btbuscar = new javax.swing.JButton();
        txbuscar = new javax.swing.JTextField();
        
        txbuscar.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent arg0) {
        	txbuscar.setText("");
        	txnombre.setText("");
        	txdir.setText("");
        	txdni.setText("");
        	txtelefono.setText("");
        	}
        });
        
        txbuscar.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent arg0) {
        		final TextAutoCompleter busqueda = new TextAutoCompleter(txbuscar);
        		for (int i = 0; i < repartidor.size(); i++) {

        			busqueda.addItem(repartidor.get(i).getid());
        		}
        	}
        });
        lbdni = new javax.swing.JLabel();
        txnombre = new javax.swing.JTextField();
        lbnombre = new javax.swing.JLabel();
        txtelefono = new javax.swing.JTextField();
        lbdir = new javax.swing.JLabel();
        lbtel = new javax.swing.JLabel();
        txdir = new javax.swing.JTextField();
        btsalir = new javax.swing.JButton();
        btagregar = new javax.swing.JButton();
        btbloquear = new javax.swing.JButton();
        btmod = new javax.swing.JButton();
        checkhab = new javax.swing.JCheckBox();
        btnuevo = new javax.swing.JButton();
        cbvehiculo = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        txdni = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setName("panel"); // NOI18N

        jLabel1.setFont(new java.awt.Font("MV Boli", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Repartidor");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 11, Short.MAX_VALUE)
                .addComponent(jLabel1))
        );

        btbuscar.setText("Buscar");
        btbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbuscarActionPerformed(evt);
            }
        });

        txbuscar.setText("Ingrese DNI");
        txbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txbuscarActionPerformed(evt);
            }
        });

        lbdni.setText("Nombre:");

        txnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txnombreActionPerformed(evt);
            }
        });
        txnombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txnombreKeyTyped(evt);
            }
        });

        lbnombre.setText("Telefono:");

        txtelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtelefonoActionPerformed(evt);
            }
        });
        txtelefono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtelefonoKeyReleased(evt);
            }
        });

        lbdir.setText("Direccion:");

        lbtel.setText("Vehiculo:");

        txdir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txdirActionPerformed(evt);
            }
        });
        txdir.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txdirKeyTyped(evt);
            }
        });

        btsalir.setText("Salir");
        btsalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btsalirActionPerformed(evt);
            }
        });

        btagregar.setText("Agregar");
        btagregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btagregarActionPerformed(evt);
                
            }
        });

        btbloquear.setText("Bloquear");
        btbloquear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbloquearActionPerformed(evt);
            }
        });

        btmod.setText("Modificar");
        btmod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmodActionPerformed(evt);
            }
        });

        checkhab.setText("Habilitado");
        checkhab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkhabActionPerformed(evt);
            }
        });

        btnuevo.setText("Nuevo");
        btnuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnuevoActionPerformed(evt);
            }
        });

        cbvehiculo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Moto", "Bici", "Sin vehiculo" }));

        jLabel2.setText("DNI:");

        txdni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txdniActionPerformed(evt);
            }
        });
        txdni.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txdniKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(checkhab)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btbuscar)
                .addGap(24, 24, 24))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(20, Short.MAX_VALUE)
                        .addComponent(btnuevo)
                        .addGap(18, 18, 18)
                        .addComponent(btagregar, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btbloquear)
                        .addGap(18, 18, 18)
                        .addComponent(btmod))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbdni)
                            .addComponent(lbnombre)
                            .addComponent(lbdir)
                            .addComponent(lbtel)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txdir, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                            .addComponent(txnombre, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                            .addComponent(txtelefono, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                            .addComponent(cbvehiculo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txdni))))
                .addGap(18, 18, 18)
                .addComponent(btsalir, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btbuscar)
                        .addComponent(txbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(checkhab))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txdni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbdni)
                    .addComponent(txnombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbnombre)
                    .addComponent(txtelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbdir)
                    .addComponent(txdir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbtel)
                    .addComponent(cbvehiculo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnuevo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btsalir, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btmod, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btbloquear, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btagregar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        jPanel1.getAccessibleContext().setAccessibleName("panel");

        pack();
    }// </editor-fold>                        

    
    void actualizar(){
  	   this.repartidor=Pizzeria.devuelveRepartidor();
     }
    
    private void txbuscarActionPerformed(java.awt.event.ActionEvent evt) {                                         
    }                                        

    private void txnombreActionPerformed(java.awt.event.ActionEvent evt) {                                         
     if(txnombre.getText().equals("")){
            txnombre.requestFocus();
        }
        else{
            txtelefono.transferFocus(); 
        }
    }                                        

    private void btsalirActionPerformed(java.awt.event.ActionEvent evt) {                                        
        dispose();        
    }                                       

    private void btagregarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        String vehiculo=String.valueOf(cbvehiculo.getSelectedItem());
        int es;
        if(checkhab.isSelected()){es=1;}
        else{es=0;}
        int dni=Integer.parseInt(txdni.getText());
        String tel=txtelefono.getText();
        Repartidor rep = new Repartidor(dni,txnombre.getText().toUpperCase(),
                txdir.getText(),tel,vehiculo,es);
        Pizzeria.AgregarRepartidor(rep);
        actualizar();
    }                                         

    private void btbloquearActionPerformed(java.awt.event.ActionEvent evt) {                                           
        int act;
        if(checkhab.isSelected()){act=0; checkhab.setSelected(false);}
        else{act=1; checkhab.setSelected(true);}
        
        int dni=Integer.parseInt(txdni.getText());
        Pizzeria.bloquearRepartidor(act,dni );
        actualizar();
    }                                          

    private void btmodActionPerformed(java.awt.event.ActionEvent evt) {                                      
        int dni=Integer.parseInt(txdni.getText());
        String nombre=String.valueOf(txnombre.getText().toUpperCase());
        String tel=String.valueOf(txtelefono.getText());
        String vehiculo=String.valueOf(cbvehiculo.getSelectedItem());
        Pizzeria.modificarRepartidor(dni,nombre,txdir.getText(),tel,vehiculo);
        actualizar();
    }                                     

    private void txtelefonoActionPerformed(java.awt.event.ActionEvent evt) {                                           
        if(txtelefono.getText().equals("")){
            txtelefono.requestFocus();
        }
        else{
            txtelefono.transferFocus(); 
        }
    }                                          

    private void txdirActionPerformed(java.awt.event.ActionEvent evt) {                                      
        if(txdir.getText().equals("")){
            txdir.requestFocus();
        }
        else{
            txdir.transferFocus(); 
        }
    }                                     

    private void checkhabActionPerformed(java.awt.event.ActionEvent evt) {                                         
    }                                        

    private void btbuscarActionPerformed(java.awt.event.ActionEvent evt) {                                         
        if(txbuscar.getText().equals("")==false && txbuscar.getText().equals(null)==false){
        String busqueda = txbuscar.getText();
        
        for(int i=0;i<repartidor.size();i++){
            if(busqueda.equals(repartidor.get(i).getId())){
                txdni.setText(String.valueOf(repartidor.get(i).getid()));
                txdir.setText(repartidor.get(i).getdireccion());
                txtelefono.setText(String.valueOf(repartidor.get(i).getTelefono()));
                txnombre.setText(repartidor.get(i).getnombre());
                checkhab.setSelected(repartidor.get(i).getActivo());
                cbvehiculo.setSelectedItem(repartidor.get(i).getVehiculo());
                
            }
        }
        btbloquear.setEnabled(true);
        btmod.setEnabled(true);
        btagregar.setEnabled(false);
        txdni.setEnabled(false);
        }
    }                                        

    private void btnuevoActionPerformed(java.awt.event.ActionEvent evt) {                                        
        txdir.setText("");
            checkhab.setSelected(true);
            txdni.setEnabled(true);
            txdni.setText("");
            txnombre.setText("");
            txtelefono.setText("");
            btbloquear.setEnabled(false);
            btmod.setEnabled(false);
            btagregar.setEnabled(false);
    }                                       

    private void txdniActionPerformed(java.awt.event.ActionEvent evt) {                                      
        if(txdni.getText().equals("")){
            txdni.requestFocus();
        }
        else{
            txdni.transferFocus(); 
        }// TODO add your handling code here:
    }                                     

    private void txdniKeyReleased(java.awt.event.KeyEvent evt) {                                  
        if(!txdni.getText().matches("[0-9--]*")){
            JOptionPane.showMessageDialog(null, "Solo valores num�ricos","Advertencia",JOptionPane.ERROR_MESSAGE);
            txdni.setText("");
        }
        desbloquearGuardar();
    }                                 

    private void txtelefonoKeyReleased(java.awt.event.KeyEvent evt) {                                       
        if(!txtelefono.getText().matches("[0-9--]*")){
            JOptionPane.showMessageDialog(null, "Solo valores num�ricos","Advertencia",JOptionPane.ERROR_MESSAGE);
            txtelefono.setText("");
        }
        desbloquearGuardar();
    }                                      

    private void txnombreKeyTyped(java.awt.event.KeyEvent evt) {                                  
        desbloquearGuardar();
    }                                 

    private void txdirKeyTyped(java.awt.event.KeyEvent evt) {                               
        desbloquearGuardar();
    }                              

                                                                               
      
                                     
                                

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                AbmRepartidor dialog = new AbmRepartidor(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton btagregar;
    private javax.swing.JButton btbloquear;
    private javax.swing.JButton btbuscar;
    private javax.swing.JButton btmod;
    private javax.swing.JButton btnuevo;
    private javax.swing.JButton btsalir;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox cbvehiculo;
    private javax.swing.JCheckBox checkhab;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbdir;
    private javax.swing.JLabel lbdni;
    private javax.swing.JLabel lbnombre;
    private javax.swing.JLabel lbtel;
    private javax.swing.JTextField txbuscar;
    private javax.swing.JTextField txdir;
    private javax.swing.JTextField txdni;
    private javax.swing.JTextField txnombre;
    private javax.swing.JTextField txtelefono;
    // End of variables declaration                   
}
