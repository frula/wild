package interfaz;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import datos.BackUP;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;

public class MenuPrincipal extends JFrame implements ActionListener {

	private JMenuBar mb;
	private JMenu menu1, menu2, menu3;
	private JMenuItem mi1, mi3;
	private JTextField ultimaRestauracion;
	private Cocina formCocina;
	private JButton btnCliente;
	private JButton btcompra;
	private JButton btnPedidos;
	private JLabel lblProductos;
	private JLabel lblMateriaPrima;
	private JLabel lblPrima;
	private JLabel lblProveedores;
	private JLabel lblCombos;

	public MenuPrincipal() {
		setResizable(false);
		getContentPane().setBackground(Color.WHITE);

		// Defino el estilo
		try {
			UIManager
					.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedLookAndFeelException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		// Creo el formulario de pedidos
		formCocina = new Cocina();

		// Tama�o inicial de ventana
		this.setSize(356, 500);
		getContentPane().setLayout(null);

		JButton btnPedido = new JButton("");
		btnPedido.setBounds(22, 31,58,55);
		ImageIcon aux3=new ImageIcon(MenuPrincipal.class.getResource("/imagenes/pedido.jpg"));
		Image aux4=aux3.getImage().getScaledInstance(btnPedido.getWidth(),btnPedido.getHeight(),Image.SCALE_REPLICATE);
		Icon fondo2=new ImageIcon(aux4);
		btnPedido.setIcon(fondo2);
		
		btnPedido.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				FormPedido formPedidos = new FormPedido();
				formPedidos.setVisible(true);

			}
		});
		
		getContentPane().add(btnPedido);
	
		btnCliente = new JButton("");
		btnCliente.setBorder(null);
		btnCliente.setBounds(137, 136,65,55);
		ImageIcon aux9=new ImageIcon(MenuPrincipal.class.getResource("/imagenes/cliente.jpg"));
		Image aux10=aux9.getImage().getScaledInstance(btnCliente.getWidth(),btnCliente.getHeight(),Image.SCALE_REPLICATE);
		Icon fondo5=new ImageIcon(aux10);
		btnCliente.setIcon(fondo5);
		btnCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ABMcliente clientes = new ABMcliente();
				clientes.setVisible(true);
			}
		});
		
		getContentPane().add(btnCliente);

		JButton btnMateriasPrimas = new JButton("");
		btnMateriasPrimas.setBorder(null);
		btnMateriasPrimas.setBounds(22, 136,58,55);
		ImageIcon aux8=new ImageIcon(MenuPrincipal.class.getResource("/imagenes/matPrima.jpg"));
		Image aux7=aux8.getImage().getScaledInstance(btnMateriasPrimas.getWidth(),btnMateriasPrimas.getHeight(),Image.SCALE_REPLICATE);
		Icon fondo4=new ImageIcon(aux7);
		btnMateriasPrimas.setIcon(fondo4);
		
		btnMateriasPrimas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				FormMatPrima matPrimas = new FormMatPrima();
				matPrimas.setVisible(true);
			}
		});
		getContentPane().add(btnMateriasPrimas);

		btnPedidos = new JButton("");
		btnPedidos.setBorder(null);
		btnPedidos.setAlignmentY(0.0f);
		btnPedidos.setBounds(137, 31,65,55);
		ImageIcon aux=new ImageIcon(MenuPrincipal.class.getResource("/imagenes/pedidos.jpg"));
		Image aux2=aux.getImage().getScaledInstance(btnPedidos.getWidth(),btnPedidos.getHeight(),Image.SCALE_REPLICATE);
		Icon fondo=new ImageIcon(aux2);
		btnPedidos.setIcon(fondo);
		btnPedidos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Pedidos formularioPedidos = new Pedidos(
						new javax.swing.JFrame(), true);
				formularioPedidos.setVisible(true);
			}
		});

		getContentPane().add(btnPedidos);
		
		JButton btnProductos = new JButton("");
		btnProductos.setBorder(null);
		btnProductos.setBounds(256, 31,58,55);
		ImageIcon aux5=new ImageIcon(MenuPrincipal.class.getResource("/imagenes/pizza4.jpg"));
		Image aux6=aux5.getImage().getScaledInstance(btnProductos.getWidth(),btnProductos.getHeight(),Image.SCALE_REPLICATE);
		Icon fondo3=new ImageIcon(aux6);
		btnProductos.setIcon(fondo3);
		
		btnProductos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Productos formularioProductos = new Productos();
				formularioProductos.setVisible(true);
				
			
			}
		});
		//btnProductos.setBounds(228, 31, 90, 28);
		getContentPane().add(btnProductos);
		
		JButton btnCombos = new JButton("");
		btnCombos.setBorder(null);
		btnCombos.setBounds(22, 255,65,55);
		ImageIcon aux15=new ImageIcon(MenuPrincipal.class.getResource("/imagenes/combo.jpg"));
		Image aux16=aux15.getImage().getScaledInstance(btnCombos.getWidth(),btnCombos.getHeight(),Image.SCALE_REPLICATE);
		Icon fondo7=new ImageIcon(aux16);
		btnCombos.setIcon(fondo7);
		btnCombos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				Combos formularioCombo = new Combos();
				formularioCombo.setVisible(true);
			}
		});
	
		getContentPane().add(btnCombos);
		
		JButton btnProveedores = new JButton("");
		btnProveedores.setBorder(null);
		btnProveedores.setBounds(249, 136,65,55);
		ImageIcon aux12=new ImageIcon(MenuPrincipal.class.getResource("/imagenes/proveedores.jpg"));
		Image aux13=aux12.getImage().getScaledInstance(btnProveedores.getWidth(),btnProveedores.getHeight(),Image.SCALE_REPLICATE);
		Icon fondo6=new ImageIcon(aux13);
		btnProveedores.setIcon(fondo6);
		btnProveedores.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				Abmproveedor formularioProveedores = new Abmproveedor();
				formularioProveedores.setVisible(true);
			}
		});
	
		getContentPane().add(btnProveedores);
		
		JLabel lblPedidos = new JLabel("Pedidos");
		lblPedidos.setHorizontalAlignment(SwingConstants.CENTER);
		lblPedidos.setHorizontalTextPosition(SwingConstants.CENTER);
		lblPedidos.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPedidos.setBounds(140, 85, 58, 28);
		getContentPane().add(lblPedidos);
		
		JLabel lblPedido = new JLabel("Pedido");
		lblPedido.setHorizontalTextPosition(SwingConstants.CENTER);
		lblPedido.setHorizontalAlignment(SwingConstants.CENTER);
		lblPedido.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPedido.setBounds(22, 85, 58, 28);
		getContentPane().add(lblPedido);
		
		lblProductos = new JLabel("Productos");
		lblProductos.setHorizontalTextPosition(SwingConstants.CENTER);
		lblProductos.setHorizontalAlignment(SwingConstants.CENTER);
		lblProductos.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblProductos.setBounds(245, 85, 74, 28);
		getContentPane().add(lblProductos);
		
		lblMateriaPrima = new JLabel("Materia");
		lblMateriaPrima.setHorizontalTextPosition(SwingConstants.CENTER);
		lblMateriaPrima.setHorizontalAlignment(SwingConstants.CENTER);
		lblMateriaPrima.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblMateriaPrima.setBounds(22, 196, 58, 22);
		getContentPane().add(lblMateriaPrima);
		
		lblPrima = new JLabel("Prima");
		lblPrima.setHorizontalTextPosition(SwingConstants.CENTER);
		lblPrima.setHorizontalAlignment(SwingConstants.CENTER);
		lblPrima.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPrima.setBounds(22, 217, 58, 17);
		getContentPane().add(lblPrima);
		
		JLabel lblClientes = new JLabel("Clientes");
		lblClientes.setHorizontalTextPosition(SwingConstants.CENTER);
		lblClientes.setHorizontalAlignment(SwingConstants.CENTER);
		lblClientes.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblClientes.setBounds(140, 196, 58, 22);
		getContentPane().add(lblClientes);
		
		lblProveedores = new JLabel("Proveedores");
		lblProveedores.setHorizontalTextPosition(SwingConstants.CENTER);
		lblProveedores.setHorizontalAlignment(SwingConstants.CENTER);
		lblProveedores.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblProveedores.setBounds(236, 196, 94, 22);
		getContentPane().add(lblProveedores);
		
		lblCombos = new JLabel("Combos");
		lblCombos.setHorizontalTextPosition(SwingConstants.CENTER);
		lblCombos.setHorizontalAlignment(SwingConstants.CENTER);
		lblCombos.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblCombos.setBounds(22, 314, 58, 28);
		getContentPane().add(lblCombos);
		
		JLabel lblCompra = new JLabel("Compra");
		lblCompra.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblCompra.setBounds(144, 321, 58, 17);
		getContentPane().add(lblCompra);
		
		JButton btcompra = new JButton("");
		btcompra.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				interfazCompra compra = new interfazCompra();
				compra.setVisible(true);
			}
		});
		btcompra.setBounds(130, 248, 85, 75);
		getContentPane().add(btcompra);
		ImageIcon aux18=new ImageIcon(MenuPrincipal.class.getResource("/imagenes/carrito.jpg"));
		Image aux19=aux18.getImage().getScaledInstance(btcompra.getWidth(),btcompra.getHeight(),Image.SCALE_REPLICATE);
		Icon fondo8=new ImageIcon(aux19);
		btcompra.setIcon(fondo8);
		
		JButton btrepartidor = new JButton("");
		btrepartidor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AbmRepartidor repartidor=new AbmRepartidor(new javax.swing.JFrame(), true);
				repartidor.setVisible(true);
			}
		});
		
		
		btrepartidor.setBounds(245, 255, 69, 61);
		getContentPane().add(btrepartidor);
		ImageIcon aux20=new ImageIcon(MenuPrincipal.class.getResource("/imagenes/repartidorr.jpg"));
		Image aux21=aux20.getImage().getScaledInstance(btcompra.getWidth(),btcompra.getHeight(),Image.SCALE_REPLICATE);
		Icon fondo9=new ImageIcon(aux21);
		btrepartidor.setIcon(fondo9);
		
		
		JLabel lblRepartidor = new JLabel("Repartidor");
		lblRepartidor.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblRepartidor.setBounds(249, 323, 65, 14);
		getContentPane().add(lblRepartidor);
		
		JButton btinformes = new JButton("");
		btinformes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VentaReporte informe=new VentaReporte();
				informe.setVisible(true);
			}
		});
		btinformes.setBounds(140, 372, 62, 50);
		getContentPane().add(btinformes);
		ImageIcon aux22=new ImageIcon(MenuPrincipal.class.getResource("/imagenes/informes.png"));
		Image aux23=aux22.getImage().getScaledInstance(btinformes.getWidth(),btinformes.getHeight(),Image.SCALE_REPLICATE);
		Icon fondo10=new ImageIcon(aux23);
		btinformes.setIcon(fondo10);
		
		JLabel lblNewLabel = new JLabel("Informes");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(144, 426, 62, 14);
		getContentPane().add(lblNewLabel);

		// Creo el menu contenedor
		mb = new JMenuBar();
		setJMenuBar(mb);

		// Creo el menu principal
		menu1 = new JMenu("Opciones de Sistema");
		mb.add(menu1);

		// Creo y agrego los submenus
		menu2 = new JMenu("Backup");
		menu2.addActionListener(this);
		menu1.add(menu2);
		menu3 = new JMenu("Restaurar");
		menu3.addActionListener(this);
		menu1.add(menu3);

		ultimaRestauracion = new JTextField();
		ultimaRestauracion.setEnabled(false);
		menu3.add(ultimaRestauracion);
		ultimaRestauracion.setColumns(10);

		// Agrego opciones a los submenus
		mi1 = new JMenuItem("Realizar nuevo Backup");
		menu2.add(mi1);
		mi1.addActionListener(this);
		mi3 = new JMenuItem("Restaurar Sistema");
		menu3.add(mi3);
		mi3.addActionListener(this);

	}

	// Capturo los eventos de las opciones
	public void actionPerformed(ActionEvent e) {
		int respuesta;
		// Accion de backup
		if (e.getSource() == mi1) {

			respuesta = JOptionPane.showConfirmDialog(null, "�Esta seguro?",
					"Alerta!", JOptionPane.YES_NO_OPTION);

			if (respuesta == 0) {
				BackUP c = new BackUP();
				c.generarBackUp("c:\\backupPrueba.sql");
				JOptionPane.showMessageDialog(null,
						"Operaci�n realizada correctamente");
			} else
				JOptionPane.showMessageDialog(null, "Operaci�n cancelada");

		}
		// Accion de restauracion
		if (e.getSource() == mi3) {
			respuesta = JOptionPane.showConfirmDialog(null, "�Esta seguro?",
					"Alerta!", JOptionPane.YES_NO_OPTION);
			if (respuesta == 0) {
				BackUP c = new BackUP();
				c.restaurarBackUp("c:\\backupPrueba.sql");
				JOptionPane.showMessageDialog(null,
						"Operaci�n realizada correctamente");

			} else
				JOptionPane.showMessageDialog(null, "Operaci�n cancelada");
		}

	}
}