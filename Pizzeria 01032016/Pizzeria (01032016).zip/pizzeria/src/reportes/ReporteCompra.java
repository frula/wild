package reportes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import negocio.Compra;
import negocio.CompraConDetalle;
import negocio.DetalleCompra;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;


public class ReporteCompra {
 private JasperReport reporte;
 private JasperViewer reporteViewer;
 private JasperPrint reporteLleno;
 
 
 public ReporteCompra(List<DetalleCompra> compras,String nombre){
	 try { 
	 this.reporte=(JasperReport) JRLoader.loadObjectFromFile("C:\\Users\\user\\Pictures\\pizzeriawild\\Blank_A4_2.jasper");
      Map parametro=new HashMap();
      parametro.put("Parameter1",nombre);
		this.reporteLleno=JasperFillManager.fillReport(this.reporte,parametro,new JRBeanCollectionDataSource(compras));
	} catch (JRException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
 }
 
 
 public void mostrar(){
	 this.reporteViewer= new JasperViewer(this.reporteLleno);
	 this.reporteViewer.setVisible(true);
 }
 
 public static  List<DetalleCompra> listaCompras(){
	 return DetalleCompra.dameCompras();
 }
}
