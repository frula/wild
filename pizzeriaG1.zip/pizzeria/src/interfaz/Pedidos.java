 package interfaz;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

import negocio.Celda;
import negocio.CeldaP;
import negocio.Cliente;
import negocio.Itinerario;
import negocio.Pedido;
import negocio.Repartidor;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;
import datos.Basededatos;
import datos.Pizzeria;

public class Pedidos extends javax.swing.JDialog {
    final DefaultTableModel datostabla = new DefaultTableModel();
    ArrayList<Itinerario>itinerario = Pizzeria.devuelveItinerario();
    ArrayList<Repartidor> repartidor= Pizzeria.devuelveRepartidor();
    int filaselected;
    public Pedidos(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        setFocusCycleRoot(false);
        setFocusableWindowState(false);
        setFocusable(false);
        setMaximumSize(new Dimension(800, 800));
        setMinimumSize(new Dimension(1000, 400));
        initComponents();
        getContentPane().add(jScrollPane1);
        tabla.setModel(datostabla);
        jScrollPane1.setViewportView(tabla);
        
        cbestado.setEnabled(false);                               

       
        GroupLayout groupLayout = new GroupLayout(getContentPane());
        groupLayout.setHorizontalGroup(
        	groupLayout.createParallelGroup(Alignment.LEADING)
        		.addGroup(groupLayout.createSequentialGroup()
        			.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
        				.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
        					.addContainerGap()
        					.addComponent(salir, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE))
        				.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
        					.addComponent(lbguardar)
        					.addGap(4)
        					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
        						.addComponent(cbrepartidor, Alignment.TRAILING, 0, 143, Short.MAX_VALUE)
        						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
        							.addComponent(btitinerario, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        							.addComponent(cbpedidos, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        							.addComponent(btguardar, GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
        							.addComponent(cbestado, Alignment.TRAILING, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 821, Short.MAX_VALUE)
        			.addGap(8))
        );
        groupLayout.setVerticalGroup(
        	groupLayout.createParallelGroup(Alignment.LEADING)
        		.addGroup(groupLayout.createSequentialGroup()
        			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
        				.addGroup(groupLayout.createSequentialGroup()
        					.addGap(327)
        					.addComponent(lbguardar))
        				.addGroup(groupLayout.createSequentialGroup()
        					.addComponent(cbpedidos, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
        					.addGap(59)
        					.addComponent(cbrepartidor, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(cbestado, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addComponent(btguardar, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btitinerario, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)))
        			.addPreferredGap(ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
        			.addComponent(salir))
        		.addGroup(groupLayout.createSequentialGroup()
        			.addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
        			.addContainerGap())
        );
        getContentPane().setLayout(groupLayout);
        datostabla.setDataVector(new Object[][] { }, new Object[] {
         "IdPedido", "Nro Pedido", "Cliente", "Fecha","Total","Pagado","Adomicilio","Estado" });
        
        tabla.getColumnModel().getColumn(5).setCellEditor(new Celda());
        tabla.getColumnModel().getColumn(5).setCellRenderer(new CeldaP());
        
        tabla.getColumnModel().getColumn(6).setCellEditor(new Celda());
        tabla.getColumnModel().getColumn(6).setCellRenderer(new CeldaP());
        
        //TableColumn estado = tabla.getColumnModel().getColumn(7);
        //comboBoxEstado = new JComboBox();
        // comboBox.addItem("No preparado");
        // comboBox.addItem("Preparado");
        // comboBox.addItem("Entregado");
        //TableCellEditor tc =new DefaultCellEditor(comboBoxEstado);
        //estado.setCellEditor(tc);
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
        @SuppressWarnings("unchecked")
		@Override
        public void mouseClicked(java.awt.event.MouseEvent e) {
        	if(!cbpedidos.getSelectedItem().equals("Para Itinerario")){
                cbestado.setEnabled(true);
                btguardar.setEnabled(true);
           		String actual= (String) tabla.getValueAt(tabla.getSelectedRow(), 7);
           		filaselected=tabla.getSelectedRow();
           		
        	 	   if(actual.equals("Preparando")){
        	 		  cbestado.removeAllItems();
        	 		   cbestado.addItem("Preparando");
        	 		  cbestado.addItem("Preparado");
        	 		 cbestado.addItem("Cancelado");
        	 		cbestado.setSelectedItem("Preparando");
        	 	   }
        	 	   else if(actual.equals("Preparado")&&
        	 			  tabla.getValueAt(tabla.getSelectedRow(), 6).equals(true)){
        	 		  cbestado.removeAllItems();
        	 		 cbestado.addItem("Preparado");
        	 		cbestado.addItem("En viaje");
        	 		cbestado.addItem("Cancelado");
        	 		cbestado.setSelectedItem("Preparado");
        	 	   }
        	 	   else if(actual.equals("Preparado")&&
         	 			  tabla.getValueAt(tabla.getSelectedRow(), 6).equals(false)){
        	 		  cbestado.removeAllItems();
        	 		 cbestado.addItem("Preparado");
        	 		cbestado.addItem("Entregado");
        	 		cbestado.addItem("Cancelado");
        	 		cbestado.setSelectedItem("Preparado");
        	 	   }
        	 	   else if(actual.equals("En viaje")){
        	 		  cbestado.removeAllItems();
        	 		 cbestado.addItem("En viaje");
        	 		cbestado.addItem("Cancelado");
        	 		cbestado.setSelectedItem("En viaje");
        	 	   }
        	 	   else if(actual.equals("Entregado")){
        	 		  cbestado.removeAllItems();
        	 		 cbestado.addItem("Entregado");
        	 		cbestado.addItem("Cancelado");
        	 		cbestado.setSelectedItem("Entregado");
        	 	   }
        	 	   else{
        	 		  cbestado.removeAllItems();
        	 		 cbestado.addItem("Cancelado");  
        	 		cbestado.setSelectedItem("Cancelado");}
        	 	   
				}
        	
        	}
           
        
        });    
        
        
        inicioTabla();

    }
    
    
    void inicioTabla(){
    	settablaEstados();
    	
    	String fecha=(Basededatos.dateToMySQLDate2(new Date()));
        ArrayList<Pedido> pedidofecha=Pizzeria.devuelvepedidofecha(fecha);
            for(int i=0;i<pedidofecha.size();i++){
                if(pedidofecha.get(i).getFechaPedido().equals(fecha)){
                 Cliente cliente=Pizzeria.devuelvecliente(pedidofecha.get(i).getIdcliente());
            	 String nombreCliente= cliente.getNombreCliente();
                 datostabla.addRow(new Object[] {
                 pedidofecha.get(i).getIdPedido(),pedidofecha.get(i).getNumeroPedido(),nombreCliente,
                 pedidofecha.get(i).getFechaPedido(),pedidofecha.get(i).getTotalPedido(),
                 pedidofecha.get(i).getpagoconfirmado(),pedidofecha.get(i).getAdomicilio(),pedidofecha.get(i).getestado()});
                }
             } 
    }
    @SuppressWarnings("unchecked")
	void inicializarcbestado(){
    	cbestado.setEnabled(false);
    	cbestado.removeAllItems();
    	cbestado.addItem("--Estado--");
    }
   
    void settablaNopreparado(){
    	btitinerario.setEnabled(true);
        cbrepartidor.setVisible(true);
        cbrepartidor.setEnabled(true);
        inicializarcbestado();
        
    	datostabla.setDataVector(new Object[][] { }, new Object[] {
    	         "IdPedido", "Nro Pedido", "Nro cliente", "Fecha","Total","Pagado","Adomicilio","Estado","Itinerario" });
    	tabla.getColumnModel().getColumn(8).setCellEditor(new Celda());
        tabla.getColumnModel().getColumn(8).setCellRenderer(new CeldaP());
    
        tabla.getColumnModel().getColumn(5).setCellEditor(new Celda());
        tabla.getColumnModel().getColumn(5).setCellRenderer(new CeldaP());
        
        tabla.getColumnModel().getColumn(6).setCellEditor(new Celda());
        tabla.getColumnModel().getColumn(6).setCellRenderer(new CeldaP());
               
        
        //TableColumn estado = tabla.getColumnModel().getColumn(7);
        //JComboBox comboBox = new JComboBox();
        //comboBox.addItem("No preparado");
        //comboBox.addItem("Preparado");
        //comboBox.addItem("Entregado");
        //TableCellEditor tc =new DefaultCellEditor(comboBox);
        //estado.setCellEditor(tc);
        // tabla.getColumnModel().getColumn(7).setCellEditor(new Celda());
        //tabla.getColumnModel().getColumn(7).setCellRenderer(new CeldaP());
        inicioTablaRepartidor();
    }
    
    void inicioTablaRepartidor(){
    	ArrayList<Repartidor> rep=Pizzeria.devuelveRepartidor();
    	for(int i=0;i<rep.size();i++){
    		cbrepartidor.addItem(rep.get(i).getnombre());
    	}
    }
    
    void settablaEstados(){
    	btitinerario.setEnabled(false);
    	 btguardar.setEnabled(false);
    	 cbrepartidor.setVisible(false);
    	 datostabla.setDataVector(new Object[][] { }, new Object[] {
    	         "IdPedido", "Nro Pedido", "Nro cliente", "Fecha","Total","Pagado","Adomicilio","Estado" });
    	        
    	        tabla.getColumnModel().getColumn(5).setCellEditor(new Celda());
    	        tabla.getColumnModel().getColumn(5).setCellRenderer(new CeldaP());
    	        
    	        tabla.getColumnModel().getColumn(6).setCellEditor(new Celda());
    	        tabla.getColumnModel().getColumn(6).setCellRenderer(new CeldaP());
    	               
    	        // tabla.getColumnModel().getColumn(7).setCellEditor(new Celda());
    	        //tabla.getColumnModel().getColumn(7).setCellRenderer(new CeldaP());
    	        
    	        //TableColumn estado = tabla.getColumnModel().getColumn(7);
    	        // JComboBox comboBox = new JComboBox();
    	        //comboBox.addItem("No preparado");
    	        //comboBox.addItem("Preparado");
    	        //comboBox.addItem("Entregado");
    	  	
    	        //TableCellEditor tc =new DefaultCellEditor(comboBox);
    	        //estado.setCellEditor(tc);
    }
    
    void borratabla(){
        int total=datostabla.getRowCount();
        for (int i = total-1; i >= 0; i--) {
             datostabla.removeRow(i); 
            }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jScrollPane1.setMaximumSize(new Dimension(332767, 332767));
        jScrollPane1.setBorder(UIManager.getBorder("Table.scrollPaneBorder"));
        tabla = new javax.swing.JTable();
        cbestado = new javax.swing.JComboBox();
        cbestado.setModel(new DefaultComboBoxModel(new String[] {"--Estado--"}));
        cbpedidos = new javax.swing.JComboBox();
        cbrepartidor=new javax.swing.JComboBox();
        btguardar = new javax.swing.JButton();
        salir = new javax.swing.JToggleButton();
        salir.setAlignmentX(100.0f);
        salir.setAlignmentY(100.0f);
        lbguardar = new javax.swing.JLabel();
        btitinerario = new javax.swing.JButton();
        btitinerario.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        	
        		ArrayList<Pedido>pedidosNuevos = new ArrayList<Pedido>();
        		ArrayList<Cliente> clientes=Pizzeria.devuelveClientes();
        		ArrayList <Pedido> pedidos = Pizzeria.devuelvepedidoEstado();
        		ArrayList <Repartidor> rep = Pizzeria.devuelveRepartidor();
        		
   			    int numentrega=itinerario.size();
        		 for (int j=0;j<tabla.getRowCount();j++){ 
        			 boolean iti=(Boolean) (tabla.getValueAt(j, 8));
        			 String idtab = (String.valueOf(tabla.getValueAt(j, 0)));
	                if(iti){
	                	for(int p=0;p<pedidos.size();p++){
	               			  String idped = (pedidos.get(p).getIdPedido());
	               			if(idtab.equals(idped)){
		               		  String idpedcli=String.valueOf(pedidos.get(p).getIdcliente());

	               		    for(int i=0;i<clientes.size();i++){
                              String idclie =(String.valueOf(clientes.get(i).getIdCliente()));
	                			  if(idpedcli.equals(idclie)){ 
	                		          int idcliente=clientes.get(i).getIdCliente();
	                		          String nombre =clientes.get(i).getNombreCliente();
	                		          String dni=clientes.get(i).getDni();
	                		          String direccion = clientes.get(i).getDireccion();
	                		          String telefono = clientes.get(i).getTelefono();
	                		          int activo = clientes.get(i).getActivo();
	                		          Cliente cli=new Cliente(idcliente,nombre,dni,direccion,telefono,activo);
	                		          
	                		          String numeropedido=(String.valueOf(pedidos.get(p).getNumeroPedido()));
	                		          String fecha=pedidos.get(p).getFechaPedido();
	                		          double total=pedidos.get(p).getTotalPedido();
	                		          int paga=pedidos.get(p).getintpagoconfirmado();
	                		          int Adom=pedidos.get(p).getintdom();
	                		          String est=pedidos.get(p).getestado();
	                		          
	                		          Pedido ped = new Pedido(idped,numeropedido,cli,fecha,total,paga,Adom,est);
	                		          pedidosNuevos.add(ped);
	                	}}}}
	                	}}
        		 String nombrerep=(String) cbrepartidor.getSelectedItem();
        		 for(int i=0;i<pedidosNuevos.size();i++){
        			 //int id=itinerario.size()+1;
        			 int idRep = 0;
        			 String fecha=(Basededatos.dateToMySQLDate2(new Date()));
        			 String idP=pedidosNuevos.get(i).getIdPedido();
        			 for(int j=0;j<rep.size();j++){
        				 
        				 if(nombrerep.equals(rep.get(j).getnombre())){
        				    idRep=rep.get(j).getid(); 
        				 }
        			 }
        			 //int idR=(int)(Math.random()*((repartidor.size()+1)-1))+1;
        			 //System.out.println(idR);
        			 Pizzeria.agregarItinerario(numentrega,idRep,idP,fecha);
        			 Pizzeria.modificarestadopedido(idP,"En viaje");
        			 Pizzeria.ActivarItinerario(idP);
        		 }
        		 String fileName = "C:\\Users\\gablopez\\Desktop\\Gustavo\\backup\\servidor\\pizzeria\\src\\It.jasper";

        			Basededatos.establecerConexion();
        			JasperPrint print;
        			try {
        				Map parametro = new HashMap();
        				parametro.put(null, "");

        				print = JasperFillManager.fillReport(fileName, parametro,
        						Basededatos.getConexion());
        				JasperViewer jviewer = new JasperViewer(print, false);
        				jviewer.setVisible(true);
        				Basededatos.establecerConexion();

        			} catch (JRException e) {
        				// TODO Auto-generated catch block
        				e.printStackTrace();
        			}
  
        		 Pizzeria.BorrarItinerario();
        	}
        });
    
        btitinerario.setVisible(true);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jScrollPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jScrollPane1MouseReleased(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Pagado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tablaMouseReleased(evt);
            }
            @Override
        	public void mouseClicked(MouseEvent arg0) {
            	
        	      
        		
        	}
        	@Override
        	public void mouseEntered(MouseEvent arg0) {
                    if (tabla.editCellAt(tabla.getSelectedRow(), 8)) {
                                        //btguardar.requestFocus();
                    	System.out.println(tabla.getSelectedRow());
        				}
                    if(tabla.isEditing()){
        		tabla.getCellEditor().stopCellEditing();
                    }
                }
                    
                
        	
        });
        jScrollPane1.setViewportView(tabla);

        cbpedidos.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--Pedidos--", "Todos", "No pagado", "No preparado", "No pagado ni preparado", "Envios a domicilio","Para Itinerario" }));
        cbpedidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbpedidosActionPerformed(evt);
            }
        });

        btguardar.setText("Guardar");
        btguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btguardarActionPerformed(evt);
            }
        });

        salir.setText("Salir");
        salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirActionPerformed(evt);
            }
        });

        btitinerario.setText("Imprimir itinerario");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbpedidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbpedidosActionPerformed
            ArrayList <Pedido> pedidos = Pizzeria.devuelvepedidoEstado();
            String elegido=cbpedidos.getSelectedItem().toString();
            borratabla();
            
            if(elegido.equals("--Pedidos--")){
            	settablaEstados();
        		String fecha=(Basededatos.dateToMySQLDate2(new Date()));
                ArrayList<Pedido> pedidofecha=Pizzeria.devuelvepedidofecha(fecha);
                for(int i=0;i<pedidofecha.size();i++){
                    if(pedidofecha.get(i).getFechaPedido().equals(fecha)){
                    
                    Cliente cliente=Pizzeria.devuelvecliente(pedidos.get(i).getIdcliente());
                	String nombreCliente= cliente.getNombreCliente();
                     datostabla.addRow(new Object[] {
                     pedidofecha.get(i).getIdPedido(),pedidofecha.get(i).getNumeroPedido(),nombreCliente,
                     pedidofecha.get(i).getFechaPedido(),pedidofecha.get(i).getTotalPedido(),
                     pedidofecha.get(i).getpagoconfirmado(),pedidofecha.get(i).getAdomicilio(),pedidofecha.get(i).getestado()});
                    }
                 } 
             }
            
            else if(elegido.equals("Todos")){
            	settablaEstados();
              //borratabla();
              for(int i=0;i<pedidos.size();i++){ 
            	  
            	    Cliente cliente=Pizzeria.devuelvecliente(pedidos.get(i).getIdcliente());
            	    String nombreCliente= cliente.getNombreCliente();
                    datostabla.addRow(new Object[] {
                    pedidos.get(i).getIdPedido(),pedidos.get(i).getNumeroPedido(),nombreCliente,
                    pedidos.get(i).getFechaPedido(),pedidos.get(i).getTotalPedido(),
                    pedidos.get(i).getpagoconfirmado(),pedidos.get(i).getAdomicilio(),pedidos.get(i).getestado()});
            }  
            }
            else if(elegido.equals("No pagado")){
            	
               
            	
               //borratabla();
            	settablaEstados();
               for(int i=0;i<pedidos.size();i++){
                   if(pedidos.get(i).getpagoconfirmado()==false){
                	Cliente cliente=Pizzeria.devuelvecliente(pedidos.get(i).getIdcliente());
               	    String nombreCliente= cliente.getNombreCliente();
                	   datostabla.addRow(new Object[] {
                    pedidos.get(i).getIdPedido(),pedidos.get(i).getNumeroPedido(),nombreCliente,
                    pedidos.get(i).getFechaPedido(),pedidos.get(i).getTotalPedido(),
                    pedidos.get(i).getpagoconfirmado(),pedidos.get(i).getAdomicilio(),pedidos.get(i).getestado()});
                   }
            }
            }
            else if(elegido.equals("Para Itinerario")){
            	//datostabla.addColumn("Itinerario");
            	settablaNopreparado();
                
            	//borratabla();
                for(int i=0;i<pedidos.size();i++){
                   if(pedidos.get(i).getestado().equals("null")
                		   ||pedidos.get(i).getestado().equals("Preparado")){
                	Cliente cliente=Pizzeria.devuelvecliente(pedidos.get(i).getIdcliente());
               	    String nombreCliente= cliente.getNombreCliente();
                    datostabla.addRow(new Object[] {
                    pedidos.get(i).getIdPedido(),pedidos.get(i).getNumeroPedido(),nombreCliente,
                    pedidos.get(i).getFechaPedido(),pedidos.get(i).getTotalPedido(),
                    pedidos.get(i).getpagoconfirmado(),pedidos.get(i).getAdomicilio(),pedidos.get(i).getestado(),false});
                   }
                }
                btguardar.setEnabled(false);
               
            }
            else if(elegido.equals("Preparando")){
            	//datostabla.addColumn("Itinerario");
            	settablaEstados();;
                
            	//borratabla();
                for(int i=0;i<pedidos.size();i++){
                   if(pedidos.get(i).getestado().equals("null")
                		   ||pedidos.get(i).getestado().equals("Preparando")){
                	Cliente cliente=Pizzeria.devuelvecliente(pedidos.get(i).getIdcliente());
               	    String nombreCliente= cliente.getNombreCliente();
                    datostabla.addRow(new Object[] {
                    pedidos.get(i).getIdPedido(),pedidos.get(i).getNumeroPedido(),nombreCliente,
                    pedidos.get(i).getFechaPedido(),pedidos.get(i).getTotalPedido(),
                    pedidos.get(i).getpagoconfirmado(),pedidos.get(i).getAdomicilio(),pedidos.get(i).getestado()});
                   }
                }
                
            }
            else if(elegido.equals("No pagado ni preparado")){
                //borratabla();
            	settablaEstados();
                for(int i=0;i<pedidos.size();i++){
                   if((pedidos.get(i).getestado().equals(null) || pedidos.get(i).getestado().equals("null")
                		   || pedidos.get(i).getestado().equals("Preparando"))){
                	   //if(pedidos.get(i).getpagoconfirmado()==false){
                	   Cliente cliente=Pizzeria.devuelvecliente(pedidos.get(i).getIdcliente());
               	    String nombreCliente= cliente.getNombreCliente();
                    datostabla.addRow(new Object[] {
                    pedidos.get(i).getIdPedido(),pedidos.get(i).getNumeroPedido(),nombreCliente,
                    pedidos.get(i).getFechaPedido(),pedidos.get(i).getTotalPedido(),
                    pedidos.get(i).getpagoconfirmado(),pedidos.get(i).getAdomicilio(),pedidos.get(i).getestado()});
                   }//}
                } 
            }
            
            else if(elegido.equals("Envios a domicilio")){
            	settablaEstados();
               for(int i=0;i<pedidos.size();i++){
                   if(pedidos.get(i).getAdomicilio()==true){
                	Cliente cliente=Pizzeria.devuelvecliente(pedidos.get(i).getIdcliente());
               	    String nombreCliente= cliente.getNombreCliente();
                    datostabla.addRow(new Object[] {
                    pedidos.get(i).getIdPedido(),pedidos.get(i).getNumeroPedido(),nombreCliente,
                    pedidos.get(i).getFechaPedido(),pedidos.get(i).getTotalPedido(),
                    pedidos.get(i).getpagoconfirmado(),pedidos.get(i).getAdomicilio(),pedidos.get(i).getestado()});
                   }
                } 
            }
            
            
    }//GEN-LAST:event_cbpedidosActionPerformed

    private void salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirActionPerformed
        dispose();
    }//GEN-LAST:event_salirActionPerformed

    private void btguardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btguardarActionPerformed
        btguardar.requestFocus();
        for(int i=0;i<datostabla.getRowCount();i++){
        	if(i==filaselected){
               int id=Integer.valueOf(String.valueOf(tabla.getValueAt(i, 0)));
               int pa;
               int dc;
               boolean pagadoseleccion=((Boolean) tabla.getValueAt(i,5)).booleanValue();
               boolean Adomicilio=((Boolean) tabla.getValueAt(i,6)).booleanValue();
               String est=(String) cbestado.getSelectedItem();
               if(pagadoseleccion==false){pa=0;}
               else{pa=1;}
              
               
               if(Adomicilio==false){dc=0;}
               else{dc=1;}
               
               Pizzeria.modificarpedido(id, pa, dc,est);
        }}
    }//GEN-LAST:event_btguardarActionPerformed

    private void jScrollPane1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane1MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jScrollPane1MouseReleased

    private void tablaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaMouseReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Pedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Pedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Pedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Pedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Pedidos dialog = new Pedidos(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
                
            }
        });
    }
    private javax.swing.JButton btguardar;
    private javax.swing.JComboBox cbpedidos;
    private javax.swing.JComboBox cbrepartidor;
    private javax.swing.JButton btitinerario;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbguardar;
    private javax.swing.JToggleButton salir;
    private javax.swing.JTable tabla;
    private javax.swing.JComboBox cbestado;
}
