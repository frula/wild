package interfaz;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import negocio.Cliente;
import negocio.Pedido;
import datos.Basededatos;
import datos.Busqueda;

public class FormPedido extends JDialog {
	
	private Pedido pedidoActivo;
    private JTable tabla = null;
    private DefaultTableModel modelo = null;
    private JScrollPane desplazamiento = null;
	private JTextField idPedido;
	private JTextField fechaPedido;   
	private ResultSet clientes;
	private ResultSet productos;
	private ResultSet idProductos;
	private Cliente clienteActivo;

	public FormPedido() {
		
		setTitle("Pedidos");
		JLabel lblCliente = new JLabel("Cliente:");
		lblCliente.setBounds(28, 88, 55, 16);
		getContentPane().add(lblCliente);
		
		idPedido = new JTextField();
		idPedido.setHorizontalAlignment(SwingConstants.CENTER);
		idPedido.setEnabled(false);
		idPedido.setBounds(95, 41, 122, 28);
		getContentPane().add(idPedido);
		idPedido.setColumns(10);
		
		JLabel lblIdpedido = new JLabel("IDPedido:");
		lblIdpedido.setBounds(28, 47, 55, 16);
		getContentPane().add(lblIdpedido);
		
		fechaPedido = new JTextField();
		fechaPedido.setHorizontalAlignment(SwingConstants.CENTER);
		fechaPedido.setEnabled(false);
		fechaPedido.setBounds(300, 41, 122, 28);
		getContentPane().add(fechaPedido);
		fechaPedido.setColumns(10);
		
		JLabel lblFecha = new JLabel("Fecha:");
		lblFecha.setBounds(233, 47, 55, 16);
		getContentPane().add(lblFecha);
		
		JScrollPane detallePedidos = new JScrollPane();
		detallePedidos.setBounds(12, 199, 573, 162);
		getContentPane().add(detallePedidos);
		
	
		JLabel lblId = new JLabel("ID");
		lblId.setBounds(28, 129, 20, 16);
		getContentPane().add(lblId);
		
		JLabel lblProducto = new JLabel("Producto");
		lblProducto.setBounds(162, 129, 55, 16);
		getContentPane().add(lblProducto);
		
		
		JRadioButton rdbtnPedidopreparado = new JRadioButton("PedidoPreparado");
		rdbtnPedidopreparado.setBounds(431, 18, 132, 18);
		getContentPane().add(rdbtnPedidopreparado);
		
		JRadioButton rdbtnPedidopago = new JRadioButton("PedidoPago");
		rdbtnPedidopago.setBounds(431, 46, 115, 18);
		getContentPane().add(rdbtnPedidopago);
		
		JButton btnAgregarproducto = new JButton("AgregarProducto");
		btnAgregarproducto.setBounds(463, 162, 122, 28);
		getContentPane().add(btnAgregarproducto);
		
		JButton btnEliminarproducto = new JButton("QuitarProducto");
		btnEliminarproducto.setBounds(329, 162, 122, 28);
		getContentPane().add(btnEliminarproducto);
		
		// Nombre de las columnas como apareceran en la tabla
		
        String[] columnas = {"IDProducto", "Producto", "Precio"};
        tabla = new JTable();
        modelo = new DefaultTableModel();
        desplazamiento = new JScrollPane(tabla);
        // Modelo de la tabla
        modelo.setColumnIdentifiers(columnas);
        // Barras de desplazamiento
        desplazamiento.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        desplazamiento.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        
        // Propiedades de la tabla
        tabla.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        tabla.setFillsViewportHeight(true);        
        
        tabla.setModel(modelo);
        setBounds(100, 100, 607, 405);
		getContentPane().setLayout(null);
		
//Sector de tabla arriba------------------------------------------------------------------------
		
		//Defino la fecha del dia
		
		fechaPedido.setText(Basededatos.dateToMySQLDate2(new Date()));
	
		//Carga de ComboBoxes
	
		final JComboBox cbCliente = new JComboBox();
		cbCliente.setBounds(95, 83, 490, 26);
		getContentPane().add(cbCliente);
		cbCliente.addItem("Seleccione cliente");
		try {
			clientes = Basededatos.consultasql("SELECT IDCliente,Cliente,DNI,Direccion,Telefono FROM cliente ORDER BY Cliente");
			clientes.previous();
			
			while (clientes.next()) {
				cbCliente.addItem(clientes.getString(2));
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JComboBox cbID = new JComboBox();
		cbID.setBounds(50, 124, 93, 26);
		getContentPane().add(cbID);
		cbID.addItem("IDProducto");
		try {
			idProductos = Basededatos.consultasql("SELECT IDProducto,Producto,Precio,Categoria FROM producto ORDER BY IDProducto");
			idProductos.previous();
			
			while (idProductos.next()) {
				cbID.addItem(idProductos.getString(1));
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JComboBox cbProducto = new JComboBox();
		cbProducto.setBounds(233, 124, 352, 26);
		getContentPane().add(cbProducto);
		cbProducto.addItem("Producto");
		try {
			productos = Basededatos.consultasql("SELECT IDProducto,Producto,Precio,Categoria FROM producto ORDER BY Producto");
			productos.previous();
			
			while (productos.next()) {
				cbProducto.addItem(productos.getString(2));
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//----------------------------------------------------------------------------------------------		
		//Guardo el cliente seleccionado
		cbCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					ResultSet clienteSeleccionado=Busqueda.filtroATabla("cliente","Cliente",cbCliente.getSelectedItem().toString());
		
					clienteActivo=new Cliente(clienteSeleccionado.getInt(1),clienteSeleccionado.getString(2),
							clienteSeleccionado.getString(3),clienteSeleccionado.getString(4),
							clienteSeleccionado.getString(5));
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
			}
			
		});	
	}
	
}
