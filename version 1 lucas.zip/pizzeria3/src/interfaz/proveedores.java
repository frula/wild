package interfaz;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import negocio.Proveedor;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class proveedores {

	private JFrame frmProveedores;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JLabel lblNewLabel_4; 
	private JButton btnModificar;
	private Proveedor proveedor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					proveedores window = new proveedores();
					window.frmProveedores.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public proveedores() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
    try
		
		{ 
		 UIManager.setLookAndFeel(
		 UIManager.getSystemLookAndFeelClassName());
		}
	 catch(Exception e) {};
		frmProveedores = new JFrame();
		frmProveedores.setTitle("Proveedores");
		frmProveedores.setBounds(100, 100, 450, 300);
		frmProveedores.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmProveedores.getContentPane().setLayout(null);
		proveedor=new Proveedor();
		
		JButton btnBuscar = new JButton("buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				lblNewLabel_4.setVisible(true);
				btnModificar.setVisible(true);
			}
		});
		btnBuscar.setBounds(310, 28, 89, 23);
		frmProveedores.getContentPane().add(btnBuscar);
		
		this.btnModificar = new JButton("modificar");
		btnModificar.setVisible(false);
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				lblNewLabel_4.setVisible(true);
			}
		});
		btnModificar.setBounds(310, 73, 89, 23);
		frmProveedores.getContentPane().add(btnModificar);
		
		JLabel lblNewLabel = new JLabel("Codigo");
		lblNewLabel.setBounds(28, 32, 56, 14);
		frmProveedores.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(105, 28, 105, 23);
		frmProveedores.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblDescripcion = new JLabel("Nombre");
		lblDescripcion.setBounds(28, 73, 62, 23);
		frmProveedores.getContentPane().add(lblDescripcion);
		
		textField_1 = new JTextField();
		textField_1.setBounds(104, 73, 106, 23);
		frmProveedores.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Categoria");
		lblNewLabel_1.setBounds(28, 116, 56, 23);
		frmProveedores.getContentPane().add(lblNewLabel_1);
		
		textField_2 = new JTextField();
		textField_2.setBounds(104, 116, 106, 23);
		frmProveedores.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Direccion");
		lblNewLabel_2.setBounds(28, 161, 56, 23);
		frmProveedores.getContentPane().add(lblNewLabel_2);
		
		textField_3 = new JTextField();
		textField_3.setBounds(105, 161, 106, 23);
		frmProveedores.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(105, 199, 105, 23);
		frmProveedores.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Tel");
		lblNewLabel_3.setBounds(28, 199, 62, 23);
		frmProveedores.getContentPane().add(lblNewLabel_3);
		
		JButton btnAceptar = new JButton("Guardar");
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String v=textField.getText();
				int v1= Integer.parseInt(v);
				String v2=textField_2.getText();
				int v3= Integer.parseInt(v2);
				proveedor.crear(v1, textField_1.getText(),v3,textField_3.getText(), textField.getText());
			}
		});
		
		
		btnAceptar.setBounds(229, 228, 89, 23);
		frmProveedores.getContentPane().add(btnAceptar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(335, 228, 89, 23);
		frmProveedores.getContentPane().add(btnCancelar);
		
		this.lblNewLabel_4 = new JLabel("ingrese codigo");
		lblNewLabel_4.setBounds(229, 28, 71, 23);
		frmProveedores.getContentPane().add(lblNewLabel_4);
		lblNewLabel_4.setVisible(false);
		
		
	}
}
