package negocio;

public class Cliente {

	private int idCliente;
	private String nombreCliente;
	private String dni;
	private String direccion;
	private String telefono;
	
	//Constructor con ID
	public Cliente(int idCliente, String nombreCliente, String dni,
			String direccion, String telefono) {
	
		this.idCliente = idCliente;
		this.nombreCliente = nombreCliente;
		this.dni = dni;
		this.direccion = direccion;
		this.telefono = telefono;
	}
	
	//Constructor sin ID
	public Cliente(String nombreCliente, String dni,
			String direccion, String telefono) {
	
		this.nombreCliente = nombreCliente;
		this.dni = dni;
		this.direccion = direccion;
		this.telefono = telefono;
	}

	public int getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public String getNombreCliente() {
		return nombreCliente;
	}

	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	
}
