package negocio;

import java.sql.ResultSet;
import java.sql.SQLException;

import datos.Basededatos;
import datos.Busqueda;

public class Proveedor {
	
	private int codigo;
	private String nombre;
	private int tipo;
	private String direccion;
	private String telefono;
	private int i=0;
	
	public Proveedor(){
		this.codigo=0;
		this.nombre="";
		this.tipo=0;
		this.direccion="";
		this.telefono="";
	}
	
	
	Proveedor(int codigo,String nombre,int tipo,String direccion,String telefono){
		this.codigo=codigo;
		this.nombre=nombre;
		this.tipo=tipo;
		this.direccion=direccion;
		this.telefono=telefono;
	}
	
	
	public int getCodigo(){
		return this.codigo;
	}
	
	public String getNombre(){
		return this.nombre;
	}
	
	public int getTipo(){
		return this.tipo;
	}
	public String getDireccion(){
		return this.direccion;
	}
	public String getTelefono(){
		return this.telefono;
		
	}
	
	public void setCodigo(int cod){
	     this.codigo=cod;
	}
	public void setNombre(String nombre){
		  this.nombre=nombre;
	}
	public void setTipo(int tipo){
		this.tipo=tipo;
	}
	public void setDireccion(String direccion){
		this.direccion=direccion;
	}
	public void setTelefono(String telefono){
		this.telefono=telefono;
	}
	
	
	public void  modificar(int codigo,String nombre,int tipo,String direccion,String telefono){
           this.setCodigo(codigo);
           this.setNombre(nombre);
           this.setTipo(tipo);
           this.setDireccion(direccion);
           this.setTelefono(telefono);
	}
	
	public Proveedor buscar(int codigo){
		Proveedor p=null;
		return p;
	}
	
	public void crear(int codigo,String nombre,int tipo,String direccion,String telefono){
		i++;
		Proveedor p=new Proveedor(codigo,nombre,tipo,direccion,telefono);
		String s=Integer.toString(codigo);
		String s1=Integer.toString(tipo);
		try {
			Basededatos.ejecutarsql("INSERT INTO proveedor(IDProveedor,Nombre,Telefono,Categoria,Direccion) VALUES(s,nombre,telefono,s1,direccion)");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
