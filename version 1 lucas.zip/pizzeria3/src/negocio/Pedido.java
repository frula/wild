package negocio;

import java.sql.Date;
import java.util.ArrayList;


public class Pedido {

	private int idPedido;
	private Cliente clientePedido;
	private Date fechaPedido;
	private ArrayList<Producto> productos;
	private double subTotal;
	private double totalPedido;
	private boolean pagoConfirmado;
	private boolean pedidoPreparado;	
	
	public Pedido(int idPedido, Cliente clientePedido, Date fechaPedido,
			ArrayList<Producto> productos, double subTotal, double totalPedido) {
	
		this.idPedido = idPedido;
		this.clientePedido = clientePedido;
		this.fechaPedido = fechaPedido;
		this.productos = productos;
		this.subTotal = subTotal;
		this.totalPedido = totalPedido;
		this.pagoConfirmado=false;
		this.pedidoPreparado=false;
	}


	public boolean isPagoConfirmado() {
		return pagoConfirmado;
	}


	public void setPagoConfirmado(boolean pagoConfirmado) {
		this.pagoConfirmado = pagoConfirmado;
	}


	public boolean isPedidoPreparado() {
		return pedidoPreparado;
	}


	public void setPedidoPreparado(boolean pedidoPreparado) {
		this.pedidoPreparado = pedidoPreparado;
	}


	public int getIdPedido() {
		return idPedido;
	}


	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}


	public Cliente getClientePedido() {
		return clientePedido;
	}


	public void setClientePedido(Cliente clientePedido) {
		this.clientePedido = clientePedido;
	}


	public Date getFechaPedido() {
		return fechaPedido;
	}


	public void setFechaPedido(Date fechaActual) {
		this.fechaPedido = fechaActual;
	}


	public ArrayList<Producto> getProductos() {
		return productos;
	}


	public void setProductos(ArrayList<Producto> productos) {
		this.productos = productos;
	}


	public double getSubTotal() {
		return subTotal;
	}


	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}


	public double getTotalPedido() {
		return totalPedido;
	}


	public void setTotalPedido(double totalPedido) {
		this.totalPedido = totalPedido;
	}
	

}
