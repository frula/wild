package modelo;


import java.util.ArrayList;
import java.util.List;

import persistencia.dao.PersonaDAO;
import dto.PersonaDTO;



public class Agenda 
{
	public static PersonaDAO persona;	
	
	public Agenda()
	{
		persona = new PersonaDAO();
	}
	
	public void agregarPersona(PersonaDTO nuevaPersona)
	{
		persona.insert(nuevaPersona);
	}

	public void borrarPersona(PersonaDTO persona_a_eliminar) 
	{
		persona.delete(persona_a_eliminar);
	}
	
	public static ArrayList<PersonaDTO> obtenerPersonas()
	{
		ArrayList<PersonaDTO> perso=persona.readAll();
		return perso;		
	}

	//Metodo para editar personas (...............)
	public void actualizaPersona(PersonaDTO persona_a_actualizar) 
	{
		persona.update(persona_a_actualizar);
	}
	
}
