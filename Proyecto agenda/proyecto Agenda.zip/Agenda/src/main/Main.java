package main;

import java.security.Principal;

import Negocio.MenuPrincipal;
import modelo.Agenda;
import presentacion.controlador.Controlador;
import presentacion.vista.Vista;


public class Main 
{

	public static void main(String[] args) 
	{
		MenuPrincipal principal = new MenuPrincipal();
		principal.setVisible(true);
	}
}
