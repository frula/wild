package persistencia.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

public class Conexion 
{
	public static Conexion instancia;
	private final static String driver = "com.mysql.jdbc.Driver";
	static Connection conexion;
	
	public Conexion()
	{
		try
		{
			Class.forName(driver).newInstance();
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/agenda","root","1234");
			System.out.println("Conexion exitosa");
		}
		catch(Exception e)
		{
			System.out.println("Conexion fallida");
		}
	}
	
	public static void establecerConexion() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conexion = DriverManager.getConnection("jdbc:mysql://127.0.0.1/agenda", "root", "1234");
		} catch (Exception e) {
			System.out.println("Imposible realizar conexion con la BD");
			e.printStackTrace();
		}
	}
	
	public static Conexion getConexion()   
	{								
		if(instancia == null)
		{
			instancia = new Conexion();
		}
		return instancia;
	}
	
	public static Connection DameConexion() {
		return conexion;
	}

	public Connection getSQLConexion() 
	{
		return conexion;
	}
	
	public void cerrarConexion()
	{
		instancia = null;
	}
	
	public static void cerrarconexion() {

		if (conexion != null) {
			try {
				conexion.close();
			} catch (Exception e) {
			}
		}
	}
	
	public static ResultSet consultasql(String sql) throws SQLException {

		establecerConexion();
		Statement stmt = Conexion.DameConexion().createStatement();
		ResultSet resultado = stmt.executeQuery(sql);
		if (resultado.next())
			return resultado;
		System.err.println("La consulta est� vacia");
		// cerrarconexion();
		return resultado;

	}

	public static void ejecutarsql(String sql) throws SQLException {

		 establecerConexion();
		Statement stmt =Conexion.DameConexion().createStatement();
		stmt.execute(sql);
		 cerrarconexion();
	}
	
	public static String dateToMySQLDate2(Date fecha)
	{
	java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
	return sdf.format(fecha);
	}
}
