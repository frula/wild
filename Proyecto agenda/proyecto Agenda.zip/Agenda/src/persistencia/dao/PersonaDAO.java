package persistencia.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import persistencia.conexion.Conexion;
import dto.PersonaDTO;

public class PersonaDAO 
{
	private int idPersonaAModificar;
	private static final String insert = "INSERT INTO personas(idPersona, nombre, telefono,email, cumplea�os,tipo,localidad,calle,altura,piso,depto,Provincia) " +
			"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
	private static final String delete = "DELETE FROM personas WHERE idPersona = ?";
	private static String update = "UPDATE personas SET Nombre=?,Telefono=?,Email=?,Cumplea�os=?,Tipo=?,Localidad=?,Calle=?,Altura=?,Piso=?,Depto=?,Provincia=? WHERE idPersona =";
	private static final String readall = "SELECT * FROM personas";
	private static final String readone = "SELECT * FROM personas WHERE idPersona=?";
	private static final Conexion conexion = Conexion.getConexion();
	
	public boolean insert(PersonaDTO persona)
	{
		
		PreparedStatement statement;
		try 
		{
			statement = conexion.getSQLConexion().prepareStatement(insert);
			statement.setInt(1, persona.getIdPersona());
			statement.setString(2, persona.getNombre());
			statement.setString(3, persona.getTelefono());
			statement.setString(4, persona.getEmail());
			statement.setString(5, persona.getCumplea�os());
			statement.setString(6, persona.getTipo());
			statement.setString(7, persona.getLocalidad());
			statement.setString(8, persona.getCalle());
			statement.setString(9, persona.getAltura());
			statement.setString(10,persona.getPiso());
			statement.setString(11,persona.getDepto());
			statement.setString(12,persona.getProv());
			
			if(statement.executeUpdate() > 0) //Si se ejecut� devuelvo true
				return true;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally //Se ejecuta siempre
		{
			conexion.cerrarConexion();
		}
		return false;
	}
	
	public boolean delete(PersonaDTO persona_a_eliminar)

	{
		PreparedStatement statement;
		int chequeoUpdate=0;
		try 
		{
			statement = conexion.getSQLConexion().prepareStatement(delete);
			statement.setString(1, Integer.toString(persona_a_eliminar.getIdPersona()));
			chequeoUpdate = statement.executeUpdate();
			if(chequeoUpdate > 0) //Si se ejecut� devuelvo true
				return true;
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally //Se ejecuta siempre
		{
			conexion.cerrarConexion();
		}
		return false;
	}
	
	//Actualizo los cambios en el contacto en la base
	public boolean update(PersonaDTO persona_a_actualizar)
	{
		idPersonaAModificar=persona_a_actualizar.getIdPersona();
		String sentenciaUpdate=update+idPersonaAModificar;
		PreparedStatement statement;
		try 
		{
			statement = conexion.getSQLConexion().prepareStatement(sentenciaUpdate);
			//statement.setInt(1, persona_a_actualizar.getIdPersona());
			statement.setString(1, persona_a_actualizar.getNombre());
			statement.setString(2, persona_a_actualizar.getTelefono());
			statement.setString(3, persona_a_actualizar.getEmail());
			statement.setString(4, persona_a_actualizar.getCumplea�os());
			statement.setString(5, persona_a_actualizar.getTipo());
			statement.setString(6, persona_a_actualizar.getLocalidad());
			statement.setString(7, persona_a_actualizar.getCalle());
			statement.setString(8, persona_a_actualizar.getAltura());
			statement.setString(9,persona_a_actualizar.getPiso());
			statement.setString(10,persona_a_actualizar.getDepto());
			statement.setString(11,persona_a_actualizar.getProv());
			
			if(statement.executeUpdate() > 0) //Si se ejecut� devuelvo true
				return true; 
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally //Se ejecuta siempre
		{
			conexion.cerrarConexion();
		}
		return false;
	}
	
	public ArrayList<PersonaDTO> readAll()
	{
		PreparedStatement statement;
		ResultSet resultSet; //Guarda el resultado de la query
		ArrayList<PersonaDTO> personas = new ArrayList<PersonaDTO>();
		try 
		{
			statement = conexion.getSQLConexion().prepareStatement(readall);
			resultSet = statement.executeQuery();
			
			while(resultSet.next())
			{
				//Se van creando las personas y se guardan en el ArrayList
				personas.add(new PersonaDTO(resultSet.getInt("idPersona"), resultSet.getString("Nombre"), resultSet.getString("Telefono"),
						resultSet.getString("Email"),resultSet.getString("Cumplea�os"),resultSet.getString("Tipo"),resultSet.getString("Localidad"),
						resultSet.getString("Calle"),resultSet.getString("Altura"),resultSet.getString("Piso"),
						resultSet.getString("Depto"),resultSet.getString("Provincia")));
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally //Se ejecuta siempre
		{
			conexion.cerrarConexion();
		}
		return personas;
	}

	//Devuelve la persona en la que estoy posicionado en la tabla
	public static PersonaDTO readOne(int idPersona)
	{
		PreparedStatement statement;
		ResultSet resultSet; //Guarda el resultado de la query
		PersonaDTO persona=null;
		try 
		{
			
			statement = conexion.getSQLConexion().prepareStatement(readone);
			statement.setInt(1, idPersona);
			resultSet = statement.executeQuery();
			
				//Creo la persona con los datos de la fila donde estoy parado
				persona = new PersonaDTO(resultSet.getInt("idPersona"), resultSet.getString("Nombre"), resultSet.getString("Telefono"),
						resultSet.getString("Email"),resultSet.getString("Cumplea�os"),resultSet.getString("Tipo"),resultSet.getString("Localidad"),
						resultSet.getString("Calle"),resultSet.getString("Altura"),resultSet.getString("Piso"),
						resultSet.getString("Depto"),resultSet.getString("Prov"));
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally //Se ejecuta siempre
		{
			conexion.cerrarConexion();
		}
		return persona;
	}
}
