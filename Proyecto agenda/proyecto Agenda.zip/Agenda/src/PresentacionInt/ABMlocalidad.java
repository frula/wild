package PresentacionInt;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.ImageIcon;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JComboBox;

import persistencia.conexion.Consultas;
import presentacion.controlador.Controlador;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JToggleButton;

public class ABMlocalidad extends JFrame {

	private JPanel contentPane;
	private JTextField texlocalidad;
	private JButton btnAgregar;
	private JButton btnModificar;
	private JButton btnEliminar;
	private JComboBox<String> cbProvincia;
	private JToggleButton tgbusqueda;
	private JComboBox<String> cbAllprov;
	private JLabel lblocalidad;	
	private JLabel lbprovincia;
	private boolean interruptor;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ABMlocalidad frame = new ABMlocalidad();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ABMlocalidad() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 384, 330);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lbltitulo = new JLabel("Localidad:");
		lbltitulo.setForeground(new Color(0, 0, 0));
		lbltitulo.setFont(new Font("Gungsuh", Font.PLAIN, 24));
		
		lblocalidad = new JLabel("Localidad:");
		lblocalidad.setFont(new Font("Gungsuh", Font.PLAIN, 16));
		
		lbprovincia = new JLabel("Provincia:");
		lbprovincia.setFont(new Font("Gungsuh", Font.PLAIN, 16));
		
		texlocalidad = new JTextField();
		texlocalidad.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent arg0) {
				desbloquear();
			}
		});
		texlocalidad.setFont(new Font("Gungsuh", Font.PLAIN, 12));
		texlocalidad.setColumns(10);
		
		btnAgregar = new JButton("Agregar");
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String loc=texlocalidad.getText();
				String prov=(String) cbProvincia.getSelectedItem();
				if(Consultas.LocalidadExistenteparaAgregar(loc, prov)==false){
					Consultas.AgregarLocalidad(loc, prov);
			}
				else{
					JOptionPane.showMessageDialog(null, "Registro existente","Warning",JOptionPane.WARNING_MESSAGE);
				}
				}
		});
		btnAgregar.setIcon(new ImageIcon(ABMlocalidad.class.getResource("/Imagenes/add-item.png")));
		
		btnModificar = new JButton("Modificar");
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String loc=getLocalidad();
				String prov=getProv();
				if(Consultas.LocalidadExistentemodyeli(loc, prov)==true){
				Consultas.ModificarLocalidad(loc,texlocalidad.getText(),prov,(String)cbProvincia.getSelectedItem());
				Consultas.ModificarLocalidadAgenda(loc,texlocalidad.getText(),prov,(String)cbProvincia.getSelectedItem());
				texlocalidad.setText("");
				inicializarComboAll();
				Controlador.actualizarTabla();
				}
				else{
					JOptionPane.showMessageDialog(null, "No se encontro registro","Warning",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnModificar.setIcon(new ImageIcon(ABMlocalidad.class.getResource("/Imagenes/edit.png")));
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String loc=getLocalidad();
				String prov=getProv();
				if(Consultas.LocalidadExistentemodyeli(loc, prov)){
					Consultas.EliminarLocalidad(loc, prov);
					inicializarComboAll();
			}
				else{
					JOptionPane.showMessageDialog(null, "No se encontro registro","Warning",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnEliminar.setIcon(new ImageIcon(ABMlocalidad.class.getResource("/Imagenes/delete-item.png")));
		
		cbProvincia = new JComboBox<String>();
		cbProvincia.setFont(new Font("Gungsuh", Font.BOLD, 12));
		
		cbAllprov = new JComboBox<String>();
		
		JLabel lblBusqueda = new JLabel("Busqueda");
		lblBusqueda.setFont(new Font("Gungsuh", Font.BOLD, 14));
		
		tgbusqueda = new JToggleButton("");
		tgbusqueda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(tgbusqueda.isSelected()){
					tgbusqueda.setIcon(new ImageIcon(ABMtipo.class.getResource("/Imagenes/SwitchOn.png")));
					interruptor=true;
					inicializarComboAll();
					texlocalidad.setText("");
					cbAllprov.setEnabled(true);
					cbProvincia.setEnabled(true);
					texlocalidad.setEnabled(true);
					btnAgregar.setEnabled(false);
					btnModificar.setEnabled(false);
					btnEliminar.setEnabled(true);
					lblocalidad.setText("Ingrese localidad para modificar");
					lbprovincia.setText("Seleccione provincia para modificar");
				}
				else{
					tgbusqueda.setIcon(new ImageIcon(ABMtipo.class.getResource("/Imagenes/SwitchOff.png")));
					interruptor=false;
					texlocalidad.setText("");
					cbAllprov.setEnabled(false);
					cbProvincia.setEnabled(true);
					texlocalidad.setEnabled(true);
					btnModificar.setEnabled(false);
					btnEliminar.setEnabled(false);
					lblocalidad.setText("Ingrese localidad");
					lbprovincia.setText("Seleccione provincia");
				}
			}
		});
		tgbusqueda.setIcon(new ImageIcon(ABMtipo.class.getResource("/Imagenes/SwitchOff.png")));

		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lbprovincia, GroupLayout.DEFAULT_SIZE, 272, Short.MAX_VALUE)
							.addGap(54))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(texlocalidad)
								.addComponent(lbltitulo)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(btnAgregar, GroupLayout.PREFERRED_SIZE, 103, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(btnModificar))
								.addComponent(cbProvincia, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(cbAllprov, GroupLayout.PREFERRED_SIZE, 209, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(btnEliminar))
								.addComponent(lblocalidad, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addContainerGap(18, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblBusqueda)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(tgbusqueda, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lbltitulo)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblBusqueda)
						.addComponent(tgbusqueda, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(cbAllprov, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnEliminar, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblocalidad)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(texlocalidad, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(lbprovincia)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(cbProvincia, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(20)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAgregar, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnModificar, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)))
		);
		contentPane.setLayout(gl_contentPane);
		iniciar();
		inicializarProvincias();
	}
	
	public void iniciar(){
		btnAgregar.setEnabled(false);
		btnEliminar.setEnabled(false);
		btnModificar.setEnabled(false);
		cbAllprov.setEnabled(false);
		
	}
	
	public void desbloquear(){
		boolean desbloqueo=true;
		if(texlocalidad.getText().equals("") ){
			desbloqueo=false;
		}
		if(interruptor==false){
		btnAgregar.setEnabled(desbloqueo);}
		if(interruptor==true){
		btnModificar.setEnabled(desbloqueo);}
	}
	
	public void inicializarProvincias(){
		cbProvincia.addItem("Buenos Aires"); cbProvincia.addItem("Catamarca");
		cbProvincia.addItem("Chaco"); cbProvincia.addItem("Chubut");
		cbProvincia.addItem("C�rdoba"); cbProvincia.addItem("Corrientes");
		cbProvincia.addItem("Entre R�os"); cbProvincia.addItem("Formosa");
		cbProvincia.addItem("Jujuy"); cbProvincia.addItem("La Pampa");
		cbProvincia.addItem("La Rioja"); cbProvincia.addItem("Mendoza");
		cbProvincia.addItem("Misiones"); cbProvincia.addItem("Neuqu�n");
		cbProvincia.addItem("R�o Negro"); cbProvincia.addItem("Salta");
		cbProvincia.addItem("San Juan"); cbProvincia.addItem("San Luis");
		cbProvincia.addItem("Santa Cruz"); cbProvincia.addItem("Santa Fe");
		cbProvincia.addItem("Santiago del Estero"); cbProvincia.addItem("Tierra del Fuego");
		cbProvincia.addItem("Tucum�n");
	}
	
	public void inicializarComboAll(){
		cbAllprov.removeAllItems();
		Consultas.devuelveLocalidades();
			for (int i=0;i<Consultas.localidades.size();i++){
				cbAllprov.addItem(Consultas.localidades.get(i).getLocalidad()+" ("+Consultas.localidades.get(i).getProvincia()+")");
			}
			}
	public String getLocalidad() {
		String Localidad=(String)cbAllprov.getSelectedItem();
		String loc="";
		boolean activar=true;
		for (int i=0; i<Localidad.length();i++){
			if(activar==true && Localidad.charAt(i)!='(' && Localidad.charAt(i+1)!='('){
				loc=loc+Localidad.charAt(i);
			}
			if(Localidad.charAt(i)=='(' ){
				activar=false;
			}
			}
		
		return String.valueOf(loc);
	}
	
	public String getProv(){
		String Localidad=(String)cbAllprov.getSelectedItem();
		String prov="";
		boolean activar=false;
		for (int i=0; i<Localidad.length();i++){
			if(activar==true && Localidad.charAt(i)!=')'){
				prov=prov+Localidad.charAt(i);
			}
			if(Localidad.charAt(i)=='('){
				activar=true;
			}
			else if(Localidad.charAt(i)==')'){
				activar=false;
			}
		
		
			}
		return prov;
		}
}
