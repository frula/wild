package PresentacionInt;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.ImageIcon;

import persistencia.conexion.Consultas;
import presentacion.controlador.Controlador;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JComboBox;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JToggleButton;

public class ABMtipo extends JFrame {

	private JPanel contentPane;
	private JTextField txtipo;
	private JButton btnAgregar;
	private JButton btnModificar;
	private JButton btnEliminar;
	private JToggleButton tgbusqueda;
	private static JComboBox<String> combo;
	private JLabel lbcomentario;
	private boolean interruptor;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ABMtipo frame = new ABMtipo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ABMtipo() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 405, 221);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblTipo = new JLabel("Categoria:");
		lblTipo.setFont(new Font("Gungsuh", Font.PLAIN, 22));
		
		lbcomentario = new JLabel("Nombre de categoria:");
		lbcomentario.setFont(new Font("Gungsuh", Font.BOLD, 14));
		
		txtipo = new JTextField();
		txtipo.setFont(new Font("Gungsuh", Font.PLAIN, 14));
		txtipo.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				desbloquear();
			}
		});
		txtipo.setColumns(10);
		
		btnAgregar = new JButton("Agregar");
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Consultas.TipoExistenteparaAgregar(txtipo.getText())==false){
					Consultas.AgregarTipo(txtipo.getText());
					}
				else{
					JOptionPane.showMessageDialog(null, "Registro existente","Warning",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnAgregar.setIcon(new ImageIcon(ABMtipo.class.getResource("/Imagenes/add-item.png")));
		btnAgregar.setFont(new Font("Gungsuh", Font.BOLD, 14));
		
		btnModificar = new JButton("Modificar");
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Consultas.TipoExistenteparaModyEli(txtipo.getText())==false){
					Consultas.ModificarTipo((String)combo.getSelectedItem(),txtipo.getText());
					Consultas.ModificarTipoAgenda((String)combo.getSelectedItem(),txtipo.getText());
					combo.removeAllItems();
					inicializarCombo();
					Controlador.actualizarTabla();
				}
				else{
					JOptionPane.showMessageDialog(null, "Registro "+txtipo.getText()+" existente","Warning",JOptionPane.WARNING_MESSAGE);
				}
				}
		});
		btnModificar.setIcon(new ImageIcon(ABMtipo.class.getResource("/Imagenes/edit.png")));
		btnModificar.setFont(new Font("Gungsuh", Font.BOLD, 14));
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Consultas.TipoExistenteparaModyEli((String)combo.getSelectedItem())){
					Consultas.EliminarTipo((String)combo.getSelectedItem());
					inicializarCombo();
				}
				else{
					JOptionPane.showMessageDialog(null, "No se encontro registro","Warning",JOptionPane.WARNING_MESSAGE);

				}
			}
		});
		btnEliminar.setIcon(new ImageIcon(ABMtipo.class.getResource("/Imagenes/delete-item.png")));
		btnEliminar.setFont(new Font("Gungsuh", Font.BOLD, 14));
		
		tgbusqueda = new JToggleButton("");
		tgbusqueda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {if(tgbusqueda.isSelected()){
				inicializarCombo();
				tgbusqueda.setIcon(new ImageIcon(ABMtipo.class.getResource("/Imagenes/SwitchOn.png")));
				txtipo.setText("");
				combo.setVisible(true);
				combo.setEnabled(true);
				txtipo.setVisible(true);
				txtipo.setEnabled(true);
				btnAgregar.setEnabled(false);
				btnModificar.setEnabled(false);
				btnEliminar.setEnabled(true);
				lbcomentario.setText("Ingrese Categoria para modificar");
				interruptor=true;
			}
			else{
				tgbusqueda.setIcon(new ImageIcon(ABMtipo.class.getResource("/Imagenes/SwitchOff.png")));
				txtipo.setText("");
				combo.setVisible(false);
				combo.setEnabled(false);
				txtipo.setVisible(true);
				txtipo.setEnabled(true);
				btnModificar.setEnabled(false);
				btnEliminar.setEnabled(false);
				lbcomentario.setText("Ingrese nombre de categoria:");
				interruptor=false;
			}
			}
		});
		tgbusqueda.setIcon(new ImageIcon(ABMtipo.class.getResource("/Imagenes/SwitchOff.png")));

		JLabel lblBusqueda = new JLabel("Busqueda:");
		lblBusqueda.setFont(new Font("Gungsuh", Font.BOLD, 14));
		
		combo = new JComboBox<String>();
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(combo, 0, 369, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblTipo)
							.addPreferredGap(ComponentPlacement.RELATED, 124, Short.MAX_VALUE)
							.addComponent(lblBusqueda)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(tgbusqueda, GroupLayout.PREFERRED_SIZE, 101, GroupLayout.PREFERRED_SIZE))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(btnAgregar)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(btnModificar)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnEliminar))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(lbcomentario, GroupLayout.DEFAULT_SIZE, 369, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(txtipo, GroupLayout.DEFAULT_SIZE, 369, Short.MAX_VALUE)))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(lblTipo)
							.addComponent(lblBusqueda))
						.addComponent(tgbusqueda, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(combo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(22)
					.addComponent(lbcomentario)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(txtipo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnEliminar)
						.addComponent(btnModificar)
						.addComponent(btnAgregar)))
		);
		contentPane.setLayout(gl_contentPane);
		inicializarCombo();
		iniciar();
	}
	
	public void iniciar(){
		btnAgregar.setEnabled(false);
		btnModificar.setEnabled(false);
		btnEliminar.setEnabled(false);
		combo.setVisible(false);
		combo.setEnabled(false);
	}
	
	public void desbloquear(){
		boolean bloqueo=true;
		if(txtipo.getText().equals("")){
			bloqueo=false;		}
		if(interruptor==false){
		btnAgregar.setEnabled(bloqueo);}
		if(interruptor==true){
			btnModificar.setEnabled(true);}
	}
	public static void inicializarCombo(){
		Consultas.borrarListaTipo();
		Consultas.devuelveTipos();
		combo.removeAllItems();
		for(int i=0;i<Consultas.tipos.size();i++){
			combo.addItem(Consultas.tipos.get(i).getTipo());
		}
	}
}
