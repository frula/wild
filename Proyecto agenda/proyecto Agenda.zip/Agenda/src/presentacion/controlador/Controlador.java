package presentacion.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import modelo.Agenda;
import persistencia.conexion.Busqueda;
import persistencia.conexion.Conexion;
import persistencia.conexion.Consultas;
import presentacion.reportes.ReporteAgenda;
import presentacion.vista.Mensajes;
import presentacion.vista.VentanaEdicion;
import presentacion.vista.VentanaPersona;
import presentacion.vista.Vista;
import dto.PersonaDTO;

import javax.swing.JComboBox;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

public class Controlador implements ActionListener {
	private static Vista vista;
	private static List<PersonaDTO> personas_en_tabla;
	private List<PersonaDTO> personasParaEdicion;
	private PersonaDTO personaAEditar;
	private VentanaPersona ventanaPersona;
	private VentanaEdicion ventanaEdicion;
	private Agenda agenda;

	public Controlador(Vista vista, Agenda agenda) {
		this.vista = vista;
		this.vista.getBtnAgregar().addActionListener(this);
		this.vista.getBtnBorrar().addActionListener(this);
		this.vista.getBtnReporte().addActionListener(this);
		this.vista.getBtnEditar().addActionListener(this);
		this.agenda = agenda;
		this.personas_en_tabla = null;
		this.ventanaEdicion = new VentanaEdicion(this);
		GroupLayout groupLayout = new GroupLayout(ventanaEdicion.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGap(0, 383, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGap(0, 324, Short.MAX_VALUE)
		);
		ventanaEdicion.getContentPane().setLayout(groupLayout);
		this.ventanaPersona = new VentanaPersona(this);
	}

	public void inicializar() {
		this.llenarTabla();
	}

	void llenarTabla() {
		this.vista.getModelPersonas().setRowCount(0); // Para vaciar la tabla
		this.vista.getModelPersonas().setColumnCount(0);
		this.vista.getModelPersonas().setColumnIdentifiers(
				this.vista.getNombreColumnas());

		this.personas_en_tabla = Agenda.obtenerPersonas();
		for (int i = 0; i < this.personas_en_tabla.size(); i++) {
			Object[] fila = {this.personas_en_tabla.get(i).getNombre(),
					this.personas_en_tabla.get(i).getTelefono(),
					this.personas_en_tabla.get(i).getEmail(),
					this.personas_en_tabla.get(i).getCumplea�os(),
					this.personas_en_tabla.get(i).getTipo(),
					this.personas_en_tabla.get(i).getLocalidad(),
					this.personas_en_tabla.get(i).getCalle(),
					this.personas_en_tabla.get(i).getAltura(),
					this.personas_en_tabla.get(i).getPiso(),
					this.personas_en_tabla.get(i).getDepto(),
					this.personas_en_tabla.get(i).getProv()};
			this.vista.getModelPersonas().addRow(fila);
		}
		this.vista.show();
	}
	//Completo el formulario para la edicion
	private void llenarParaEdicion() {
				
		String nombre,telefono,email,cumplea�os,tipo,localidad,calle,altura,piso,depto,provincia;
		
		altura=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 7));
		calle=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 6));
		cumplea�os=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 3));
		depto=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 9));
		email=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(),2));
		nombre=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 0));
		piso=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 8));
		telefono=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 1));
		tipo=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 4));
		localidad=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 5));
		provincia=String.valueOf(
				vista.getTablaPersonas().getValueAt(this.vista.devuelveFilaPersonaSeleccionada(), 10));
		
		//lleno los campos de la ventana de edicion
		//Faltan la localidad y el tipo
		this.ventanaEdicion.setTxtAltura(altura);
		this.ventanaEdicion.setTxtCalle(calle);
		this.ventanaEdicion.setComboLocalidad(localidad,provincia);
		try {
			this.ventanaEdicion.setTxtCumplea�os(cumplea�os);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.ventanaEdicion.setTxtDepto(depto);
		this.ventanaEdicion.setTxtMail(email);
		this.ventanaEdicion.setTxtNombre(nombre);
		this.ventanaEdicion.setTxtPiso(piso);
		this.ventanaEdicion.setTxtTelefono(telefono);
		this.ventanaEdicion.setTipo(tipo);
		this.ventanaEdicion.setLocalidad(localidad);
		
		
	}
	public static void actualizarTabla(){
		vista.getModelPersonas().setRowCount(0); // Para vaciar la tabla
		vista.getModelPersonas().setColumnCount(0);
		vista.getModelPersonas().setColumnIdentifiers(
				vista.getNombreColumnas());

		personas_en_tabla = Agenda.obtenerPersonas();
		for (int i = 0; i < personas_en_tabla.size(); i++) {
			Object[] fila = {personas_en_tabla.get(i).getNombre(),
					personas_en_tabla.get(i).getTelefono(),
					personas_en_tabla.get(i).getEmail(),
					personas_en_tabla.get(i).getCumplea�os(),
					personas_en_tabla.get(i).getTipo(),
					personas_en_tabla.get(i).getLocalidad(),
					personas_en_tabla.get(i).getCalle(),
					personas_en_tabla.get(i).getAltura(),
					personas_en_tabla.get(i).getPiso(),
					personas_en_tabla.get(i).getDepto(),
					personas_en_tabla.get(i).getProv()};
			vista.getModelPersonas().addRow(fila);
		}
		vista.show();
	}
	public PersonaDTO contactoAModificar(){
		int idPersonaSeleccionada=personas_en_tabla.get(vista.devuelveFilaPersonaSeleccionada()).getIdPersona();
		personaAEditar=new PersonaDTO(idPersonaSeleccionada,ventanaEdicion.getTxtNombre().getText(),ventanaEdicion.getTxtTelefono().getText()
				,ventanaEdicion.getTxtMail().getText(),ventanaEdicion.getTxtCumplea�os(),ventanaEdicion.getTipo(),
			ventanaEdicion.getLocalidad(),ventanaEdicion.getTxtCalle().getText(),ventanaEdicion.getTxtAltura().getText(),
			ventanaEdicion.getTxtPiso().getText(),ventanaEdicion.getTxtDepto().getText(),ventanaEdicion.getProv());
		System.out.println(ventanaEdicion.getProv());
		return personaAEditar;
	}
	
	
	@SuppressWarnings("static-access")
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == this.vista.getBtnAgregar()) {
			this.ventanaPersona = new VentanaPersona(this);
			this.ventanaPersona.setVisible(true);
			
					
		} else if (e.getSource() == this.vista.getBtnBorrar()) {
			int[] filas_seleccionadas = this.vista.getTablaPersonas()
					.getSelectedRows();
			for (int fila : filas_seleccionadas) {
				this.agenda.borrarPersona(this.personas_en_tabla.get(fila));
			}

			this.llenarTabla();

		} else if (e.getSource() == this.vista.getBtnEditar()) {
			
				//Abro el formulario para editar
		if(this.vista.getTablaPersonas().getSelectedRow()!=-1){
			this.ventanaEdicion = new VentanaEdicion(this);	
			this.ventanaEdicion.setVisible(true);
				this.llenarParaEdicion();
			
		}else Mensajes.lanzarMensajeInformativo("Debe seleccionar un contacto en la tabla");		
		
		}else if (e.getSource() == this.vista.getBtnReporte()) {
			//reporte.mostrar();
			
		    //String fecha2=(String)Conexion.dateToMySQLDate2(new Date());
		    //String fecha2=(String)(Conexion.dateToMySQLDate2(new Date()));
		    //System.out.println(fecha2);
		    Consultas.abrirReporte("reportes\\XProvincia.jasper",null,null);
		    
		} else if (e.getSource() == this.ventanaEdicion.getBtnGuardar()) {
			
			if(ventanaEdicion.getTxtNombre().getText().equals("")==false){
			this.agenda.actualizaPersona(this.contactoAModificar());
			this.llenarTabla();
			this.ventanaEdicion.dispose();
			}else Mensajes.lanzarMensajeInformativo("Debe completar al menos el nombre de contacto");
		}else if (e.getSource() == this.ventanaPersona.getBtnAgregarPersona()) {
		
			PersonaDTO nuevaPersona = new PersonaDTO(0, this.ventanaPersona
					.getTxtNombre().getText(), ventanaPersona.getTxtTelefono()
					.getText(), ventanaPersona.getTxtMail().getText(),
					ventanaPersona.getTxtCumplea�os(),
					ventanaPersona.getTipo(), ventanaPersona.getLocalidad(),
					ventanaPersona.getTxtCalle().getText(),
					ventanaPersona.getTxtAltura().getText(),
					ventanaPersona.getTxtPiso().getText(),
					ventanaPersona.getTxtDepto().getText(),
					ventanaPersona.getProv());
			
if(ventanaPersona.getTxtNombre().getText().equals("")==false){
			this.agenda.agregarPersona(nuevaPersona);
			this.llenarTabla();
			this.ventanaPersona.dispose();
}else Mensajes.lanzarMensajeInformativo("Debe completar al menos el nombre del contacto");
}
		
		
			}
	
	}


