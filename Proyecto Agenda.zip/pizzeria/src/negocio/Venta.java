package negocio;

public class Venta {
    private String fecha;  
	private int idproducto;
	private String producto;
	private int cantidad;
	private double preciounitario;
	
	public Venta(int idproducto,String producto,int cantidad,double preciounitario){
		this.idproducto=idproducto;
		this.producto=producto;
		this.cantidad=cantidad;
		this.preciounitario=preciounitario;
	}
	
	public Venta(String fecha,String producto,int cantidad,double preciounitario){
		this.fecha=fecha;
		this.producto=producto;
		this.cantidad=cantidad;
		this.preciounitario=preciounitario;
	}
	
	public int getIdproducto() {
		return idproducto;
	}

	public void setIdproducto(int idproducto) {
		this.idproducto = idproducto;
	}

	public String getProducto() {
		return producto;
	}

	public void setProducto(String producto) {
		this.producto = producto;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public double getPreciounitario() {
		return preciounitario;
	}

	public void setPreciounitario(double preciounitario) {
		this.preciounitario = preciounitario;
	}
	
	
}
