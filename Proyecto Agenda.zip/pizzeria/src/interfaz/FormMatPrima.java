/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz;

import datos.Pizzeria;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import negocio.Categoria;
import negocio.MateriaPrima;

import javax.swing.JComboBox;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;

import com.mxrck.autocompleter.TextAutoCompleter;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.RowSpec;

import net.miginfocom.swing.MigLayout;

import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;

public class FormMatPrima extends javax.swing.JFrame {
    ArrayList <MateriaPrima> materiasprimas = Pizzeria.devuelveMateriaPrima();
    int idBusqueda;
    boolean desbloquearAgregar=true;
    
    public FormMatPrima() {
    	setResizable(false);
        initComponents();
        limpiar();
        bloquear();
        iniciocombobox();
        
       
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txmatprima = new javax.swing.JTextField();
        btagregar = new javax.swing.JButton();
        btagregar.setIcon(new ImageIcon(FormMatPrima.class.getResource("/imagenes/Purpura/confirm_icon2.png")));
        btbloquear = new javax.swing.JButton();
        btbloquear.setIcon(new ImageIcon(FormMatPrima.class.getResource("/imagenes/Purpura/lock.png")));
        chhab = new javax.swing.JCheckBox();
        btnuevo = new javax.swing.JButton();
        btnuevo.setIcon(new ImageIcon(FormMatPrima.class.getResource("/imagenes/Purpura/add-item.png")));
        btbuscar = new javax.swing.JButton();
        btbuscar.setIcon(new ImageIcon(FormMatPrima.class.getResource("/imagenes/Purpura/search.png")));
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new Color(139, 0, 139));
        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new Font("Maiandra GD", Font.PLAIN, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Materia prima");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1Layout.setHorizontalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addContainerGap(288, Short.MAX_VALUE)
        			.addComponent(jLabel1)
        			.addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
        			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        			.addComponent(jLabel1)
        			.addContainerGap())
        );
        jPanel1.setLayout(jPanel1Layout);

        jLabel2.setText("Categoria");

        txmatprima.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txmatprimaActionPerformed(evt);
            }
        });
        txmatprima.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txmatprimaKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txmatprimaKeyTyped(evt);
            }
        });
        txmatprima.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent arg0) {
				 final TextAutoCompleter buscar = new TextAutoCompleter(txmatprima);
					for (int i = 0; i < materiasprimas.size(); i++) {
						buscar.addItem(materiasprimas.get(i).getnombre());
					}
			}
		});

        btagregar.setText("Agregar");
        btagregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btagregarActionPerformed(evt);
            }
        });

        btbloquear.setText("Bloquear");
        btbloquear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbloquearActionPerformed(evt);
            }
        });

        chhab.setText("Habilitado");

        btnuevo.setText("Nuevo");
        btnuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnuevoActionPerformed(evt);
            }
        });

        btbuscar.setText("Buscar");
        btbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbuscarActionPerformed(evt);
            }
        });
        
        cbcat = new JComboBox();
        btmodificar = new javax.swing.JButton();
        btmodificar.setIcon(new ImageIcon(FormMatPrima.class.getResource("/imagenes/Purpura/edit.png")));
        
                btmodificar.setText("Modificar");
                btmodificar.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        btmodificarActionPerformed(evt);
                    }
                });
                GroupLayout groupLayout = new GroupLayout(getContentPane());
                groupLayout.setHorizontalGroup(
                	groupLayout.createParallelGroup(Alignment.LEADING)
                		.addGroup(groupLayout.createSequentialGroup()
                			.addGap(23)
                			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                				.addGroup(groupLayout.createSequentialGroup()
                					.addPreferredGap(ComponentPlacement.RELATED)
                					.addComponent(btnuevo, GroupLayout.PREFERRED_SIZE, 96, GroupLayout.PREFERRED_SIZE)
                					.addPreferredGap(ComponentPlacement.RELATED)
                					.addComponent(btagregar, GroupLayout.PREFERRED_SIZE, 102, GroupLayout.PREFERRED_SIZE)
                					.addPreferredGap(ComponentPlacement.RELATED)
                					.addComponent(btbloquear, GroupLayout.PREFERRED_SIZE, 104, GroupLayout.PREFERRED_SIZE)
                					.addPreferredGap(ComponentPlacement.UNRELATED)
                					.addComponent(btmodificar))
                				.addGroup(groupLayout.createSequentialGroup()
                					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
                						.addGroup(groupLayout.createSequentialGroup()
                							.addComponent(jLabel2)
                							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                							.addComponent(cbcat, GroupLayout.PREFERRED_SIZE, 178, GroupLayout.PREFERRED_SIZE))
                						.addGroup(groupLayout.createSequentialGroup()
                							.addComponent(chhab)
                							.addPreferredGap(ComponentPlacement.RELATED)
                							.addComponent(txmatprima, GroupLayout.PREFERRED_SIZE, 177, GroupLayout.PREFERRED_SIZE)))
                					.addPreferredGap(ComponentPlacement.RELATED)
                					.addComponent(btbuscar)))
                			.addGap(10))
                		.addGroup(groupLayout.createSequentialGroup()
                			.addContainerGap()
                			.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, 436, Short.MAX_VALUE)
                			.addContainerGap())
                );
                groupLayout.setVerticalGroup(
                	groupLayout.createParallelGroup(Alignment.LEADING)
                		.addGroup(groupLayout.createSequentialGroup()
                			.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE)
                			.addGap(8)
                			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                				.addComponent(chhab)
                				.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
                					.addComponent(btbuscar)
                					.addComponent(txmatprima, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
                			.addGap(18)
                			.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
                				.addComponent(jLabel2)
                				.addComponent(cbcat, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                			.addGap(18)
                			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                				.addComponent(btnuevo, GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                				.addComponent(btmodificar, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                				.addComponent(btbloquear, GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                				.addComponent(btagregar, GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)))
                );
                getContentPane().setLayout(groupLayout);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    void limpiar (){
       txmatprima.setText("Ingrese nombre Mat. Prima");
    }
    
    void iniciocombobox(){
    	ArrayList<Categoria> categoria=Pizzeria.devuelveCategoria();
    	for(int i=0;i<categoria.size();i++){
    		cbcat.addItem(categoria.get(i).getnombre());
    	}
    }
    
    void bloquear(){
       txmatprima.setEnabled(true);
       
       btnuevo.setEnabled(true);
       btagregar.setEnabled(false);
       btbloquear.setEnabled(false);
       btmodificar.setEnabled(false);
       chhab.setEnabled(false);
       chhab.setSelected(true);
    }
    
       void desbloquear(){
      
      // txcat.setEnabled(true);
       txmatprima.setEnabled(true);
        
       
       btnuevo.setEnabled(true);
       btagregar.setEnabled(false);
       btbloquear.setEnabled(false);
       btmodificar.setEnabled(false);
       chhab.setEnabled(false);
    }
       void desbloquearGuardar(){
        boolean desbloqueo=true;
        
        if(txmatprima.getText().equals("") || desbloquearAgregar==false){
            desbloqueo=false;}
        else{
            desbloqueo=true;}
        
        btagregar.setEnabled(desbloqueo);
        }
       
       void desbloquearBloMod(){
         btmodificar.setEnabled(true);
         btbloquear.setEnabled(true);
       }
       
       void desbloquearBloqHab(int es){
         if(es==0){chhab.setSelected(false);}
         else if(es==1){chhab.setSelected(true);}
       }
       
       void actualizar(){
    	   materiasprimas=Pizzeria.devuelveMateriaPrima();
       }
    
    private void btagregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btagregarActionPerformed
    	ArrayList <Categoria> categoria = Pizzeria.devuelveCategoria();
    	
        //0=EstaMarcado 1=NOestaMarcado
        int es;
        if(chhab.isSelected()){
           es=1; 
        }
        else{
            es=0;
        }
        String nombre=txmatprima.getText().toUpperCase();
        int setid=Pizzeria.devuelveMayorColumna("materiaprima", "idMatPrima")+1;
        
        int cat = 0;
        String cateselec=(String) cbcat.getSelectedItem();
        //String cat=txcat.getText();
        for(int i=0;i<categoria.size();i++){
        	if(cateselec.equals(categoria.get(i).getnombre())){
        		cat=categoria.get(i).getid();
        	}
        }
        Pizzeria.agregarmatprima(setid,nombre,cat,es);
        bloquear();
        actualizar();
    }//GEN-LAST:event_btagregarActionPerformed

    private void btbloquearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbloquearActionPerformed
        int id=idBusqueda;
        int es;
        if(chhab.isSelected()){
           es=0; 
        }
        else{
            es=1;
        }
        Pizzeria.bloquarDesbloquearMatprima(id, es);
        desbloquearBloqHab(es);
        actualizar();
    }//GEN-LAST:event_btbloquearActionPerformed

	private void btmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmodificarActionPerformed
    	ArrayList <Categoria> categoria = Pizzeria.devuelveCategoria();
        String nombre=txmatprima.getText().toUpperCase();
        int id=idBusqueda;
        int cat = 0;
        for(int i=0;i<categoria.size();i++){
        	if(cbcat.getSelectedItem().equals(categoria.get(i).getnombre())){
        		cat=categoria.get(i).getid();
        	}
        }
        
        Pizzeria.modificarmatprima(id, nombre,cat);      
        actualizar();
    }//GEN-LAST:event_btmodificarActionPerformed

    private void txmatprimaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txmatprimaActionPerformed
        if(txmatprima.getText().equals("")){
            txmatprima.requestFocus();
        }
        else{
            txmatprima.transferFocus(); 
        } 
    }//GEN-LAST:event_txmatprimaActionPerformed

    private void btnuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnuevoActionPerformed
    	ArrayList<Categoria> categoria = Pizzeria.devuelveCategoria();
        chhab.setSelected(true);
        limpiar();
        desbloquear();
        String setid=Integer.toString(materiasprimas.size()+1);
        desbloquearAgregar=true;
       
   }//GEN-LAST:event_btnuevoActionPerformed

    private void txmatprimaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txmatprimaKeyTyped
        desbloquearGuardar();
    }//GEN-LAST:event_txmatprimaKeyTyped

    private void txmatprimaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txmatprimaKeyReleased
        /*char c = evt.getKeyChar();
        String aux = txmatprima.getText();
        txmatprima.setText("");
        if(!aux.isEmpty()){
            aux=aux.substring(0,aux.length()-1);
        System.out.println(aux.length()-1);
        aux+=String.valueOf(c).toUpperCase();
        txmatprima.setText(aux);}*/
        desbloquearGuardar();
    }//GEN-LAST:event_txmatprimaKeyReleased

    private void btbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbuscarActionPerformed
    	ArrayList <Categoria>categoria=Pizzeria.devuelveCategoria();
        String nombre=txmatprima.getText().toUpperCase();
        desbloquearAgregar=false;
        boolean existe=false;
        for(int i=0;i<materiasprimas.size();i++){
        if(nombre.equals(materiasprimas.get(i).getnombre())){
            idBusqueda=(materiasprimas.get(i).getidmp());
        
            txmatprima.setText(materiasprimas.get(i).getnombre());
            int cat=Integer.valueOf(materiasprimas.get(i).getcategoria());
            //txcat.setText(cat); 
            if(materiasprimas.get(i).gethabilitado()==1){
            chhab.setSelected(true);
            }
            else if (materiasprimas.get(i).gethabilitado()==0){
            chhab.setSelected(false);         
            }
            
            for(int j=0;j<categoria.size();j++){
            	if(cat==categoria.get(j).getid()){
            		cbcat.setSelectedItem(categoria.get(j).getnombre());
            	}
            }
            existe=true;
            btagregar.setEnabled(false);
            desbloquear();
            desbloquearBloMod();
        }
        else if(existe==false && i==materiasprimas.size()-1){
            txmatprima.requestFocus();
            JOptionPane.showMessageDialog(null,"No se encontro ningun registro");
        }       
        }
    }//GEN-LAST:event_btbuscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormMatPrima.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormMatPrima.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormMatPrima.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormMatPrima.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                FormMatPrima dialog = new FormMatPrima();
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btagregar;
    private javax.swing.JButton btbloquear;
    private javax.swing.JButton btbuscar;
    private javax.swing.JButton btmodificar;
    private javax.swing.JButton btnuevo;
    private javax.swing.JCheckBox chhab;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txmatprima;
    private JComboBox cbcat;

}
