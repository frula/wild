package interfaz;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JToolBar;
import javax.swing.JMenuBar;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLayeredPane;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;

import negocio.Venta;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import datos.Basededatos;
import datos.Pizzeria;

import javax.swing.border.LineBorder;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentaReporte extends JFrame {
	ArrayList<Venta> venta= Pizzeria.cantidadproductos();
	JScrollPane scrollPane = new javax.swing.JScrollPane();
	private javax.swing.JLayeredPane capas;
    private javax.swing.JPanel barras;
	final DefaultTableModel datostabla = new DefaultTableModel();
	private JMenuBar menuBar;
	private JMenuBar mb;
	private JMenu menu1;
	private JMenuItem mi1, mi2, mi3,mi4;
	
	private JTable tabla;
	private double gananciasTotales;
	private ChartPanel panel;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentaReporte frame = new VentaReporte();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentaReporte() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 701, 429);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		capas = new JLayeredPane();
		capas.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addComponent(capas, GroupLayout.DEFAULT_SIZE, 431, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 238, GroupLayout.PREFERRED_SIZE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addGap(2)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(capas, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 218, Short.MAX_VALUE)
						.addComponent(scrollPane, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 273, Short.MAX_VALUE))
					.addContainerGap())
		);
		// Creo el menu contenedor
		mb = new JMenuBar();
		setJMenuBar(mb);

		// Creo el menu principal
		menu1 = new JMenu("Imprimir Reporte");
		mb.add(menu1);
        mi1 = new JMenuItem("Reporte Diario");
        mi1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		String fecha=Basededatos.dateToMySQLDate2(new Date());
        		
        		if (e.getSource() == mi1) {
        			Pizzeria.abrirReporte("C:\\Users\\user\\Pictures\\pizzeriawild\\Reportedeldia.jasper",
        					fecha, "Fecha");
        		}
        	}
        });
        mi3 = new JMenuItem("Reporte Mensual");
        mi3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		String fecha=Basededatos.dateToMySQLDate2(new Date());
        		
        		if (e.getSource() == mi3) {
        			Pizzeria.abrirReporte("C:\\Users\\user\\Pictures\\pizzeriawild\\src\\reportes\\ReporteMes.jasper",
        					fecha, "Fecha");
        		}
        	}
        });
        mi4 = new JMenuItem("Reporte del dia...");
        mi4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if (e.getSource() == mi4) {
        			ReportedeldiaX report = new ReportedeldiaX();
        			report.setVisible(true);
        		}
        	}
        });

        menu1.add(mi1); 
        menu1.add(mi4);
        menu1.add(mi3); 
		tabla = new JTable();
		scrollPane.setColumnHeaderView(tabla);
		
		barras = new JPanel();
		barras.setBounds(10, 11, 411, 325);
		capas.add(barras);
		contentPane.setLayout(gl_contentPane);
		tabla.setModel(datostabla);
        scrollPane.setViewportView(tabla);
		datostabla.setDataVector(new Object[][] { }, new Object[] {
		         "Producto","Cantidad","C/U"});
		graficar();
		llenarTabla();
	}
	
	public void graficar(){
		JFreeChart chart=null;
		
		DefaultCategoryDataset data = new DefaultCategoryDataset();
        
		for(int i=0;i<venta.size();i++){
			data.addValue(venta.get(i).getCantidad(), venta.get(i).getProducto(), venta.get(i).getProducto());
		}
		
		chart=ChartFactory.createBarChart("Productos vendidos",
				"Producto", 
				"Cantidad", 
				data, 
				PlotOrientation.HORIZONTAL, 
				true, 
				true, 
				true);
		CategoryPlot plot = (CategoryPlot) chart.getPlot();
		plot.setDomainGridlinesVisible(true);
		panel=new ChartPanel(chart);
		panel.setPreferredSize(new Dimension(400, 320));

		barras.add(panel);
		barras.repaint();
	}
	public void llenarTabla(){
	tabla.getColumn("Producto").setPreferredWidth(150);
	
	
	  for(int i=0;i<venta.size();i++){
		  datostabla.addRow(new Object[] {
	                 venta.get(i).getProducto(),venta.get(i).getCantidad(),venta.get(i).getPreciounitario()});
	  }
	}
}
