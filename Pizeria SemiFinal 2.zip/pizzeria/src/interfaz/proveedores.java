package interfaz;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import negocio.Categoria;
import negocio.Categoria2;
import negocio.Proveedor;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JPanel;

import java.awt.Font;
import java.awt.Color;

import javax.swing.JCheckBox;

import com.mxrck.autocompleter.TextAutoCompleter;

import datos.Pizzeria;
import java.awt.event.KeyAdapter;

public class proveedores extends javax.swing.JFrame{
    ArrayList<Proveedor>prov=Pizzeria.devuelveProveedores();
    
	private JFrame frmProveedores;
	private JTextField txnombre;
	private JTextField txtel;
	private JButton btnModificar;
	private Proveedor proveedor;
	private JTextField txbuscar;
	private JComboBox cbcategoria;
	private JLabel lblNewLabel;
    private JLabel lblNewLabel_2; 
    private JButton btnModificarEstado;


	/**
	 * Launch the application.
	 */


	/**
	 * Create the application.
	 */
	public proveedores() {
		setResizable(false);
        initialize();
        
		
		
	txbuscar.addKeyListener(new KeyAdapter() {
		public void keyPressed(KeyEvent arg0) {
				
			final TextAutoCompleter busqueda = new TextAutoCompleter(txbuscar);
						for (int i = 0; i < prov.size(); i++) {
							busqueda.addItem(prov.get(i).getNombre());
						}
			}
			
		});
	}

	
		
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
    try
		
		{ 
		 UIManager.setLookAndFeel(
		 UIManager.getSystemLookAndFeelClassName());
		}
	 catch(Exception e) {};
		frmProveedores = new JFrame();
		frmProveedores.setResizable(false);
		frmProveedores.setTitle("Proveedores");
		frmProveedores.setBounds(100, 100, 450, 300);
		frmProveedores.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmProveedores.getContentPane().setLayout(null);
		proveedor=new Proveedor();
		
		JButton btnBuscar = new JButton("buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(Proveedor.existeProveedor(txbuscar.getText())==false){
					JOptionPane.showMessageDialog(frmProveedores,"No existe proveedor","Problemas", JOptionPane.WARNING_MESSAGE);
				  } 
				else{
				
				proveedor=Proveedor.buscar(txbuscar.getText());
				txnombre.setText(proveedor.getNombre());
				txtel.setText(proveedor.getTelefono());
				
				if(proveedor.getEstado()==1){
				lblNewLabel_2.setText("Activo");
				}
				if(proveedor.getEstado()==0){
				lblNewLabel_2.setText("Inactivo");
				}
				cbcategoria.setSelectedItem(proveedor.getTipo());
				//lblNewLabel_4.setVisible(true);
				btnModificar.setVisible(true);
				btnModificarEstado.setVisible(true);
				//lblNewLabel_4.setText(proveedor.getTipo());
			 }
			}	
		});
		btnBuscar.setBounds(345, 45, 89, 23);
		frmProveedores.getContentPane().add(btnBuscar);
		
		this.btnModificar = new JButton("modificar");
		btnModificar.setVisible(false);
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				proveedor.modificar(txnombre.getText(),cbcategoria.getSelectedItem().toString(),txtel.getText());
				//lblNewLabel_4.setVisible(true);
			    btnModificarEstado.setVisible(false);
			    btnModificar.setVisible(false);
			    txnombre.setText("");
			    txtel.setText("");
			    lblNewLabel_2.setText("");
			    Actualizar();
			    txbuscar.setText("");
			    //lblNewLabel_4.setText("");
			}
		});
		btnModificar.setBounds(109, 238, 89, 23);
		frmProveedores.getContentPane().add(btnModificar);
		
		JLabel lblDescripcion = new JLabel("Nombre");
		lblDescripcion.setBounds(22, 96, 62, 23);
		frmProveedores.getContentPane().add(lblDescripcion);
		
		txnombre = new JTextField();
		txnombre.setBounds(93, 96, 106, 23);
		frmProveedores.getContentPane().add(txnombre);
		txnombre.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Categoria");
		lblNewLabel_1.setBounds(22, 130, 56, 23);
		frmProveedores.getContentPane().add(lblNewLabel_1);
		
		txtel = new JTextField();
		txtel.setBounds(94, 164, 105, 23);
		frmProveedores.getContentPane().add(txtel);
		txtel.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Tel");
		lblNewLabel_3.setBounds(22, 164, 62, 23);
		frmProveedores.getContentPane().add(lblNewLabel_3);
		
		
		
		JButton btnAceptar = new JButton("Guardar");
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(txnombre.getText().equals("")==true || txtel.getText().equals("")==true){
					JOptionPane.showMessageDialog(frmProveedores,"No fueron ingresados datos","Problemas", JOptionPane.WARNING_MESSAGE);	
				}
				else{
				proveedor.crear(txnombre.getText(),cbcategoria.getSelectedItem().toString(),txtel.getText(),1);
				 txnombre.setText("");
				 txtel.setText("");
				 lblNewLabel_2.setText("");
				 //lblNewLabel_4.setText("");
			}
				final TextAutoCompleter bus = new TextAutoCompleter(txbuscar);
				for (int i = 0; i < prov.size(); i++) {
					bus.addItem(prov.get(i).getNombre());
				}
			}
			
		});
		
		
		btnAceptar.setBounds(10, 238, 89, 23);
		frmProveedores.getContentPane().add(btnAceptar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frmProveedores.setVisible(false);
			}
		});
		btnCancelar.setBounds(345, 238, 89, 23);
		frmProveedores.getContentPane().add(btnCancelar);
		
		txbuscar = new JTextField();
		
		txbuscar.setBounds(208, 45, 132, 23);
		frmProveedores.getContentPane().add(txbuscar);
		txbuscar.setColumns(10);
		
		cbcategoria = new JComboBox();
		cbcategoria.setBounds(92, 130, 106, 23);
		ArrayList lista=Categoria2.categorias();
		//comboBox.setModel(new DefaultComboBoxModel(new String[]{}));
		int i=0;
		while(i<lista.size()){
			//System.out.println(lista.get(i));
			cbcategoria.addItem(lista.get(i));
			i++;
		}
		frmProveedores.getContentPane().add(cbcategoria);
		
		lblNewLabel = new JLabel("Estado");
		lblNewLabel.setBounds(22, 198, 56, 29);
		frmProveedores.getContentPane().add(lblNewLabel);
		
		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(92, 198, 106, 24);
		frmProveedores.getContentPane().add(lblNewLabel_2);
		
		btnModificarEstado = new JButton("Modificar estado");
		btnModificarEstado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				proveedor.cambiarEstado();
				txnombre.setText("");
				txtel.setText("");
				lblNewLabel_2.setText("");
				//lblNewLabel_4.setText("");
				btnModificarEstado.setVisible(false);
				btnModificar.setVisible(false);
			}
		});
		btnModificarEstado.setBounds(208, 238, 120, 23);
		frmProveedores.getContentPane().add(btnModificarEstado);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(47, 79, 79));
		panel.setForeground(new Color(189, 183, 107));
		panel.setBounds(0, 0, 444, 29);
		frmProveedores.getContentPane().add(panel);
		
		JLabel lblProveedor = new JLabel("Proveedor");
		lblProveedor.setForeground(Color.LIGHT_GRAY);
		lblProveedor.setBackground(Color.WHITE);
		lblProveedor.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		panel.add(lblProveedor);
		btnModificarEstado.setVisible(false);
		
		
	}

	public void setVisible(boolean b) {
		frmProveedores.setVisible(b);
		
	}
	
	
	public void Actualizar(){
		this.prov=Pizzeria.devuelveProveedores();
		for (int i =0;i<prov.size();i++){
			System.out.print(prov.get(i).getNombre());
		}
	}
	 public static void main(String args[]) {
	        /* Set the Nimbus look and feel */
	        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
	        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
	         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
	         */
		 
	        try {
	            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
	                if ("Nimbus".equals(info.getName())) {
	                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
	                    break;
	                }
	            }
	        } catch (ClassNotFoundException ex) {
	            java.util.logging.Logger.getLogger(proveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (InstantiationException ex) {
	            java.util.logging.Logger.getLogger(proveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (IllegalAccessException ex) {
	            java.util.logging.Logger.getLogger(proveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
	            java.util.logging.Logger.getLogger(proveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        }
	        //</editor-fold>

	        /* Create and display the dialog */
	        java.awt.EventQueue.invokeLater(new Runnable() {
	            public void run() {
	          
	            	proveedores dialog = new proveedores();
	                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
	                    @Override
	                    public void windowClosing(java.awt.event.WindowEvent e) {
	                        System.exit(0);
	                     
	                    }
	                    
	                });
	                dialog.setVisible(true);
	
	            }
	        });
	    }
}
