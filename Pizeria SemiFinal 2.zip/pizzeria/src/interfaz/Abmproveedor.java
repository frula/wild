package interfaz;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.event.DocumentEvent;

import negocio.Categoria;
import negocio.Proveedor;

import com.mxrck.autocompleter.*;

import datos.Pizzeria;

public class Abmproveedor extends javax.swing.JFrame {

    ArrayList <Proveedor> proveedor= Pizzeria.devuelveProveedores();
    boolean modificado=false;
    private Proveedor proveed;
    int id=proveedor.size()+2;
    public Abmproveedor() {
    	setResizable(false);
        initComponents();
        inicio();
        
       /* final TextAutoCompleter busqueda = new TextAutoCompleter(txbuscar);
		for (int i = 0; i < clientes.size(); i++) {

			busqueda.addItem(clientes.get(i).getNombreCliente());
		}*/
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txbuscar = new javax.swing.JTextField();
        txbuscar.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent arg0) {
        		final TextAutoCompleter busq = new TextAutoCompleter(txbuscar);

				for (int i = 0; i < Pizzeria.devuelveProveedores().size(); i++) {
        			busq.addItem(Pizzeria.devuelveProveedores().get(i).toString());
        		}
        	}
        });
        txbuscar.setBackground(Color.CYAN);
       

     
        
        txbuscar.getDocument().addDocumentListener(
        		new javax.swing.event.DocumentListener(){

        		

				@Override
				public void changedUpdate(DocumentEvent arg0) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void removeUpdate(DocumentEvent arg0) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void insertUpdate(DocumentEvent arg0) {
					// TODO Auto-generated method stub
					
				}
				
				
        		});
        
            		
        lbnombre = new javax.swing.JLabel();
        lbtel = new javax.swing.JLabel();
        lbcat = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setName("panel"); // NOI18N

        jLabel1.setFont(new Font("Rod", Font.PLAIN, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Proveedor");

     
        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1Layout.setHorizontalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(jLabel2, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
        			.addPreferredGap(ComponentPlacement.RELATED, 225, Short.MAX_VALUE)
        			.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 169, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        		.addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addGap(11)
        			.addComponent(jLabel1, GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE))
        );
        jPanel1.setLayout(jPanel1Layout);

        txbuscar.setText("Ingrese DNI");
       

        lbnombre.setText("Nombre:");

        lbtel.setText("Telefono");

        lbcat.setText("Categoria:");
                btmod = new javax.swing.JButton();
                
                        btmod.setText("Modificar");
                        btmod.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btmodActionPerformed(evt);
                            }
                        });
                        btbuscar = new javax.swing.JButton();
                        
                                btbuscar.setText("Buscar");
                                btbuscar.addActionListener(new java.awt.event.ActionListener() {
                                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                                        btbuscarActionPerformed(evt);
                                    }
                                });
                        checkhab = new javax.swing.JCheckBox();
                        
                                checkhab.setText("Habilitado");
                                checkhab.addActionListener(new java.awt.event.ActionListener() {
                                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                                        checkhabActionPerformed(evt);
                                    }
                                });
        btbloquear = new javax.swing.JButton();
        
        
                btbloquear.setText("Bloqueo/Desbloqueo");
                btbloquear.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        btbloquearActionPerformed(evt);
                    }
                });
        txnombre = new javax.swing.JTextField();
        
                txnombre.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        txnombreActionPerformed(evt);
                    }
                });
                txnombre.addKeyListener(new java.awt.event.KeyAdapter() {
                    public void keyReleased(java.awt.event.KeyEvent evt) {
                        txnombreKeyReleased(evt);
                    }
                    public void keyTyped(java.awt.event.KeyEvent evt) {
                        txnombreKeyTyped(evt);
                    }
                });
                txtel = new javax.swing.JTextField();
                
                        txtel.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txdirActionPerformed(evt);
                            }
                        });
                        txtel.addKeyListener(new java.awt.event.KeyAdapter() {
                            public void keyReleased(java.awt.event.KeyEvent evt) {
                                txdirKeyReleased(evt);
                            }
                            public void keyTyped(java.awt.event.KeyEvent evt) {
                                txdirKeyTyped(evt);
                            }
                        });
                                btagregar = new javax.swing.JButton();
                                
                                
                                        btagregar.setText("Confirmar Nuevo");
                                        btagregar.addActionListener(new java.awt.event.ActionListener() {
                                            public void actionPerformed(java.awt.event.ActionEvent evt) {
                                                btagregarActionPerformed(evt);
                                            }
                                        });
                                        
                                        cbcat = new JComboBox();
                                                                btnuevo = new javax.swing.JButton();
                                                                
                                                                        btnuevo.setText("Nuevo");
                                                                        btnuevo.addActionListener(new java.awt.event.ActionListener() {
                                                                            public void actionPerformed(java.awt.event.ActionEvent evt) {
                                                                                btnuevoActionPerformed(evt);
                                                                            }
                                                                        });
                                                                        
                                                                        JLabel lblId = new JLabel("DNI:");
                                                                        
                                                                        txdni = new JTextField();
                                                                        txdni.setColumns(10);
                                                                        GroupLayout groupLayout = new GroupLayout(getContentPane());
                                                                        groupLayout.setHorizontalGroup(
                                                                        	groupLayout.createParallelGroup(Alignment.LEADING)
                                                                        		.addGroup(groupLayout.createSequentialGroup()
                                                                        			.addGap(7)
                                                                        			.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, 450, GroupLayout.PREFERRED_SIZE))
                                                                        		.addGroup(groupLayout.createSequentialGroup()
                                                                        			.addGap(7)
                                                                        			.addComponent(btbuscar, GroupLayout.PREFERRED_SIZE, 108, GroupLayout.PREFERRED_SIZE)
                                                                        			.addGap(30)
                                                                        			.addComponent(txbuscar, GroupLayout.PREFERRED_SIZE, 312, GroupLayout.PREFERRED_SIZE))
                                                                        		.addGroup(groupLayout.createSequentialGroup()
                                                                        			.addGap(7)
                                                                        			.addComponent(checkhab)
                                                                        			.addGap(106)
                                                                        			.addComponent(btmod, GroupLayout.PREFERRED_SIZE, 133, GroupLayout.PREFERRED_SIZE)
                                                                        			.addGap(4)
                                                                        			.addComponent(btnuevo, GroupLayout.PREFERRED_SIZE, 134, GroupLayout.PREFERRED_SIZE))
                                                                        		.addGroup(groupLayout.createSequentialGroup()
                                                                        			.addComponent(lbtel, GroupLayout.PREFERRED_SIZE, 49, GroupLayout.PREFERRED_SIZE)
                                                                        			.addGap(5)
                                                                        			.addComponent(txtel, GroupLayout.PREFERRED_SIZE, 398, GroupLayout.PREFERRED_SIZE))
                                                                        		.addGroup(groupLayout.createSequentialGroup()
                                                                        			.addComponent(lbcat, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                                                                        			.addPreferredGap(ComponentPlacement.RELATED)
                                                                        			.addComponent(cbcat, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
                                                                        			.addPreferredGap(ComponentPlacement.UNRELATED)
                                                                        			.addComponent(btagregar, GroupLayout.PREFERRED_SIZE, 271, GroupLayout.PREFERRED_SIZE))
                                                                        		.addGroup(groupLayout.createSequentialGroup()
                                                                        			.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
                                                                        				.addComponent(lblId, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                        				.addComponent(lbnombre, GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE))
                                                                        			.addGap(11)
                                                                        			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
                                                                        				.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
                                                                        					.addComponent(txdni)
                                                                        					.addGap(171)
                                                                        					.addComponent(btbloquear, GroupLayout.PREFERRED_SIZE, 134, GroupLayout.PREFERRED_SIZE))
                                                                        				.addComponent(txnombre, GroupLayout.PREFERRED_SIZE, 398, GroupLayout.PREFERRED_SIZE)))
                                                                        );
                                                                        groupLayout.setVerticalGroup(
                                                                        	groupLayout.createParallelGroup(Alignment.LEADING)
                                                                        		.addGroup(groupLayout.createSequentialGroup()
                                                                        			.addGap(7)
                                                                        			.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                                        			.addGap(4)
                                                                        			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                                                                        				.addComponent(btbuscar)
                                                                        				.addGroup(groupLayout.createSequentialGroup()
                                                                        					.addGap(2)
                                                                        					.addComponent(txbuscar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
                                                                        			.addGap(10)
                                                                        			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                                                                        				.addComponent(checkhab)
                                                                        				.addComponent(btmod)
                                                                        				.addComponent(btnuevo))
                                                                        			.addGap(13)
                                                                        			.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
                                                                        				.addComponent(btbloquear)
                                                                        				.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
                                                                        					.addComponent(lblId)
                                                                        					.addComponent(txdni, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
                                                                        			.addGap(15)
                                                                        			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                                                                        				.addComponent(txnombre, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                                        				.addGroup(groupLayout.createSequentialGroup()
                                                                        					.addGap(3)
                                                                        					.addComponent(lbnombre)))
                                                                        			.addGap(17)
                                                                        			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                                                                        				.addGroup(groupLayout.createSequentialGroup()
                                                                        					.addGap(3)
                                                                        					.addComponent(lbtel))
                                                                        				.addComponent(txtel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                                        			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                                                                        				.addGroup(groupLayout.createSequentialGroup()
                                                                        					.addGap(13)
                                                                        					.addComponent(cbcat, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                                        				.addGroup(groupLayout.createSequentialGroup()
                                                                        					.addGap(11)
                                                                        					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                                                                        						.addGroup(groupLayout.createSequentialGroup()
                                                                        							.addGap(5)
                                                                        							.addComponent(lbcat))
                                                                        						.addComponent(btagregar))))
                                                                        			.addContainerGap())
                                                                        );
                                                                        getContentPane().setLayout(groupLayout);

        jPanel1.getAccessibleContext().setAccessibleName("panel");

        pack();
    }// </editor-fold>                        

    @SuppressWarnings("unchecked")
	void inicio(){
    	
    	ArrayList<Categoria>cat=Pizzeria.devuelveCategoria();
        
        for(int i=0;i<cat.size();i++){  
        	cbcat.addItem(cat.get(i).getnombre());
        	}
        checkhab.setEnabled(false);
        checkhab.setSelected(true);
        btbloquear.setEnabled(false);
        btmod.setEnabled(false);

    }
    
    void actualizar(){
 	   this.proveedor=Pizzeria.devuelveProveedores();
 	   modificado=true;
    }
    
    void desbloquearGuardar(){
        boolean desbloqueo=true;
        
        if(txtel.getText().equals("")){
            desbloqueo=false;}
        else if(txtel.getText().equals("")){
            desbloqueo=false;}
        else if(txnombre.getText().equals("")){
            desbloqueo=false;
        }
        else if(btbloquear.isEnabled()==true || btmod.isEnabled()==true){
            desbloqueo=false;
        }
        else{
            desbloqueo=true;}
        btagregar.setEnabled(desbloqueo);
        }
                                        

    private void btagregarActionPerformed(java.awt.event.ActionEvent evt) { 
    	String nombre=txnombre.getText().toUpperCase();
        String tel=txtel.getText();
        String dni=txdni.getText();
        ArrayList<Categoria>cat=Pizzeria.devuelveCategoria();
        int idcat = 0;
        int idhab;
        if(checkhab.isSelected()){ idhab=1;}
        else{ idhab=0;}
        for(int i=0;i<cat.size();i++){  
        	if(cbcat.getSelectedItem().equals(cat.get(i).getnombre())){ 
        		idcat=cat.get(i).getid();
        	}
        }
        //System.out.println(id);
        //Proveedor prov = new Proveedor(txnombre.getText().toUpperCase(),txtel.getText(),0);
        Pizzeria.agregarProveedor(dni,nombre,tel,idcat,idhab);
        actualizar();
        txnombre.setText("");
        txtel.setText("");
        txtel.setText("");
        txdni.setText("");
    }                                         

    private void btbloquearActionPerformed(java.awt.event.ActionEvent evt) {                                           
        int act;
        if(checkhab.isSelected()){act=0; checkhab.setSelected(false);}
        else{act=1; checkhab.setSelected(true);}
        int dni=Integer.parseInt(txdni.getText());
        Pizzeria.bloquearproveedor(act,dni );
        btbloquear.setEnabled(false);
        
        actualizar();
    }                                          

    private void btmodActionPerformed(java.awt.event.ActionEvent evt) {  
    	ArrayList<Categoria>cat=Pizzeria.devuelveCategoria();
        String nombre=txnombre.getText().toUpperCase();
        int dni=Integer.parseInt(txdni.getText());
        int tel=Integer.parseInt(txtel.getText());
        int categoria = 0;
        for(int i=0;i<cat.size();i++){ 
        	if(cbcat.getSelectedItem().equals(cat.get(i).getnombre())){ 
        		categoria=cat.get(i).getid();
        	}
        }
        
        Pizzeria.modificarproveedor(dni,nombre,txtel.getText(),categoria);
        
        txnombre.setEnabled(true);
        txnombre.setText("");
        txdni.setText("");
        txtel.setText("");
        btmod.setEnabled(false);
        btbloquear.setEnabled(false);
        txtel.setText("");
        txbuscar.setText("");
        actualizar();
    }                                     

    private void txnombreActionPerformed(java.awt.event.ActionEvent evt) {                                         
        if(txnombre.getText().equals("")){
            txnombre.requestFocus();
        }
        else{
            txnombre.transferFocus(); 
        }
    }                                        

    private void txdirActionPerformed(java.awt.event.ActionEvent evt) {                                      
        if(txtel.getText().equals("")){
            txtel.requestFocus();
        }
        else{
            txtel.transferFocus(); 
        }
    }                                     

    private void checkhabActionPerformed(java.awt.event.ActionEvent evt) {                                         
    }                                        

    private void btbuscarActionPerformed(java.awt.event.ActionEvent evt) { 
    	ArrayList<Categoria> cat=Pizzeria.devuelveCategoria();
        String busqueda = (txbuscar.getText());
        Proveedor proveed=Proveedor.buscarxDNI(busqueda);
        for(int i=0;i<proveedor.size();i++){
            if(busqueda.equals(proveedor.get(i).toString())){
                txdni.setText(String.valueOf(proveedor.get(i).getid()));
                txtel.setText(proveedor.get(i).getDireccion());
                txtel.setText(String.valueOf(proveedor.get(i).getTelefono()));
                txnombre.setText(proveedor.get(i).getNombre());
                if(proveedor.get(i).getEstado()==1){checkhab.setSelected(true);}
                else{checkhab.setSelected(false);}
                txnombre.setEnabled(true);
                btbloquear.setEnabled(true);
                btmod.setEnabled(true);
                btagregar.setEnabled(false);
                txdni.setEnabled(false);
                
                cbcat.setSelectedItem(proveed.getTipo());
                txdni.setEnabled(false);
                
            }
        }
  
        }
                                            

    private void btnuevoActionPerformed(java.awt.event.ActionEvent evt) {                                        
  
    	txtel.setText("");
        btagregar.setEnabled(true);   
    	checkhab.setSelected(true);
        txdni.setText("");
        txdni.setEnabled(true);
        txnombre.setText("");
        txtel.setText("");
        btbloquear.setEnabled(false);
        btmod.setEnabled(false);
            txnombre.setEnabled(true);
            txbuscar.setText("Ingrese nombre de proveedor");
            // TODO add your handling code here:
            
    }  
    
    

    private void txnombreKeyTyped(java.awt.event.KeyEvent evt) {                                  
        desbloquearGuardar();// TODO add your handling code here:
    }                                 

    private void txdirKeyTyped(java.awt.event.KeyEvent evt) {                               
        desbloquearGuardar();// TODO add your handling code here:
    }                              

    private void txnombreKeyReleased(java.awt.event.KeyEvent evt) {                                     
        // TODO add your handling code here:
    }                                    

    private void txdirKeyReleased(java.awt.event.KeyEvent evt) {                                  
        // TODO add your handling code here:
    }                                 

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Abmproveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Abmproveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Abmproveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Abmproveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            	Abmproveedor dialog = new Abmproveedor();
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton btagregar;
    private javax.swing.JButton btbloquear;
    private javax.swing.JButton btbuscar;
    private javax.swing.JButton btmod;
    private javax.swing.JButton btnuevo;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JCheckBox checkhab;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbtel;
    private javax.swing.JLabel lbnombre;
    private javax.swing.JLabel lbcat;
    private javax.swing.JTextField txbuscar;
    private javax.swing.JTextField txtel;
    private javax.swing.JTextField txnombre;
    private JComboBox cbcat;
    private JTextField txdni;
}
