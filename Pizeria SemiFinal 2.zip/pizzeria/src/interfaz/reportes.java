package interfaz;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;

import negocio.Compra;
import negocio.DetalleCompra;
import reportes.ReporteCompra;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;
import javax.swing.JTextField;

public class reportes {

	private static JFrame frame= new JFrame();
	public static JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					reportes window = new reportes();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public reportes() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private static void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 367, 199);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnGenerar = new JButton("Generar reporte");
		btnGenerar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Compra com=Compra.buscar(textField.getText().toString());
				ReporteCompra reporte=new ReporteCompra(DetalleCompra.buscar(textField.getText().toString()),com.getProveedor());
				reporte.mostrar();
			}
		});
		btnGenerar.setBounds(213, 22, 128, 23);
		frame.getContentPane().add(btnGenerar);
		
		JLabel lblElijaCompra = new JLabel("Elija compra");
		lblElijaCompra.setBounds(25, 26, 83, 14);
		frame.getContentPane().add(lblElijaCompra);
		
		textField = new JTextField();
		textField.setBounds(126, 23, 77, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
	    
		//public  void setVisible(boolean b) {
			//initialize();
		//frame.setVisible(true);
		/*frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);*/
			
		}

	public static void setVisible(boolean b) {
		frame.setVisible(true);
		initialize();
	}
}
