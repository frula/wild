package negocio;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import datos.Basededatos;
import datos.Busqueda;

public class DetalleCompra {

	public String MateriaPrima;
	
	public int cant;
	public int idCompra;
	
	DetalleCompra(){
		this.MateriaPrima="";
		
		this.cant=0;
		this.idCompra=0;
	}
	
	public DetalleCompra(String Materia, int cant,int idCompra){
		this.MateriaPrima=Materia;
		this.cant=cant;
		this.idCompra=idCompra;
	}
	
	public void setMateriaPrima(String valor){
		this.MateriaPrima=valor;
	}
	public void setCantidad(int cant){
		this.cant=cant;
	}
	public void setIdCompra(int compra){
		this.idCompra=compra;
	}
	public String getMateriaprima(){
		return this.MateriaPrima;
	}
	public int getCantidad(){
		return this.cant; 
	}
	public int getIdCompra(){
		return this.idCompra;
	}

	public static ArrayList<DetalleCompra> buscar(String text) {
		ArrayList<DetalleCompra> nuevo=new ArrayList<DetalleCompra>();
		DetalleCompra c=null;
		try {
			ResultSet pro=Busqueda.devuelveTabla("detallecompra");
			if(pro.getString(4).equals(text)){
				//System.out.println(pro.getString(1)+"salio");
				c=new DetalleCompra(pro.getString(2),pro.getInt(3),pro.getInt(4));
			    nuevo.add(c);  
			}
			
			while(pro.next()){
				if(pro.getString(4).equals(text)){
					c=new DetalleCompra(pro.getString(2),pro.getInt(3),pro.getInt(4));
				    nuevo.add(c);  
				}
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return nuevo;
	}
	
	public static void modificar(String nombre, int cantidad, int idCompra){
		
		try {
			Basededatos.ejecutarsql("UPDATE detallecompra SET IdMateriaPrima='"+nombre+"' WHERE IdCompra="+idCompra+"");
			Basededatos.ejecutarsql("UPDATE detallecompra SET Cantidad='"+cantidad+"' WHERE IdCompra="+idCompra+"");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void eliminar(int numeroCompra){
		try {
			Basededatos.ejecutarsql("DELETE FROM detallecompra where IdCompra="+numeroCompra+"");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void agregar(String idmateriaPrima,int cantidad,int idcompra){
		try {
			Basededatos.ejecutarsql("INSERT INTO detallecompra(IdMateriaPrima,Cantidad,IdCompra) VALUES('"+idmateriaPrima+"',"+cantidad+","+idcompra+")");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static List<DetalleCompra>dameCompras(){
		ArrayList<DetalleCompra> nuevo=new ArrayList<DetalleCompra>();
		DetalleCompra c=new DetalleCompra();
		try {
			ResultSet pro=Busqueda.devuelveTabla("detallecompra");
			//if(pro.getString(4).equals(text)){
				//System.out.println(pro.getString(1)+"salio");
				c=new DetalleCompra(pro.getString(2),pro.getInt(3),pro.getInt(4));
			    nuevo.add(c);  
			
			while(pro.next()){
					c=new DetalleCompra(pro.getString(2),pro.getInt(3),pro.getInt(4));
				    nuevo.add(c);  
				}
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return nuevo;
	}
	 public static  List<DetalleCompra> listaCompras(){
		 return DetalleCompra.dameCompras();
}
}
