package negocio;

import java.util.ArrayList;

public class reporte {
	
	int numero;
	String proveedor;
	ArrayList<Producto> productos;
  
	reporte(int num,String prove,ArrayList<Producto> pro){
		this.numero=num;
		this.proveedor=prove;
		this.productos=pro;
	}
	
	
	
}
